using UnityEngine;
using FruitMerge.Data;

namespace FruitMerge.Core
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class Fruit : MonoBehaviour
    {
        [Header("Settings")]
        [SerializeField] private float maxVelocity = 15f;

        private bool isLockedForMerge;
        private bool isInitialized;
        private bool isDropped = false;

        private Rigidbody2D rb;
        private SpriteRenderer spriteRenderer;
        private Collider2D activeCollider;
        private CircleCollider2D circleCol;
        private BoxCollider2D boxCol;
        private CapsuleCollider2D capsuleCol;
        private PolygonCollider2D polygonCol;

        private FruitTypeSO fruitType;

        public FruitTypeSO FruitType => fruitType;
        public bool IsLockedForMerge => isLockedForMerge;
        public bool IsInitialized => isInitialized;
        public bool IsDropped => isDropped;
        public Rigidbody2D Rigidbody => rb;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            if (rb == null)
            {
                Debug.LogError("[Fruit] Rigidbody2D component bulunamadi! Prefab'a ekle.");
            }

            spriteRenderer = GetComponent<SpriteRenderer>();
            
            // Herhangi bir Collider2D tipini bul
            activeCollider = GetComponent<Collider2D>();
            if (activeCollider == null)
            {
                Debug.LogWarning("[Fruit] Collider2D component bulunamadi! Prefab'a ekle.");
            }

            circleCol = GetComponent<CircleCollider2D>();
            boxCol = GetComponent<BoxCollider2D>();
            capsuleCol = GetComponent<CapsuleCollider2D>();
            polygonCol = GetComponent<PolygonCollider2D>();
        }

        public void Initialize(FruitTypeSO type, Vector2 position, bool isKinematic = false)
        {
            if (type == null)
            {
                Debug.LogError("[Fruit] Initialize: FruitType null!");
                return;
            }

            fruitType = type;
            transform.position = position;
            transform.rotation = Quaternion.identity;

            // ÖNEMLİ: Prefab'taki tüm ayarları koru - sadece gerekli olanları güncelle
            
            // Sprite güncelle (prefab'taki sprite'ı override et)
            if (spriteRenderer != null && type.sprite != null)
            {
                spriteRenderer.sprite = type.sprite;
                spriteRenderer.sortingOrder = Time.frameCount % 1000;
            }

            // Z pozisyonunu sıfırla
            Vector3 pos = transform.position;
            pos.z = 0f;
            transform.position = pos;

            // COLLIDER AYARLARI: Prefab'taki ayarları koru - HİÇBİR ŞEY YAPMA!
            // Prefab'ta ayarlanan collider radius, offset, size, center vb. TÜM ayarlar korunur
            // Initialize() metodu collider ayarlarına DOKUNMUYOR
            
            // Debug: Collider ayarlarını kontrol et
            #if UNITY_EDITOR
            if (boxCol != null)
            {
                Debug.Log($"[Fruit] Initialize: BoxCollider Size={boxCol.size}, Offset={boxCol.offset}");
            }
            if (circleCol != null)
            {
                Debug.Log($"[Fruit] Initialize: CircleCollider Radius={circleCol.radius}, Offset={circleCol.offset}");
            }
            #endif

            // Physics Material'ı sadece ScriptableObject'te varsa uygula
            // Prefab'taki material'ı override etmez, sadece yoksa ekler
            if (type.optionalMaterial != null && activeCollider != null)
            {
                // Sadece collider'da material yoksa ekle
                if (circleCol != null && circleCol.sharedMaterial == null)
                {
                    circleCol.sharedMaterial = type.optionalMaterial;
                }
                else if (boxCol != null && boxCol.sharedMaterial == null)
                {
                    boxCol.sharedMaterial = type.optionalMaterial;
                }
                else if (capsuleCol != null && capsuleCol.sharedMaterial == null)
                {
                    capsuleCol.sharedMaterial = type.optionalMaterial;
                }
                else if (polygonCol != null && polygonCol.sharedMaterial == null)
                {
                    polygonCol.sharedMaterial = type.optionalMaterial;
                }
            }

            // Rigidbody ayarları (prefab'taki bazı ayarları override edebilir ama bu normal)
            if (rb != null)
            {
                rb.velocity = Vector2.zero;
                rb.angularVelocity = 0f;
                rb.bodyType = isKinematic ? RigidbodyType2D.Kinematic : RigidbodyType2D.Dynamic;
                rb.simulated = true;
                rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
                rb.interpolation = RigidbodyInterpolation2D.Interpolate;
                rb.constraints = RigidbodyConstraints2D.FreezeRotation;

                // Rigidbody material'ı sadece yoksa ekle
                if (type.optionalMaterial != null && rb.sharedMaterial == null)
                {
                    rb.sharedMaterial = type.optionalMaterial;
                }
            }

            isLockedForMerge = false;
            isInitialized = true;
            isDropped = !isKinematic;

            if (activeCollider != null) activeCollider.enabled = true;

            gameObject.SetActive(true);
        }

        // Meyveyi düşür (dynamic yap)
        public void Drop()
        {
            if (rb == null)
            {
                Debug.LogError("[Fruit] Drop: Rigidbody null!");
                return;
            }

            // KRİTİK: Önce Dynamic yap, sonra simulated aç
            rb.bodyType = RigidbodyType2D.Dynamic;
            rb.simulated = true;
            rb.gravityScale = 1f; // Gravity'yi aç (eğer kapalıysa)
            isDropped = true;

            // Debug log
            Debug.Log($"[Fruit] {fruitType?.displayName} düşürüldü. BodyType: {rb.bodyType}, Simulated: {rb.simulated}, Gravity: {rb.gravityScale}");
        }

        public void LockForMerge()
        {
            if (isLockedForMerge) return;

            isLockedForMerge = true;

            if (rb != null)
            {
                rb.velocity = Vector2.zero;
                rb.angularVelocity = 0f;
                rb.simulated = false;
            }

            if (activeCollider != null)
            {
                activeCollider.enabled = false;
            }
        }

        public void ResetForPool()
        {
            isLockedForMerge = false;
            isInitialized = false;
            isDropped = false;
            fruitType = null;

            if (rb != null)
            {
                rb.velocity = Vector2.zero;
                rb.angularVelocity = 0f;
                rb.bodyType = RigidbodyType2D.Dynamic;
                rb.simulated = true;
            }

            if (activeCollider != null)
            {
                activeCollider.enabled = true;
            }

            gameObject.SetActive(false);
        }

        private void FixedUpdate()
        {
            if (rb != null && !isLockedForMerge && rb.bodyType == RigidbodyType2D.Dynamic)
            {
                if (rb.velocity.sqrMagnitude > maxVelocity * maxVelocity)
                {
                    rb.velocity = rb.velocity.normalized * maxVelocity;
                }

                if (transform.position.z != 0f)
                {
                    Vector3 pos = transform.position;
                    pos.z = 0f;
                    transform.position = pos;
                }
            }
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            ProcessCollision(collision);
        }

        // OnCollisionStay2D kaldırıldı - her frame çağrılıyor, performans sorunu yaratıyor
        // OnCollisionEnter2D yeterli (meyveler bir kez çarpıştığında merge edilmeli)

        private void ProcessCollision(Collision2D collision)
        {
            if (isLockedForMerge) return;
            
            // Sadece düşürülmüş meyveler merge edebilir
            if (!isDropped) return;

            Fruit otherFruit = collision.gameObject.GetComponent<Fruit>();
            if (otherFruit == null) return;
            if (otherFruit.IsLockedForMerge) return;
            
            // Diğeri de düşürülmüş mü?
            if (!otherFruit.IsDropped) return;
            
            if (fruitType == null || otherFruit.FruitType == null) return;
            if (fruitType.id != otherFruit.FruitType.id) return;

            // MergeSystem kontrolü
            if (MergeSystem.Instance == null)
            {
                Debug.LogError("[Fruit] MergeSystem.Instance null!");
                return;
            }

            // ContactPoint al
            Vector2 contactPoint = collision.contactCount > 0 
                ? collision.contacts[0].point 
                : (Vector2)transform.position;

            // Merge sisteme bildir
            MergeSystem.Instance.OnFruitCollision(this, otherFruit, contactPoint);
        }
    }
}
