using FruitMerge.Data;
using FruitMerge.Managers;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace FruitMerge.UI
{
    public class UIHud : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private ScoreManager scoreManager;
        [SerializeField] private SpawnQueueManager spawnQueueManager;
        [SerializeField] private GameManager gameManager;

        [Header("UI Elements")]
        [SerializeField] private TextMeshProUGUI scoreText;
        [SerializeField] private TextMeshProUGUI highScoreText;
        [SerializeField] private Image nextFruitImage;
        [SerializeField] private Button restartButton;

        [Header("Game Over Panel")]
        [SerializeField] private GameObject gameOverPanel;
        [SerializeField] private TextMeshProUGUI gameOverTitleText;
        [SerializeField] private TextMeshProUGUI finalScoreText;
        [SerializeField] private Button gameOverRestartButton;

        [Header("Settings")]
        [SerializeField] private string scoreFormat = "Score: {0}";
        [SerializeField] private string highScoreFormat = "Best: {0}";

        private void OnEnable()
        {
            // Singleton'ları kullan (fallback olarak direkt referanslar)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            SpawnQueueManager spawnQueue = spawnQueueManager != null ? spawnQueueManager : FindFirstObjectByType<SpawnQueueManager>();
            GameManager game = gameManager != null ? gameManager : GameManager.Instance;

            if (score != null)
            {
                score.OnScoreChanged += UpdateScoreText;
                score.OnHighScoreChanged += UpdateHighScoreText;
            }
            else
            {
                Debug.LogWarning("[UIHud] ScoreManager bulunamadı! Event subscription yapılamadı.");
            }

            if (spawnQueue != null)
            {
                spawnQueue.OnNextChanged += UpdateNextFruitPreview;
            }
            else
            {
                Debug.LogWarning("[UIHud] SpawnQueueManager bulunamadı! Event subscription yapılamadı.");
            }

            if (game != null)
            {
                game.OnGameStateChanged += HandleGameStateChanged;
            }
            else
            {
                Debug.LogWarning("[UIHud] GameManager bulunamadı! Event subscription yapılamadı.");
            }

            if (restartButton != null)
            {
                restartButton.onClick.AddListener(OnRestartButtonClicked);
            }

            if (gameOverRestartButton != null)
            {
                gameOverRestartButton.onClick.AddListener(OnRestartButtonClicked);
            }
        }

        private void OnDisable()
        {
            // Singleton'ları kullan (fallback olarak direkt referanslar)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            SpawnQueueManager spawnQueue = spawnQueueManager != null ? spawnQueueManager : FindFirstObjectByType<SpawnQueueManager>();
            GameManager game = gameManager != null ? gameManager : GameManager.Instance;

            if (score != null)
            {
                score.OnScoreChanged -= UpdateScoreText;
                score.OnHighScoreChanged -= UpdateHighScoreText;
            }

            if (spawnQueue != null)
            {
                spawnQueue.OnNextChanged -= UpdateNextFruitPreview;
            }

            if (game != null)
            {
                game.OnGameStateChanged -= HandleGameStateChanged;
            }

            if (restartButton != null)
            {
                restartButton.onClick.RemoveListener(OnRestartButtonClicked);
            }

            if (gameOverRestartButton != null)
            {
                gameOverRestartButton.onClick.RemoveListener(OnRestartButtonClicked);
            }
        }

        private void Start()
        {
            // Singleton kullan (fallback)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            
            if (score != null)
            {
                UpdateScoreText(score.CurrentScore);
                UpdateHighScoreText(score.HighScore);
            }

            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);
            }
        }

        private void UpdateScoreText(int score)
        {
            if (scoreText != null)
            {
                scoreText.text = string.Format(scoreFormat, score);
            }
        }

        private void UpdateHighScoreText(int highScore)
        {
            if (highScoreText != null)
            {
                highScoreText.text = string.Format(highScoreFormat, highScore);
            }
        }

        private void UpdateNextFruitPreview(FruitTypeSO nextFruit)
        {
            if (nextFruitImage != null)
            {
                if (nextFruit != null && nextFruit.sprite != null)
                {
                    nextFruitImage.sprite = nextFruit.sprite;
                    nextFruitImage.enabled = true;
                }
                else
                {
                    nextFruitImage.enabled = false;
                }
            }
        }

        public void OnRestartButtonClicked()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        private void HandleGameStateChanged(GameManager.GameState newState)
        {
            if (newState == GameManager.GameState.GameOver)
            {
                ShowGameOverPanel();
            }
            else if (newState == GameManager.GameState.Playing)
            {
                HideGameOverPanel();
            }
        }

        private void HideGameOverPanel()
        {
            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);
            }
        }

        private void ShowGameOverPanel()
        {
            if (gameOverPanel == null) return;

            gameOverPanel.SetActive(true);

            if (gameOverTitleText != null)
            {
                gameOverTitleText.text = "GAME OVER!";
            }

            // Singleton kullan (fallback)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            
            if (finalScoreText != null && score != null)
            {
                finalScoreText.text = $"Score: {score.CurrentScore}";
            }

            if (gameOverRestartButton != null)
            {
                gameOverRestartButton.gameObject.SetActive(true);
                gameOverRestartButton.interactable = true;
            }
        }
    }
}
