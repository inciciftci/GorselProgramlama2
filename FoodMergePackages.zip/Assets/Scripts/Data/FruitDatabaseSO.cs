using UnityEngine;
using System.Collections.Generic;
using System.Linq;

namespace FruitMerge.Data
{
    [CreateAssetMenu(fileName = "FruitDatabase", menuName = "FruitMerge/FruitDatabase")]
    public class FruitDatabaseSO : ScriptableObject
    {
        [Header("Fruit Types")]
        [Tooltip("Tum meyve tipleri (ID sirasina gore)")]
        public List<FruitTypeSO> types = new List<FruitTypeSO>();

        // Rehber uyumluluğu için alias (allTypes -> types)
        public List<FruitTypeSO> allTypes
        {
            get => types;
            set => types = value;
        }

        [Header("Spawn Settings")]
        [Tooltip("Spawn edilebilecek maksimum meyve ID'si (0-tabanli). Ornek: 2 = sadece 0,1,2 spawn olur")]
        [SerializeField] private int maxSpawnTypeID = 2;

        private Dictionary<int, FruitTypeSO> idLookup;
        private bool isInitialized = false;

        public void Initialize()
        {
            // Zaten initialize edildiyse tekrar etme (performans optimizasyonu)
            if (isInitialized && idLookup != null && idLookup.Count > 0)
            {
                return;
            }

            idLookup = new Dictionary<int, FruitTypeSO>();
            foreach (var fruitType in types)
            {
                if (fruitType != null)
                {
                    if (idLookup.ContainsKey(fruitType.id))
                    {
                        Debug.LogError($"[FruitDatabase] Çakışan ID: {fruitType.id} ({fruitType.displayName})");
                        continue;
                    }
                    idLookup[fruitType.id] = fruitType;
                }
            }

            if (types.Count == 0)
            {
                Debug.LogError("[FruitDatabase] Types listesi bos! ScriptableObject'leri ekleyin.");
            }

            for (int i = 0; i < types.Count; i++)
            {
                if (types[i] != null && types[i].id != i)
                {
                    Debug.LogWarning($"[FruitDatabase] {types[i].displayName} ID'si ({types[i].id}) index'i ({i}) ile uyusmuyor!");
                }
            }

            isInitialized = true;
            Debug.Log($"[FruitDatabase] Initialize tamamlandı. {idLookup.Count} fruit tipi yüklendi.");
        }

        public FruitTypeSO GetTypeByID(int id)
        {
            if (idLookup == null || idLookup.Count == 0)
            {
                Initialize();
            }

            if (idLookup.TryGetValue(id, out FruitTypeSO fruitType))
            {
                return fruitType;
            }

            Debug.LogError($"[FruitDatabase] ID {id} icin meyve tipi bulunamadi!");
            return null;
        }

        public FruitTypeSO GetNextType(FruitTypeSO currentType)
        {
            if (currentType == null)
            {
                Debug.LogError("[FruitDatabase] GetNextType: currentType null!");
                return null;
            }

            return currentType.nextType;
        }

        public FruitTypeSO GetRandomStartType()
        {
            if (types == null || types.Count == 0)
            {
                Debug.LogError("[FruitDatabase] GetRandomStartType: Types listesi bos! FruitDatabase.asset dosyasında types listesine fruit ekleyin.");
                return null;
            }

            if (idLookup == null || idLookup.Count == 0)
            {
                Initialize();
            }

            List<FruitTypeSO> validTypes = new List<FruitTypeSO>();
            for (int i = 0; i <= maxSpawnTypeID && i < types.Count; i++)
            {
                if (types[i] != null)
                {
                    validTypes.Add(types[i]);
                }
                else
                {
                    Debug.LogWarning($"[FruitDatabase] GetRandomStartType: types[{i}] null! Index {i} boş.");
                }
            }

            if (validTypes.Count == 0)
            {
                Debug.LogError($"[FruitDatabase] GetRandomStartType: Gecerli tip bulunamadi! maxSpawnTypeID: {maxSpawnTypeID}, types.Count: {types.Count}");
                Debug.LogError($"[FruitDatabase] Lütfen FruitDatabase.asset dosyasını açın ve types listesine fruit ekleyin!");
                return null;
            }

            int randomIndex = Random.Range(0, validTypes.Count);
            FruitTypeSO selected = validTypes[randomIndex];
            
            // Log sadece ilk çağrıda veya hata durumunda (çok fazla log spam'ini önle)
            // Debug.Log($"[FruitDatabase] GetRandomStartType: {selected.displayName} seçildi");
            
            return selected;
        }

        public List<FruitTypeSO> GetAllTypes()
        {
            return types;
        }

        public int GetMaxSpawnTypeID()
        {
            return maxSpawnTypeID;
        }
    }
}
