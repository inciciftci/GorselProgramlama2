using UnityEngine;
using FruitMerge.Core;
using FruitMerge.Data;
using FruitMerge.UI;

namespace FruitMerge.Managers
{
    public class GameManager : MonoBehaviour
    {
        // Singleton
        public static GameManager Instance { get; private set; }

        [Header("References")]
        [SerializeField] private FruitDatabaseSO fruitDatabase;
        [SerializeField] private PoolManager poolManager;
        [SerializeField] private MergeSystem mergeSystem;
        [SerializeField] private SpawnQueueManager spawnQueueManager;
        [SerializeField] private FruitSpawner fruitSpawner;
        [SerializeField] private ScoreManager scoreManager;
        [SerializeField] private FailLineManager failLineManager;
        [SerializeField] private UIHud uiHud;

        [Header("Game State")]
        [SerializeField] private GameState currentState = GameState.MainMenu;

        public enum GameState
        {
            MainMenu,
            Playing,
            GameOver,
            Paused
        }

        public System.Action<GameState> OnGameStateChanged;
        public GameState CurrentState => currentState;

        private void Awake()
        {
            // Singleton kurulumu
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[GameManager] Birden fazla instance tespit edildi, yok ediliyor.");
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (fruitDatabase != null)
            {
                fruitDatabase.Initialize();
            }

            if (mergeSystem != null)
            {
                mergeSystem.OnMergeCompleted += HandleMergeCompleted;
            }

            if (failLineManager != null)
            {
                failLineManager.OnGameOver += HandleGameOver;
            }

            Debug.Log("[GameManager] Singleton kuruldu.");
        }

        private void Start()
        {
            WarmupPools();
            StartGame();
        }

        private void WarmupPools()
        {
            if (fruitDatabase == null || poolManager == null) return;

            foreach (var fruitType in fruitDatabase.GetAllTypes())
            {
                if (fruitType != null)
                {
                    poolManager.WarmupPool(fruitType, 5);
                }
            }
        }

        public void StartGame()
        {
            ChangeState(GameState.Playing);

            if (spawnQueueManager != null)
            {
                spawnQueueManager.InitializeQueue();
            }

            if (fruitSpawner != null)
            {
                fruitSpawner.AllowInput = true;
                fruitSpawner.StartSpawning();
            }

            if (scoreManager != null)
            {
                scoreManager.ResetScore();
            }

            if (failLineManager != null)
            {
                failLineManager.ResetFailLine();
            }
        }

        public void RestartGame()
        {
            // Önceki Invoke'ları iptal et (birden fazla restart çağrılırsa sorun olmasın)
            CancelInvoke(nameof(StartGame));

            if (poolManager != null)
            {
                poolManager.ReturnAll();
            }

            if (mergeSystem != null)
            {
                mergeSystem.ClearQueue();
            }

            if (fruitSpawner != null)
            {
                fruitSpawner.ResetSpawner();
            }

            if (spawnQueueManager != null)
            {
                spawnQueueManager.ResetQueue();
            }

            if (scoreManager != null)
            {
                scoreManager.ResetScore();
            }

            if (failLineManager != null)
            {
                failLineManager.ResetFailLine();
            }

            // Kısa delay ile oyunu başlat (tüm sistemlerin reset olması için)
            Invoke(nameof(StartGame), 0.2f);
        }

        private void ChangeState(GameState newState)
        {
            if (currentState == newState) return;

            currentState = newState;
            OnGameStateChanged?.Invoke(newState);

            switch (newState)
            {
                case GameState.Playing:
                    Time.timeScale = 1f;
                    if (fruitSpawner != null) fruitSpawner.AllowInput = true;
                    break;

                case GameState.GameOver:
                    Time.timeScale = 1f;
                    if (fruitSpawner != null) fruitSpawner.AllowInput = false;
                    break;

                case GameState.Paused:
                    Time.timeScale = 0f;
                    if (fruitSpawner != null) fruitSpawner.AllowInput = false;
                    break;
            }
        }

        private void HandleMergeCompleted(FruitTypeSO newFruitType, Vector2 position)
        {
            // Skor MergeSystem'da ekleniyor
        }

        private void HandleGameOver()
        {
            if (currentState != GameState.Playing) return;
            ChangeState(GameState.GameOver);
        }

        public void TogglePause()
        {
            if (currentState == GameState.Playing)
            {
                ChangeState(GameState.Paused);
            }
            else if (currentState == GameState.Paused)
            {
                ChangeState(GameState.Playing);
            }
        }

        private void OnDestroy()
        {
            if (mergeSystem != null)
            {
                mergeSystem.OnMergeCompleted -= HandleMergeCompleted;
            }

            if (failLineManager != null)
            {
                failLineManager.OnGameOver -= HandleGameOver;
            }

            if (Instance == this)
            {
                Instance = null;
            }
        }
    }
}
