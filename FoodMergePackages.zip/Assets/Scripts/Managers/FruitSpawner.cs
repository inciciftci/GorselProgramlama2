using FruitMerge.Core;
using FruitMerge.Data;
using UnityEngine;

namespace FruitMerge.Managers
{
    public class FruitSpawner : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private PoolManager poolManager;
        [SerializeField] private SpawnQueueManager spawnQueueManager;

        [Header("Spawn Settings")]
        [SerializeField] private float spawnY = 8f;
        [SerializeField] private float minX = -6f;
        [SerializeField] private float maxX = 6f;
        [SerializeField] private float previewOffsetY = 0.5f;

        [Header("Input Settings")]
        [SerializeField] private bool allowInput = true;

        private Fruit previewFruit;
        private bool isDragging = false;
        private bool hasDropped = false;

        private Camera mainCamera;

        public bool AllowInput
        {
            get => allowInput;
            set => allowInput = value;
        }

        private void Awake()
        {
            mainCamera = Camera.main;
        }

        private void Start()
        {
            // SpawnQueueManager'ın InitializeQueue() çağrılmasını bekle
            // Start() metodları sırayla çalışır, bu yüzden kısa bir delay ekle
            // Ama GameManager.StartGame() zaten StartSpawning() çağırıyor, bu yüzden burada gerek yok
            // Sadece GameManager çalışmazsa fallback olarak spawn et
            if (GameManager.Instance == null || GameManager.Instance.CurrentState == GameManager.GameState.MainMenu)
            {
                Invoke(nameof(SpawnFirstPreview), 0.1f);
            }
        }

        private void SpawnFirstPreview()
        {
            // İlk preview fruit'ı spawn et
            if (spawnQueueManager != null && poolManager != null)
            {
                // SpawnQueueManager hazır değilse InitializeQueue() çağır
                if (spawnQueueManager.CurrentFruit == null)
                {
                    Debug.LogWarning("[FruitSpawner] SpawnQueueManager.CurrentFruit null! InitializeQueue() çağrılıyor...");
                    spawnQueueManager.InitializeQueue();
                }

                SpawnPreviewFruit();
                // Debug.Log("[FruitSpawner] Start: İlk preview fruit spawn edildi.");
            }
            else
            {
                Debug.LogWarning("[FruitSpawner] Start: spawnQueueManager veya poolManager null! Preview fruit spawn edilemedi.");
            }
        }

        private void Update()
        {
            if (!allowInput) return;
            HandleInput();
        }

        private void HandleInput()
        {
            // Preview fruit kontrolü - Eğer null ise (drop sonrası bekleme süresi gibi) input işlemine devam etme
            if (previewFruit == null)
            {
                return;
            }

            // Mouse input
            if (Input.GetMouseButtonDown(0))
            {
                isDragging = true;
                hasDropped = false;
                // Debug.Log("[FruitSpawner] Mouse button DOWN - dragging başladı");
            }

            if (Input.GetMouseButton(0) && isDragging && !hasDropped)
            {
                MovePreviewToMousePosition();
            }

            if (Input.GetMouseButtonUp(0) && isDragging && !hasDropped)
            {
                // Debug.Log("[FruitSpawner] Mouse button UP - fruit düşürülüyor");
                DropFruit();
                isDragging = false;
                hasDropped = true;
            }

            // Touch input
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);

                if (touch.phase == TouchPhase.Began)
                {
                    isDragging = true;
                    hasDropped = false;
                }
                else if (touch.phase == TouchPhase.Moved && isDragging && !hasDropped)
                {
                    MovePreviewToTouchPosition(touch.position);
                }
                else if (touch.phase == TouchPhase.Ended && isDragging && !hasDropped)
                {
                    DropFruit();
                    isDragging = false;
                    hasDropped = true;
                }
            }
        }

        private void SpawnPreviewFruit()
        {
            if (spawnQueueManager == null)
            {
                Debug.LogError("[FruitSpawner] SpawnPreviewFruit: spawnQueueManager null!");
                return;
            }

            if (poolManager == null)
            {
                Debug.LogError("[FruitSpawner] SpawnPreviewFruit: poolManager null!");
                return;
            }

            FruitTypeSO currentType = spawnQueueManager.CurrentFruit;
            if (currentType == null)
            {
                Debug.LogError("[FruitSpawner] SpawnPreviewFruit: CurrentFruit null!");
                return;
            }

            Vector2 spawnPosition = new Vector2(0, spawnY + previewOffsetY);
            previewFruit = poolManager.Get(currentType, spawnPosition, isKinematic: true);

            if (previewFruit != null)
            {
                previewFruit.Rigidbody.bodyType = RigidbodyType2D.Kinematic;
                previewFruit.Rigidbody.simulated = false;
                // Log sadece gerektiğinde (çok fazla log spam'ini önle)
                // Debug.Log($"[FruitSpawner] Preview fruit spawn edildi: {currentType.displayName} at Y={spawnPosition.y}");
            }
            else
            {
                Debug.LogError($"[FruitSpawner] SpawnPreviewFruit: Preview fruit spawn edilemedi! {currentType.displayName}");
            }
        }

        private void MovePreviewToMousePosition()
        {
            if (previewFruit == null)
            {
                Debug.LogWarning("[FruitSpawner] MovePreviewToMousePosition: previewFruit null!");
                return;
            }

            if (mainCamera == null)
            {
                Debug.LogWarning("[FruitSpawner] MovePreviewToMousePosition: mainCamera null!");
                return;
            }

            Vector3 mouseWorldPos = mainCamera.ScreenToWorldPoint(Input.mousePosition);
            float clampedX = Mathf.Clamp(mouseWorldPos.x, minX, maxX);
            
            // SADECE X pozisyonunu değiştir, Y sabit kalsın (spawn noktasında)
            previewFruit.transform.position = new Vector3(clampedX, spawnY + previewOffsetY, 0f);
        }

        private void MovePreviewToTouchPosition(Vector2 touchPosition)
        {
            if (previewFruit == null || mainCamera == null) return;

            Vector3 touchWorldPos = mainCamera.ScreenToWorldPoint(touchPosition);
            float clampedX = Mathf.Clamp(touchWorldPos.x, minX, maxX);

            // SADECE X pozisyonunu değiştir, Y sabit kalsın (spawn noktasında)
            previewFruit.transform.position = new Vector3(clampedX, spawnY + previewOffsetY, 0f);
        }

        private void DropFruit()
        {
            if (previewFruit == null)
            {
                Debug.LogWarning("[FruitSpawner] DropFruit: previewFruit null!");
                return;
            }

            Vector3 currentPos = previewFruit.transform.position;
            float randomOffsetX = Random.Range(-0.1f, 0.1f);
            
            // Meyveyi spawn noktasından biraz aşağı konumlandır (fail line'ın ÜZERİNDE ama güvenli mesafede)
            float dropY = spawnY - 0.5f; // Fail line'dan 0.5 birim yukarıda başlat
            previewFruit.transform.position = new Vector3(currentPos.x + randomOffsetX, dropY, 0f);

            // KRİTİK: Drop() metodunu ÇAĞIR (Dynamic + Simulated yapar)
            previewFruit.Drop();
            
            // SONRA Rigidbody ayarlarını yap (Drop'tan sonra!)
            if (previewFruit.Rigidbody != null)
            {
                previewFruit.Rigidbody.velocity = new Vector2(0f, -2f); // Biraz daha hızlı aşağı
                previewFruit.Rigidbody.angularVelocity = 0f;
            }

            Debug.Log($"[FruitSpawner] Fruit düşürüldü: {previewFruit.FruitType?.displayName} at Y={dropY}, BodyType: {previewFruit.Rigidbody?.bodyType}");

            spawnQueueManager.AdvanceQueue();
            previewFruit = null;

            Invoke(nameof(SpawnPreviewFruit), 0.3f);
        }

        public void ResetSpawner()
        {
            if (previewFruit != null)
            {
                if (poolManager != null)
                {
                    poolManager.Return(previewFruit);
                }
                previewFruit = null;
            }

            isDragging = false;
            hasDropped = false;

            // Tüm Invoke'ları iptal et
            CancelInvoke(nameof(SpawnPreviewFruit));
            CancelInvoke(nameof(SpawnFirstPreview));
        }

        public void StartSpawning()
        {
            ResetSpawner();
            SpawnPreviewFruit();
        }

        private void OnDrawGizmos()
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawLine(new Vector3(minX, spawnY, 0), new Vector3(maxX, spawnY, 0));

            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(new Vector3(minX, spawnY, 0), 0.3f);
            Gizmos.DrawWireSphere(new Vector3(maxX, spawnY, 0), 0.3f);
        }
    }
}
