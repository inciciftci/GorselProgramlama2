using UnityEngine;

namespace FruitMerge.Managers
{
    public class ScoreManager : MonoBehaviour
    {
        // Singleton
        public static ScoreManager Instance { get; private set; }

        [Header("Score")]
        [SerializeField] private int currentScore = 0;
        [SerializeField] private int highScore = 0;

        [Header("Settings")]
        [SerializeField] private string highScoreKey = "HighScore";

        public System.Action<int> OnScoreChanged;
        public System.Action<int> OnHighScoreChanged;

        public int CurrentScore => currentScore;
        public int HighScore => highScore;

        private void Awake()
        {
            // Singleton kurulumu
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[ScoreManager] Birden fazla instance tespit edildi, yok ediliyor.");
                Destroy(gameObject);
                return;
            }
            Instance = this;

            Debug.Log("[ScoreManager] Singleton kuruldu.");
        }

        private void Start()
        {
            LoadHighScore();
        }

        public void AddScore(int points)
        {
            if (points <= 0) return;

            currentScore += points;
            OnScoreChanged?.Invoke(currentScore);

            if (currentScore > highScore)
            {
                highScore = currentScore;
                OnHighScoreChanged?.Invoke(highScore);
                SaveHighScore();
            }
        }

        public void ResetScore()
        {
            currentScore = 0;
            OnScoreChanged?.Invoke(currentScore);
        }

        private void LoadHighScore()
        {
            highScore = PlayerPrefs.GetInt(highScoreKey, 0);
            OnHighScoreChanged?.Invoke(highScore);
        }

        private void SaveHighScore()
        {
            PlayerPrefs.SetInt(highScoreKey, highScore);
            PlayerPrefs.Save();
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }
    }
}
