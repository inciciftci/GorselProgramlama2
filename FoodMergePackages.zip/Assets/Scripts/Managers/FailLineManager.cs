using UnityEngine;
using System.Collections.Generic;
using FruitMerge.Core;

namespace FruitMerge.Managers
{
    [RequireComponent(typeof(BoxCollider2D))]
    public class FailLineManager : MonoBehaviour
    {
        [Header("Settings")]
        [Tooltip("Meyve çizginin üstünde bu süre kadar SABİT kalırsa Game Over")]
        [SerializeField] private float graceTime = 1.0f;
        
        [Header("Detection Mode")]
        [Tooltip("Trigger kullan (collider ile) veya Y pozisyon kontrolü yap")]
        [SerializeField] private bool useTriggerDetection = false;
        
        [Header("Y Position Detection (useTriggerDetection = false ise)")]
        [Tooltip("Game Over tetiklenecek Y pozisyonu (kutunun en üstü)")]
        [SerializeField] private float gameOverYPosition = 3.5f;
        
        [Tooltip("Y pozisyon kontrolü için kontrol edilecek tüm Fruit'leri bul")]
        [SerializeField] private bool checkAllFruitsInScene = true;
        
        [Header("Sabit Kalma Kontrolü")]
        [Tooltip("Meyvenin sabit sayılması için maksimum hız (meyve bu hızdan yavaşsa 'sabit' sayılır)")]
        [SerializeField] private float stationaryVelocityThreshold = 0.1f;

        [Header("Debug")]
        [SerializeField] private bool debugMode = false;

        private Dictionary<Fruit, float> fruitsInZone = new Dictionary<Fruit, float>();
        private Dictionary<Fruit, Vector2> fruitLastPositions = new Dictionary<Fruit, Vector2>();

        public System.Action OnGameOver;

        private BoxCollider2D trigger;

        private void Awake()
        {
            trigger = GetComponent<BoxCollider2D>();

            if (trigger != null)
            {
                trigger.isTrigger = true;
            }

            // Layer ayarı - güvenli kontrol
            int failLineLayer = LayerMask.NameToLayer("FailLine");
            if (failLineLayer >= 0) // Layer bulunduysa (geçerli bir değer)
            {
                gameObject.layer = failLineLayer;
            }
            else
            {
                Debug.LogWarning("[FailLineManager] 'FailLine' layer'ı bulunamadı! Default layer kullanılacak.");
            }
        }

        private void Update()
        {
            // Y pozisyon kontrolü modu
            if (!useTriggerDetection)
            {
                CheckYPositionDetection();
                return;
            }

            // Trigger modu (eski sistem)
            List<Fruit> toRemove = new List<Fruit>();
            var fruitsCopy = new Dictionary<Fruit, float>(fruitsInZone);

            foreach (var kvp in fruitsCopy)
            {
                Fruit fruit = kvp.Key;
                
                if (fruit == null || !fruit.gameObject.activeInHierarchy)
                {
                    toRemove.Add(fruit);
                    continue;
                }

                // Sadece düşürülmüş meyveler sayılır
                if (!fruit.IsDropped)
                {
                    continue;
                }

                float timeInZone = kvp.Value + Time.deltaTime;

                if (fruitsInZone.ContainsKey(fruit))
                {
                    fruitsInZone[fruit] = timeInZone;
                }

                if (timeInZone >= graceTime)
                {
                    TriggerGameOver(fruit);
                    return;
                }
            }

            foreach (var fruit in toRemove)
            {
                if (fruitsInZone.ContainsKey(fruit))
                {
                    fruitsInZone.Remove(fruit);
                }
            }
        }

        private void CheckYPositionDetection()
        {
            // Oyun durumu kontrolü
            if (GameManager.Instance != null && GameManager.Instance.CurrentState != GameManager.GameState.Playing)
            {
                return;
            }

            // PERFORMANS OPTİMİZASYONU: FindObjectsOfType yerine PoolManager'dan aktif fruit'leri al
            List<Fruit> allFruitsList;
            if (checkAllFruitsInScene)
            {
                // PoolManager'dan aktif fruit'leri al (çok daha hızlı)
                if (PoolManager.Instance != null)
                {
                    allFruitsList = PoolManager.Instance.GetAllActiveFruits();
                }
                else
                {
                    // Fallback: FindObjectsOfType (sadece PoolManager yoksa)
                    allFruitsList = new List<Fruit>(FindObjectsOfType<Fruit>());
                    if (debugMode && Time.frameCount % 300 == 0) // Her 5 saniyede bir uyar
                    {
                        Debug.LogWarning("[FailLineManager] PoolManager.Instance null! FindObjectsOfType kullanılıyor (yavaş!).");
                    }
                }
            }
            else
            {
                // Sadece zone'daki meyveleri kontrol et
                allFruitsList = new List<Fruit>();
                foreach (var kvp in fruitsInZone)
                {
                    if (kvp.Key != null)
                    {
                        allFruitsList.Add(kvp.Key);
                    }
                }
            }
            
            Fruit[] allFruits = allFruitsList.ToArray();

            // Zone dışına çıkan meyveleri temizle
            List<Fruit> toRemove = new List<Fruit>();
            foreach (var kvp in fruitsInZone)
            {
                Fruit fruit = kvp.Key;
                if (fruit == null || !fruit.gameObject.activeInHierarchy)
                {
                    toRemove.Add(fruit);
                    continue;
                }

                float fruitTopY = GetFruitTopY(fruit);
                
                // Eğer fruit çizginin altına düştüyse (zone'dan çıktı)
                if (fruitTopY < gameOverYPosition)
                {
                    toRemove.Add(fruit);
                    if (debugMode)
                    {
                        Debug.Log($"[FailLineManager] {fruit.FruitType?.displayName} zone'dan çıktı. Y: {fruitTopY}, Limit: {gameOverYPosition}");
                    }
                }
            }

            // Zone dışına çıkanları temizle
            foreach (var fruit in toRemove)
            {
                fruitsInZone.Remove(fruit);
            }

            // Yeni zone'a giren meyveleri ekle ve süre takibi yap
            foreach (Fruit fruit in allFruits)
            {
                if (fruit == null || !fruit.gameObject.activeInHierarchy) continue;
                
                // ÖNEMLİ: Preview fruit kontrolü (IsDropped kontrolünden ÖNCE)
                Rigidbody2D rb = fruit.GetComponent<Rigidbody2D>();
                if (rb != null && rb.bodyType == RigidbodyType2D.Kinematic)
                {
                    continue; // Preview fruit'lar sayılmaz (kinematic = henüz düşürülmemiş)
                }
                
                if (!fruit.IsDropped) continue; // Sadece düşürülmüş meyveler
                if (fruit.IsLockedForMerge) continue; // Merge için kilitli olanlar sayılmaz

                // Fruit'in en üst noktasını hesapla
                float fruitTopY = GetFruitTopY(fruit);

                // DEBUG: Tüm fruit'leri logla
                if (debugMode && Time.frameCount % 60 == 0) // Her saniye bir kez log
                {
                    Debug.Log($"[FailLineManager] Fruit: {fruit.FruitType?.displayName}, TopY: {fruitTopY:F2}, Limit: {gameOverYPosition:F2}, IsDropped: {fruit.IsDropped}, IsKinematic: {(rb != null ? rb.bodyType == RigidbodyType2D.Kinematic : false)}");
                }

                // Eğer fruit'in en üst noktası gameOverYPosition'ı geçtiyse (zone içinde)
                if (fruitTopY >= gameOverYPosition)
                {
                    // Meyvenin sabit kalıp kalmadığını kontrol et
                    bool isStationary = IsFruitStationary(fruit, rb);
                    
                    if (!isStationary)
                    {
                        // Meyve hareket ediyorsa zone'dan çıkar (süre sıfırla)
                        if (fruitsInZone.ContainsKey(fruit))
                        {
                            fruitsInZone.Remove(fruit);
                            fruitLastPositions.Remove(fruit);
                            if (debugMode)
                            {
                                Debug.Log($"[FailLineManager] {fruit.FruitType?.displayName} hareket ediyor, zone'dan çıkarıldı.");
                            }
                        }
                        continue; // Hareket eden meyveler sayılmaz
                    }

                    // Zone'a yeni girdiyse ekle (sadece sabit meyveler)
                    if (!fruitsInZone.ContainsKey(fruit))
                    {
                        fruitsInZone[fruit] = 0f;
                        fruitLastPositions[fruit] = fruit.transform.position;
                        if (debugMode)
                        {
                            Debug.Log($"[FailLineManager] ⚠️ {fruit.FruitType?.displayName} zone'a GİRDİ ve SABİT! TopY: {fruitTopY:F2}, Limit: {gameOverYPosition:F2}, GraceTime: {graceTime}s");
                        }
                    }

                    // Süre takibi yap (sadece sabit meyveler için)
                    float timeInZone = fruitsInZone[fruit] + Time.deltaTime;
                    fruitsInZone[fruit] = timeInZone;
                    fruitLastPositions[fruit] = fruit.transform.position;

                    // DEBUG: Süre takibi
                    if (debugMode && Time.frameCount % 30 == 0) // Her 0.5 saniyede bir log
                    {
                        Debug.Log($"[FailLineManager] ⏱️ {fruit.FruitType?.displayName} zone'da SABİT {timeInZone:F2}s / {graceTime}s");
                    }

                    // Grace time aşıldıysa game over
                    if (timeInZone >= graceTime)
                    {
                        if (debugMode)
                        {
                            Debug.Log($"[FailLineManager] 🚨 GAME OVER! {fruit.FruitType?.displayName} {graceTime}s boyunca zone'da SABİT kaldı. TopY: {fruitTopY:F2}, Limit: {gameOverYPosition:F2}");
                        }

                        TriggerGameOver(fruit);
                        return;
                    }
                }
                else
                {
                    // Zone dışındaysa temizle
                    if (fruitsInZone.ContainsKey(fruit))
                    {
                        fruitsInZone.Remove(fruit);
                        fruitLastPositions.Remove(fruit);
                    }
                }
            }
        }

        private float GetFruitTopY(Fruit fruit)
        {
            if (fruit == null) return 0f;

            // Collider varsa onun üst noktasını kullan (daha doğru)
            Collider2D col = fruit.GetComponent<Collider2D>();
            if (col != null && col.enabled)
            {
                Bounds bounds = col.bounds;
                float topY = bounds.max.y; // En üst nokta
                return topY;
            }

            // Collider yoksa transform pozisyonunu kullan
            return fruit.transform.position.y;
        }

        private bool IsFruitStationary(Fruit fruit, Rigidbody2D rb)
        {
            if (fruit == null) return false;

            // Rigidbody varsa velocity kontrolü yap
            if (rb != null && rb.bodyType == RigidbodyType2D.Dynamic)
            {
                float velocityMagnitude = rb.velocity.magnitude; // Unity 2D'de velocity kullanılır
                
                // Hız threshold'dan düşükse sabit sayılır
                bool isStationary = velocityMagnitude <= stationaryVelocityThreshold;
                
                if (debugMode && Time.frameCount % 60 == 0)
                {
                    Debug.Log($"[FailLineManager] IsFruitStationary: {fruit.FruitType?.displayName}, Velocity: {velocityMagnitude:F3}, Threshold: {stationaryVelocityThreshold:F3}, Stationary: {isStationary}");
                }
                
                return isStationary;
            }

            // Rigidbody yoksa pozisyon değişikliği kontrolü yap
            if (fruitLastPositions.ContainsKey(fruit))
            {
                Vector2 lastPos = fruitLastPositions[fruit];
                Vector2 currentPos = fruit.transform.position;
                float positionChange = Vector2.Distance(lastPos, currentPos);
                
                // Pozisyon değişimi çok küçükse sabit sayılır
                bool isStationary = positionChange <= stationaryVelocityThreshold * Time.deltaTime;
                
                return isStationary;
            }

            // İlk kontrol, henüz pozisyon kaydedilmemiş
            return true; // İlk kontrol için true döndür (süre takibi başlasın)
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            Fruit fruit = other.GetComponent<Fruit>();

            if (fruit != null && !fruit.IsLockedForMerge && fruit.IsDropped)
            {
                if (!fruitsInZone.ContainsKey(fruit))
                {
                    fruitsInZone[fruit] = 0f;

                    if (debugMode)
                    {
                        Debug.Log($"[FailLineManager] {fruit.FruitType.displayName} fail line'a girdi.");
                    }
                }
            }
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            Fruit fruit = other.GetComponent<Fruit>();

            if (fruit != null && fruitsInZone.ContainsKey(fruit))
            {
                fruitsInZone.Remove(fruit);
            }
        }

        private void TriggerGameOver(Fruit fruit)
        {
            if (debugMode)
            {
                Debug.Log($"[FailLineManager] GAME OVER! Tetikleyen: {fruit?.FruitType?.displayName ?? "Unknown"}");
            }

            OnGameOver?.Invoke();
            fruitsInZone.Clear();
            fruitLastPositions.Clear(); // Pozisyon takibini de temizle
        }

        public void ResetFailLine()
        {
            fruitsInZone.Clear();
            fruitLastPositions.Clear();
            
            // Debug log
            if (debugMode)
            {
                Debug.Log("[FailLineManager] FailLine sıfırlandı.");
            }
        }

        private void OnDrawGizmos()
        {
            // Trigger modu için gizmo
            if (useTriggerDetection && trigger != null)
            {
                Gizmos.color = fruitsInZone.Count > 0 ? Color.red : Color.yellow;
                Gizmos.DrawWireCube(transform.position, trigger.size);
            }

            // Y pozisyon modu için gizmo
            if (!useTriggerDetection)
            {
                Gizmos.color = Color.red;
                Vector3 lineStart = new Vector3(-10, gameOverYPosition, 0);
                Vector3 lineEnd = new Vector3(10, gameOverYPosition, 0);
                Gizmos.DrawLine(lineStart, lineEnd);
                
                // İki uçta küçük işaretler
                Gizmos.DrawWireSphere(lineStart, 0.2f);
                Gizmos.DrawWireSphere(lineEnd, 0.2f);
            }
        }
    }
}
