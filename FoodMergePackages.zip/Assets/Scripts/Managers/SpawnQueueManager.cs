using UnityEngine;
using FruitMerge.Data;

namespace FruitMerge.Managers
{
    public class SpawnQueueManager : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private FruitDatabaseSO fruitDatabase;

        private FruitTypeSO currentFruit;
        private FruitTypeSO nextFruit;

        public System.Action<FruitTypeSO> OnCurrentChanged;
        public System.Action<FruitTypeSO> OnNextChanged;

        public FruitTypeSO CurrentFruit => currentFruit;
        public FruitTypeSO NextFruit => nextFruit;

        private void Awake()
        {
            if (fruitDatabase != null)
            {
                fruitDatabase.Initialize();
            }
        }

        private void Start()
        {
            // Oyun başladığında queue'yu başlat
            InitializeQueue();
        }

        public void InitializeQueue()
        {
            if (fruitDatabase == null)
            {
                Debug.LogError("[SpawnQueueManager] InitializeQueue: FruitDatabase atanmamis!");
                return;
            }

            fruitDatabase.Initialize();

            currentFruit = fruitDatabase.GetRandomStartType();
            nextFruit = fruitDatabase.GetRandomStartType();

            // Null kontrolü ve fallback
            if (currentFruit == null)
            {
                Debug.LogError("[SpawnQueueManager] InitializeQueue: GetRandomStartType() null döndü! FruitDatabase'de fruit var mı kontrol edin.");
                // Fallback: İlk fruit'i al
                if (fruitDatabase.GetAllTypes().Count > 0)
                {
                    currentFruit = fruitDatabase.GetAllTypes()[0];
                    Debug.LogWarning($"[SpawnQueueManager] Fallback: İlk fruit kullanılıyor: {currentFruit?.displayName}");
                }
            }

            if (nextFruit == null)
            {
                Debug.LogError("[SpawnQueueManager] InitializeQueue: NextFruit null! Fallback kullanılıyor.");
                if (fruitDatabase.GetAllTypes().Count > 0)
                {
                    nextFruit = fruitDatabase.GetAllTypes()[0];
                }
            }

            OnCurrentChanged?.Invoke(currentFruit);
            OnNextChanged?.Invoke(nextFruit);

            // Log sadece başlangıçta (çok fazla log spam'ini önle)
            // Debug.Log($"[SpawnQueueManager] Queue başlatıldı. Current: {currentFruit?.displayName ?? "NULL"}, Next: {nextFruit?.displayName ?? "NULL"}");
        }

        public void AdvanceQueue()
        {
            if (fruitDatabase == null)
            {
                Debug.LogError("[SpawnQueueManager] AdvanceQueue: FruitDatabase null!");
                return;
            }

            currentFruit = nextFruit;
            nextFruit = fruitDatabase.GetRandomStartType();

            // Null kontrolü
            if (nextFruit == null)
            {
                Debug.LogError("[SpawnQueueManager] AdvanceQueue: GetRandomStartType() null döndü!");
                if (fruitDatabase.GetAllTypes().Count > 0)
                {
                    nextFruit = fruitDatabase.GetAllTypes()[0];
                    Debug.LogWarning($"[SpawnQueueManager] Fallback: İlk fruit kullanılıyor: {nextFruit?.displayName}");
                }
            }

            OnCurrentChanged?.Invoke(currentFruit);
            OnNextChanged?.Invoke(nextFruit);

            // Log sadece gerektiğinde (çok fazla log spam'ini önle)
            // Debug.Log($"[SpawnQueueManager] Queue ilerledi. Current: {currentFruit?.displayName ?? "NULL"}, Next: {nextFruit?.displayName ?? "NULL"}");
        }

        public void ResetQueue()
        {
            currentFruit = null;
            nextFruit = null;

            OnCurrentChanged?.Invoke(null);
            OnNextChanged?.Invoke(null);
        }
    }
}
