using UnityEngine;

public class PickupManager : MonoBehaviour
{

    public GameObject Pickup;
    public GameObject Ground;
    public int amount;
    private void Start()
    {
        float GroundSizeX = Ground.transform.localScale.x * 10f;
        float GroundSizeZ = Ground.transform.localScale.z * 10f;    

        for (int i = 0; i < amount; i++)
        {
            float randomX = Random.Range(-GroundSizeX / 2f, GroundSizeX / 2f);
            float randomZ = Random.Range(-GroundSizeZ / 2f, GroundSizeZ / 2f);

            Vector3 location = new Vector3(randomX, 3f, randomZ);
            Instantiate(Pickup, location, Quaternion.identity); 
             
        } 
    }



}
