using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;


public class ScoreManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public GameObject   GameOverScreen;
    PickupManager Pickup;
   

    int totalPickup;
    int Score = 0;

    private void Start()
    {
        Pickup = FindFirstObjectByType<PickupManager>();
        totalPickup = Pickup.amount;
        UpdateScore();

    }

    public void CollectPickUp()
    {
        Score++;
        UpdateScore();

        if (Score >= totalPickup)
        {
            GameOverScreen.SetActive(true);
            Time.timeScale = 0f;
        }
    }

    public void UpdateScore()
    {
        scoreText.text = "Skor: " + Score.ToString();
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
