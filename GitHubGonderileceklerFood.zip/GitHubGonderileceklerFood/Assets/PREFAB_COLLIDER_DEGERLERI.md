# 📋 Prefab Collider Değerleri - Hızlı Referans

Bu dosya, her prefab için collider ayarlarını içerir. Sprite boyutlarına göre hesaplanmış değerler.

---

## ⚠️ ÖNEMLİ NOT

Bu değerler **örnek** değerlerdir. Gerçek sprite boyutlarınıza göre ayarlamalısınız!

**Hesaplama Formülü:**
```
Gerçek Boyut = (Sprite Pixel Boyutu) / 100
Scale Çarpanı = colliderRadius / 0.3
Collider Size = Gerçek Boyut * Scale Çarpanı * 0.9
```

---

## 📦 BOXCOLLIDER2D - Değerler

### 1. Food_BurnedToast (ID: 0) - En Küçük

**FruitTypeSO Ayarları:**
```
id: 0
colliderRadius: 0.25
```

**BoxCollider2D Ayarları:**
```
Size: Sprite boyutuna göre hesapla
  - Örnek: Sprite 100x100 pixel ise → Size: (0.225, 0.225)
  - Formül: (Sprite Boyutu / 100) * 0.83 * 0.9
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

**Hızlı Hesaplama:**
- Sprite 100x100 → Size: (0.75, 0.75) veya (0.7, 0.7)
- Sprite 80x80 → Size: (0.6, 0.6) veya (0.55, 0.55)
- Sprite 120x120 → Size: (0.9, 0.9) veya (0.85, 0.85)

---

### 2. Food_CrispyToast (ID: 1)

**FruitTypeSO Ayarları:**
```
id: 1
colliderRadius: 0.35
```

**BoxCollider2D Ayarları:**
```
Size: Sprite boyutuna göre hesapla
  - Örnek: Sprite 100x100 pixel ise → Size: (0.315, 0.315)
  - Formül: (Sprite Boyutu / 100) * 1.17 * 0.9
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

**Hızlı Hesaplama:**
- Sprite 100x100 → Size: (1.05, 1.05) veya (1.0, 1.0)
- Sprite 80x80 → Size: (0.84, 0.84) veya (0.8, 0.8)
- Sprite 120x120 → Size: (1.26, 1.26) veya (1.2, 1.2)

---

### 3. Food_BananaBread (ID: 8) - Büyük

**FruitTypeSO Ayarları:**
```
id: 8
colliderRadius: 1.05
```

**BoxCollider2D Ayarları:**
```
Size: Sprite boyutuna göre hesapla
  - Örnek: Sprite 100x100 pixel ise → Size: (0.945, 0.945)
  - Formül: (Sprite Boyutu / 100) * 3.5 * 0.9
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

**Hızlı Hesaplama:**
- Sprite 100x100 → Size: (3.15, 3.15) veya (3.0, 3.0)
- Sprite 120x120 → Size: (3.78, 3.78) veya (3.6, 3.6)
- Sprite 150x150 → Size: (4.73, 4.73) veya (4.5, 4.5)

---

## 🥛 CAPSULECOLLIDER2D - Değerler

### 4. Food_BananaMilk (ID: 3)

**FruitTypeSO Ayarları:**
```
id: 3
colliderRadius: 0.55
```

**CapsuleCollider2D Ayarları:**
```
Size: Sprite boyutuna göre hesapla
  - X: (Sprite Genişliği / 100) * 1.83 * 0.9
  - Y: (Sprite Yüksekliği / 100) * 1.83 * 0.9
Direction: Vertical (sprite'a göre)
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

**Örnek Hesaplama:**
- Sprite 80x120 pixel:
  - X: (80 / 100) * 1.83 * 0.9 = 0.72 * 1.83 * 0.9 = **1.19**
  - Y: (120 / 100) * 1.83 * 0.9 = 1.2 * 1.83 * 0.9 = **1.98**
  - Size: **(1.2, 2.0)** (yuvarlanmış)

**Hızlı Ayarlar:**
- Sprite 80x120 → Size: (1.2, 2.0)
- Sprite 100x150 → Size: (1.5, 2.5)
- Sprite 60x100 → Size: (1.0, 1.7)

---

## 🔷 POLYGONCOLLIDER2D - Değerler

### 5. Food_BakedBanana (ID: 2)

**FruitTypeSO Ayarları:**
```
id: 2
colliderRadius: 0.45
```

**PolygonCollider2D Ayarları:**
```
Edit Collider ile sprite şekline göre ayarla
Collider sprite'ın %85-90'ı kadar olmalı
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

**Ayarlama:**
1. Prefab'ı aç
2. PolygonCollider2D → Edit Collider
3. Muz şekline göre noktaları ayarla
4. Collider sprite'ın kenarlarından biraz içeride olmalı

---

### 6. Food_BananaFrenchToast (ID: 4)

**FruitTypeSO Ayarları:**
```
id: 4
colliderRadius: 0.65
```

**PolygonCollider2D Ayarları:**
```
Edit Collider ile sprite şekline göre ayarla
Dikdörtgen ama köşeler yuvarlak
Collider sprite'ın %90'ı kadar olmalı
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

---

### 7. Food_EggCheeseSandwich (ID: 5)

**FruitTypeSO Ayarları:**
```
id: 5
colliderRadius: 0.75
```

**PolygonCollider2D Ayarları:**
```
Edit Collider ile sandviç şekline göre ayarla
Collider sprite'ın %90-95'i kadar olmalı
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

---

### 8. Food_EggSalamiSandwich (ID: 6)

**FruitTypeSO Ayarları:**
```
id: 6
colliderRadius: 0.85
```

**PolygonCollider2D Ayarları:**
```
Edit Collider ile sandviç şekline göre ayarla
Collider sprite'ın %90-95'i kadar olmalı
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

---

### 9. Food_EggCheeseSalamiSandwich (ID: 7) - En Büyük Sandviç

**FruitTypeSO Ayarları:**
```
id: 7
colliderRadius: 0.95
```

**PolygonCollider2D Ayarları:**
```
Edit Collider ile sandviç şekline göre ayarla
En büyük sandviç, detaylı shape gerekebilir
Collider sprite'ın %90-95'i kadar olmalı
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

---

### 10. Food_BananaPancakes (ID: 9) - En Büyük

**FruitTypeSO Ayarları:**
```
id: 9
colliderRadius: 1.15
```

**PolygonCollider2D Ayarları:**
```
Edit Collider ile pancake şekline göre ayarla
Yuvarlak ama tam değil, polygon ile daha iyi
Collider sprite'ın %90-95'i kadar olmalı
Offset: (0, 0)
Material: FruitBouncy
Is Trigger: ❌
```

---

## 🎯 HIZLI AYARLAMA YÖNTEMİ

### BoxCollider2D İçin:

1. **Prefab'ı aç**
2. **Sprite Renderer** → Sprite'ı seç
3. Sprite'ın **pixel boyutunu** gör (Inspector'da)
4. **Basit formül:** 
   ```
   Size = (Pixel Boyutu / 100) * Scale Çarpanı * 0.9
   ```
5. **Scale Çarpanları:**
   - ID 0: 0.83
   - ID 1: 1.17
   - ID 8: 3.5

### CapsuleCollider2D İçin:

1. Sprite'ın **genişlik ve yüksekliğini** gör
2. **Formül:**
   ```
   X = (Genişlik / 100) * 1.83 * 0.9
   Y = (Yükseklik / 100) * 1.83 * 0.9
   ```

### PolygonCollider2D İçin:

1. **Edit Collider** ile görsel olarak ayarla
2. Collider sprite'ın **%85-95'i** kadar olmalı
3. Scene view'da yeşil çizgileri kontrol et

---

## ✅ TEST KONTROLÜ

### Her Prefab İçin:

1. Prefab'ı Scene'e sürükle
2. **Play** moduna geç
3. Sprite ve collider'ı görsel olarak kontrol et:
   - Collider sprite'ın içinde mi?
   - Collider sprite'a çok yakın mı?
   - Collider sprite'dan taşıyor mu?
4. İki aynı sprite'ı birbirine yaklaştır:
   - Çarpışma doğru çalışıyor mu?
   - Merge işlemi tetikleniyor mu?

---

## 📊 ÖZET TABLO

| ID | Prefab | Collider Tipi | Size Çarpanı | Önerilen Size |
|----|--------|---------------|-------------|---------------|
| 0 | Burned Toast | Box | 0.83 | Sprite * 0.75 |
| 1 | Crispy Toast | Box | 1.17 | Sprite * 1.05 |
| 2 | Baked Banana | Polygon | 1.50 | Sprite * 0.90 |
| 3 | Banana Milk | Capsule | 1.83 | Sprite * 0.90 |
| 4 | French Toast | Polygon | 2.17 | Sprite * 0.90 |
| 5 | Egg Cheese | Polygon | 2.50 | Sprite * 0.90 |
| 6 | Egg Salami | Polygon | 2.83 | Sprite * 0.90 |
| 7 | Full Sandwich | Polygon | 3.17 | Sprite * 0.90 |
| 8 | Banana Bread | Box | 3.50 | Sprite * 0.90 |
| 9 | Pancakes | Polygon | 3.83 | Sprite * 0.90 |

**Not:** Size Çarpanı = colliderRadius / 0.3

---

**İyi çalışmalar! 🎮**
