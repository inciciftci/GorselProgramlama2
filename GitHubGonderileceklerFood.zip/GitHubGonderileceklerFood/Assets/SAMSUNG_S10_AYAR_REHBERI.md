# 📱 Samsung Galaxy S10 - Sprite ve Collider Ayar Rehberi

Bu rehber, Samsung Galaxy S10 telefonunda ergonomik bir görüntü için sprite ve collider ayarlarını içerir.

---

## 📐 Samsung Galaxy S10 Özellikleri

- **Ekran Çözünürlüğü:** 1440 x 3040 piksel
- **Aspect Ratio:** 19:9 (yaklaşık 2.1:1)
- **Ekran Boyutu:** 6.1 inç
- **Piksel Yoğunluğu:** ~550 ppi

---

## 🎯 HEDEF: Ergonomic Görüntü

- En küçük sprite (ID 0) ekranda rahat görünsün
- En büyük sprite (ID 9) ekrana sığsın
- Tüm sprite'lar dokunma için uygun boyutta olsun
- Collider'lar sprite boyutlarına göre otomatik ayarlansın

---

## 1️⃣ SPRITE IMPORT AYARLARI

### Tüm Sprite'lar İçin Ortak Ayarlar:

1. **Project** penceresinde `Assets/Sprites` klasörüne git
2. **Tüm sprite'ları seç** (Ctrl+A veya Cmd+A)
3. **Inspector** penceresinde şu ayarları yap:

```
Texture Type: Sprite (2D and UI)
Sprite Mode: Single
Pixels Per Unit: 100
Filter Mode: Bilinear (veya Point - pixel art için)
Compression: None (veya Low)
Max Size: 2048
```

**ÖNEMLİ:** Tüm sprite'lar için **Pixels Per Unit: 100** kullanılacak. Bu sayede sprite boyutları tutarlı olacak.

---

## 2️⃣ KAMERA AYARLARI

### Main Camera Ayarları:

1. Hierarchy'de **Main Camera** seç
2. Inspector'da şu ayarları yap:

```
Projection: Orthographic
Size: 10 (Samsung S10 için optimize edilmiş)
Position: (0, 4, -10)
Background: Koyu renk (#1a1a2e gibi)
```

**Size: 10** değeri şu anlama gelir:
- Ekranın yüksekliği 20 Unity unit
- En küçük sprite (ID 0) yaklaşık 0.5-0.7 unit
- En büyük sprite (ID 9) yaklaşık 1.5-2.0 unit

---

## 3️⃣ CANVAS AYARLARI

### Canvas Ayarları (UI için):

1. Hierarchy'de **Canvas** seç
2. Inspector'da şu ayarları yap:

```
Render Mode: Screen Space - Overlay
UI Scale Mode: Scale With Screen Size
Reference Resolution: 1080 x 1920
Match: 0.5 (Width ve Height arasında denge)
```

**Not:** Samsung S10'ın gerçek çözünürlüğü 1440x3040 ama Unity'de 1080x1920 referans alınır (daha yaygın).

---

## 4️⃣ SPRITE SCALE SİSTEMİ (Fruit.cs'de Otomatik)

Fruit.cs script'i zaten sprite'ları otomatik olarak scale ediyor. Ancak daha iyi kontrol için şu ayarları yapabilirsin:

### FruitTypeSO'da colliderRadius Değerleri:

| ID | Yiyecek | colliderRadius | Gerçek Scale |
|----|---------|----------------|--------------|
| 0 | Burned Toast | **0.25** | 0.83x (en küçük) |
| 1 | Crispy Toast | **0.35** | 1.17x |
| 2 | Baked Banana | **0.45** | 1.50x |
| 3 | Banana Milk | **0.55** | 1.83x |
| 4 | Banana French Toast | **0.65** | 2.17x |
| 5 | Egg Cheese Sandwich | **0.75** | 2.50x |
| 6 | Egg Salami Sandwich | **0.85** | 2.83x |
| 7 | Full Sandwich | **0.95** | 3.17x |
| 8 | Banana Bread | **1.05** | 3.50x |
| 9 | Banana Pancakes | **1.15** | 3.83x (en büyük) |

**Formül:** `scaleMultiplier = colliderRadius / 0.3`

Bu değerler sprite'ların ekranda görünen boyutlarını kontrol eder.

---

## 5️⃣ PREFAB SCALE AYARLARI

### Her Prefab İçin:

1. **Prefab'ı aç** (örn: `Food_BurnedToast`)
2. **Transform** component'inde:
   ```
   Scale: (1, 1, 1) - Script otomatik ayarlayacak
   ```
3. **Sprite Renderer** component'inde sprite'ı kontrol et
4. Script otomatik olarak scale'i ayarlayacak

**ÖNEMLİ:** Prefab'larda Transform Scale'i (1, 1, 1) olarak bırak. Script otomatik ayarlayacak.

---

## 6️⃣ COLLIDER AYARLARI

### BoxCollider2D Ayarları:

#### Burned Toast (ID: 0) - En Küçük
```
Size: Sprite boyutunun %80-90'ı
Offset: (0, 0)
Material: FruitBouncy
```

**Hesaplama:**
- Sprite boyutu örneğin 100x100 pixel ise
- Pixels Per Unit: 100
- Gerçek boyut: 1x1 unit
- Scale: 0.83x
- Collider Size: (0.83, 0.83) veya biraz küçük (0.75, 0.75)

#### Crispy Toast (ID: 1)
```
Size: Sprite boyutunun %85-90'ı
Offset: (0, 0)
Material: FruitBouncy
```

#### Banana Bread (ID: 8) - Büyük
```
Size: Sprite boyutunun %90-95'ı
Offset: (0, 0)
Material: FruitBouncy
```

**Genel Kural:** BoxCollider2D için Size, sprite'ın gerçek boyutunun %80-95'i arasında olmalı.

---

### CapsuleCollider2D Ayarları:

#### Banana Milk (ID: 3)
```
Size: Sprite boyutuna göre
  - X: Sprite genişliği * scale
  - Y: Sprite yüksekliği * scale
Direction: Vertical (sprite'a göre)
Offset: (0, 0)
Material: FruitBouncy
```

**Örnek Hesaplama:**
- Sprite: 80x120 pixel
- Pixels Per Unit: 100
- Gerçek boyut: 0.8x1.2 unit
- Scale: 1.83x
- Collider Size: (0.8 * 1.83, 1.2 * 1.83) = (1.46, 2.20)
- Ama biraz küçük tut: (1.3, 2.0)

---

### PolygonCollider2D Ayarları:

#### Tüm PolygonCollider2D'ler İçin:

1. **Prefab'ı aç**
2. **PolygonCollider2D** → **Edit Collider**
3. Sprite şekline göre noktaları ayarla
4. Collider sprite'ın **%85-95'i** kadar olmalı (kenarlardan biraz içeride)

**Özel Notlar:**

| Yiyecek | Özel Ayarlar |
|---------|--------------|
| Baked Banana (ID: 2) | Muz şekline göre, biraz küçük |
| Banana French Toast (ID: 4) | Dikdörtgen ama köşeler yuvarlak |
| Egg Cheese Sandwich (ID: 5) | Sandviç şekline göre |
| Egg Salami Sandwich (ID: 6) | Sandviç şekline göre |
| Full Sandwich (ID: 7) | En büyük, detaylı shape |
| Banana Pancakes (ID: 9) | Yuvarlak ama tam değil |

---

## 7️⃣ COLLIDER SIZE HESAPLAMA FORMÜLÜ

### Genel Formül:

```
Gerçek Sprite Boyutu = (Sprite Pixel Boyutu) / (Pixels Per Unit)
Scale Çarpanı = colliderRadius / 0.3
Scaled Boyut = Gerçek Sprite Boyutu * Scale Çarpanı
Collider Size = Scaled Boyut * 0.85-0.95 (kenarlardan biraz küçük)
```

### Örnek: Burned Toast (ID: 0)

```
Sprite: 100x100 pixel
Pixels Per Unit: 100
Gerçek Boyut: 1x1 unit
colliderRadius: 0.25
Scale Çarpanı: 0.25 / 0.3 = 0.83
Scaled Boyut: 1 * 0.83 = 0.83 unit
Collider Size: 0.83 * 0.9 = 0.75 unit
```

**BoxCollider2D Size:** (0.75, 0.75)

---

## 8️⃣ ADIM ADIM COLLIDER AYARLAMA

### BoxCollider2D İçin:

1. **Prefab'ı aç** (örn: `Food_BurnedToast`)
2. **Sprite Renderer** → Sprite'ı seç
3. Sprite'ın **pixel boyutunu** gör (örn: 100x100)
4. **Gerçek boyutu hesapla:** Pixel Boyutu / 100
5. **Scale çarpanını hesapla:** colliderRadius / 0.3
6. **Scaled boyutu hesapla:** Gerçek Boyut * Scale Çarpanı
7. **Collider Size'ı ayarla:** Scaled Boyut * 0.9
8. **BoxCollider2D** → Size'a bu değeri gir

### CapsuleCollider2D İçin:

1. **Prefab'ı aç** (`Food_BananaMilk`)
2. Sprite boyutunu hesapla (yukarıdaki gibi)
3. **Size** alanına:
   - X: Genişlik * Scale Çarpanı * 0.9
   - Y: Yükseklik * Scale Çarpanı * 0.9
4. **Direction:** Sprite'a göre (genellikle Vertical)

### PolygonCollider2D İçin:

1. **Prefab'ı aç**
2. **PolygonCollider2D** → **Edit Collider**
3. Sprite şekline göre noktaları ayarla
4. Collider sprite'ın **%85-90'ı** kadar olmalı
5. Scene view'da görsel olarak kontrol et

---

## 9️⃣ TEST VE AYARLAMA

### Test Adımları:

1. **Game View**'da **Aspect Ratio**'yu **9:19** yap (Samsung S10)
2. **Play** moduna geç
3. En küçük sprite'ı (Burned Toast) kontrol et:
   - Ekranda rahat görünüyor mu?
   - Dokunma için yeterince büyük mü?
4. En büyük sprite'ı (Banana Pancakes) kontrol et:
   - Ekrana sığıyor mu?
   - Çok büyük mü?
5. Collider'ları test et:
   - Sprite'lar birbirine değiyor mu?
   - Merge çalışıyor mu?

### Ayarlama:

**Sprite'lar çok küçükse:**
- Kamera Size'ı azalt (örn: 9 veya 8.5)
- Veya colliderRadius değerlerini artır

**Sprite'lar çok büyükse:**
- Kamera Size'ı artır (örn: 11 veya 12)
- Veya colliderRadius değerlerini azalt

**Collider'lar sprite'dan taşıyorsa:**
- Collider Size'ı küçült (%85 yerine %80)

**Collider'lar sprite'dan çok küçükse:**
- Collider Size'ı büyüt (%85 yerine %90-95)

---

## ✅ KONTROL LİSTESİ

- [ ] Tüm sprite'lar için Pixels Per Unit: 100
- [ ] Kamera Size: 10
- [ ] Canvas Reference Resolution: 1080x1920
- [ ] Tüm FruitType SO'larda colliderRadius değerleri ayarlandı
- [ ] BoxCollider2D'ler ayarlandı (3 prefab)
- [ ] CapsuleCollider2D ayarlandı (1 prefab)
- [ ] PolygonCollider2D'ler ayarlandı (6 prefab)
- [ ] Tüm collider'lara FruitBouncy material eklendi
- [ ] Game View'da 9:19 aspect ratio ile test edildi
- [ ] Sprite boyutları ergonomik görünüyor
- [ ] Collider'lar sprite'lara uygun

---

## 📊 ÖNERİLEN DEĞERLER TABLOSU

### Kamera ve Canvas:
| Ayar | Değer |
|------|-------|
| Camera Size | 10 |
| Canvas Ref Resolution | 1080 x 1920 |
| Canvas Match | 0.5 |

### Sprite Import:
| Ayar | Değer |
|------|-------|
| Pixels Per Unit | 100 |
| Filter Mode | Bilinear |
| Compression | None/Low |

### Collider Size Çarpanları:
| Collider Tipi | Size Çarpanı |
|---------------|--------------|
| BoxCollider2D | 0.85-0.90 |
| CapsuleCollider2D | 0.85-0.90 |
| PolygonCollider2D | 0.85-0.95 |

---

## 🎮 SONUÇ

Bu ayarlarla Samsung Galaxy S10'da:
- ✅ En küçük sprite rahat görünecek
- ✅ En büyük sprite ekrana sığacak
- ✅ Tüm sprite'lar dokunma için uygun boyutta olacak
- ✅ Collider'lar sprite'lara mükemmel uyacak
- ✅ Ergonomic bir görüntü elde edilecek

**İyi çalışmalar! 📱🎮**
