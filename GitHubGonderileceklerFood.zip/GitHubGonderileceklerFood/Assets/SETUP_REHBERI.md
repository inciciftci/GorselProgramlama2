# 🎮 FoodMerge - Unity Editor Kurulum Rehberi

Bu rehber, Unity Editor'da yapman gereken adımları içerir.

---

## 📋 İÇİNDEKİLER

1. [Layer ve Tag Ayarları](#1-layer-ve-tag-ayarları)
2. [Physics 2D Ayarları](#2-physics-2d-ayarları)
3. [Physics Material 2D Oluşturma](#3-physics-material-2d-oluşturma)
4. [FruitType ScriptableObject'leri Oluşturma](#4-fruittype-scriptableobjectleri-oluşturma)
5. [FruitDatabase Oluşturma](#5-fruitdatabase-oluşturma)
6. [Fruit Prefab Oluşturma](#6-fruit-prefab-oluşturma)
7. [Sahne Kurulumu](#7-sahne-kurulumu)
8. [UI Kurulumu](#8-ui-kurulumu)
9. [Referansları Bağlama](#9-referansları-bağlama)

---

## 1. LAYER VE TAG AYARLARI

### 1.1 Layer Oluşturma
1. **Edit > Project Settings > Tags and Layers** aç
2. **Layers** bölümünde şu layer'ları ekle:

| Layer No | Layer Adı |
|----------|-----------|
| 6 | `Fruit` |
| 7 | `Wall` |
| 8 | `FailLine` |

**Adım Adım:**
- Boş bir **User Layer** satırına tıkla (Layer 6, 7, 8)
- İsmi yaz ve Enter'a bas

---

## 2. PHYSICS 2D AYARLARI

### 2.1 Physics 2D Settings
1. **Edit > Project Settings > Physics 2D** aç
2. Şu değerleri ayarla:

```
Gravity: X=0, Y=-15
Default Material: None
Velocity Iterations: 8
Position Iterations: 3
```

### 2.2 Layer Collision Matrix
**Physics 2D** ayarlarının altındaki **Layer Collision Matrix**'te:

| | Fruit | Wall | FailLine |
|---|:---:|:---:|:---:|
| **Fruit** | ✅ | ✅ | ✅ |
| **Wall** | ✅ | ❌ | ❌ |
| **FailLine** | ✅ | ❌ | ❌ |

✅ = Çarpışma olacak, ❌ = Çarpışma yok

---

## 3. PHYSICS MATERIAL 2D OLUŞTURMA

### 3.1 FruitBouncy Material
1. **Assets/Materials** klasörüne sağ tık
2. **Create > 2D > Physics Material 2D**
3. İsim: `FruitBouncy`
4. Inspector'da ayarlar:
   ```
   Friction: 0.3
   Bounciness: 0.2
   ```

### 3.2 WallFriction Material
1. Aynı şekilde `WallFriction` oluştur:
   ```
   Friction: 0.6
   Bounciness: 0.1
   ```

---

## 4. FRUITTYPE SCRIPTABLEOBJECT'LERİ OLUŞTURMA

### 4.1 FruitType'ları Oluştur
**Assets/ScriptableObjects/FruitTypes** klasörüne git ve her biri için:

1. Sağ tık → **Create > FruitMerge > FruitType**
2. İsim ve ayarları aşağıdaki tabloya göre yap:

| ID | İsim | Sprite | displayName | colliderRadius | scoreValue | nextType |
|----|------|--------|-------------|----------------|------------|----------|
| 0 | `Food_BurnedToast` | Burned_Toast.png | Burned Toast | 0.25 | 10 | Food_CrispyToast |
| 1 | `Food_CrispyToast` | Crispy_Toast.png | Crispy Toast | 0.35 | 20 | Food_BakedBanana |
| 2 | `Food_BakedBanana` | Baked_Banana.png | Baked Banana | 0.45 | 40 | Food_BananaMilk |
| 3 | `Food_BananaMilk` | Banana_Milk.png | Banana Milk | 0.55 | 80 | Food_BananaFrenchToast |
| 4 | `Food_BananaFrenchToast` | Banana_French_Toast.png | Banana French Toast | 0.65 | 160 | Food_EggCheeseSandwich |
| 5 | `Food_EggCheeseSandwich` | Egg_Cheese_Sandwich.png | Egg Cheese Sandwich | 0.75 | 320 | Food_EggSalamiSandwich |
| 6 | `Food_EggSalamiSandwich` | Egg_Salami_Sandwich.png | Egg Salami Sandwich | 0.85 | 640 | Food_EggCheeseSalamiSandwich |
| 7 | `Food_EggCheeseSalamiSandwich` | Egg_Cheese_Salami_Sandwich.png | Full Sandwich | 0.95 | 1280 | Food_BananaBread |
| 8 | `Food_BananaBread` | Banana_Bread.png | Banana Bread | 1.05 | 2560 | Food_BananaPancakes |
| 9 | `Food_BananaPancakes` | Banana_Pancakes.png | Banana Pancakes | 1.15 | 5120 | **null** |

**Önemli:**
- Her FruitType'ın **sprite** alanına ilgili sprite'ı sürükle
- **nextType** alanına bir sonraki FruitType'ı sürükle (son olan null kalır)
- **prefab** alanını şimdilik boş bırak (sonra dolduracağız)

---

## 5. FRUITTYPE SCRIPTABLEOBJECT'LERİ OLUŞTURMA

### 5.1 FruitDatabase Oluştur
1. **Assets/ScriptableObjects** klasörüne sağ tık
2. **Create > FruitMerge > FruitDatabase**
3. İsim: `FruitDatabase`

### 5.2 Types Listesini Doldur
1. `FruitDatabase` asset'ini seç
2. Inspector'da **Types** listesine sırayla tüm FruitType'ları ekle:
   - **Size**: 10
   - Element 0: `Food_BurnedToast`
   - Element 1: `Food_CrispyToast`
   - Element 2: `Food_BakedBanana`
   - Element 3: `Food_BananaMilk`
   - Element 4: `Food_BananaFrenchToast`
   - Element 5: `Food_EggCheeseSandwich`
   - Element 6: `Food_EggSalamiSandwich`
   - Element 7: `Food_EggCheeseSalamiSandwich`
   - Element 8: `Food_BananaBread`
   - Element 9: `Food_BananaPancakes`

### 5.3 Max Spawn Type ID Ayarla
- **Max Spawn Type ID**: `2` (Sadece ID 0, 1, 2 spawn olur - yani Burned Toast, Crispy Toast, Baked Banana)

---

## 6. FRUIT PREFAB OLUŞTURMA

### 6.1 Fruit_Template Oluştur
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `Fruit_Template`
3. Component'leri ekle:
   - **Sprite Renderer**
   - **Rigidbody2D**
   - **CircleCollider2D**
   - **Fruit** (script)

### 6.2 Rigidbody2D Ayarları
**Rigidbody2D** component'inde:
```
Body Type: Dynamic
Material: FruitBouncy (Materials klasöründeki)
Simulated: ✅
Use Auto Mass: ❌
Mass: 0.5
Linear Drag: 0.5
Angular Drag: 0.5
Gravity Scale: 2
Collision Detection: Continuous
Sleeping Mode: Start Awake
Interpolate: Interpolate
Constraints:
  - Freeze Rotation: ✅
```

### 6.3 CircleCollider2D Ayarları
**CircleCollider2D** component'inde:
```
Is Trigger: ❌
Used By Effector: ❌
Material: FruitBouncy
Offset: (0, 0)
Radius: 0.5 (bu otomatik ayarlanacak, şimdilik böyle bırak)
```

### 6.4 Layer Ayarla
- Objenin **Layer**'ını `Fruit` yap

### 6.5 Her FruitType İçin Ayrı Prefab Oluştur
**ÖNEMLİ:** Her FruitType için ayrı prefab oluşturmalısın! Bu sayede:
- Her yiyecek için farklı collider tipi kullanabilirsin (Circle, Box, Polygon, vb.)
- Her prefab'ın kendi özel ayarları olabilir
- Daha esnek ve özelleştirilebilir bir sistem elde edersin

**Adım Adım:**

1. **İlk Prefab'ı Oluştur:**
   - Hierarchy'de `Fruit_Template` objesini seç
   - **Sprite Renderer** component'ine ilk sprite'ı ekle (Burned_Toast)
   - Collider tipini seç:
     - **CircleCollider2D** (yuvarlak yiyecekler için)
     - **BoxCollider2D** (kare/dikdörtgen yiyecekler için)
     - **PolygonCollider2D** (özel şekiller için)
   - Collider ayarlarını yap (size, offset, vb.)
   - **Assets/Prefabs/Fruits** klasörüne sürükle
   - İsim: `Food_BurnedToast`
   - Hierarchy'deki orijinali sil

2. **Diğer Prefab'ları Oluştur:**
   - Her prefab için yukarıdaki adımları tekrarla
   - Her prefab'a ilgili sprite'ı ekle
   - Her prefab için uygun collider tipini seç ve ayarla
   - Prefab isimleri:
     - `Food_BurnedToast`
     - `Food_CrispyToast`
     - `Food_BakedBanana`
     - `Food_BananaMilk`
     - `Food_BananaFrenchToast`
     - `Food_EggCheeseSandwich`
     - `Food_EggSalamiSandwich`
     - `Food_EggCheeseSalamiSandwich`
     - `Food_BananaBread`
     - `Food_BananaPancakes`

### 6.6 Her FruitType'a Prefab Bağla
Her FruitType SO'yu aç ve:
1. **prefab** alanına ilgili prefab'ı sürükle (örn: `Food_BurnedToast` → `Food_BurnedToast` prefab'ı)
2. Tüm 10 FruitType için tekrar et

**Not:** 
- Eğer prefab'da **CircleCollider2D** varsa, script otomatik olarak radius'u ayarlayacak
- Eğer **BoxCollider2D** veya **PolygonCollider2D** varsa, collider ayarlarını prefab'da manuel yapmalısın
- Her prefab'da mutlaka bir **Collider2D** component'i olmalı!

---

## 7. SAHNE KURULUMU

### 7.1 Yeni Sahne Oluşturma
1. **File > New Scene**
2. **File > Save As** > `Assets/Scenes/GameScene.unity`

### 7.2 Kamera Ayarları
**Main Camera** seç:
```
Position: (0, 4, -10)
Projection: Orthographic
Size: 12
Background: Koyu renk (#1a1a2e gibi)
```

### 7.3 Duvarlar Oluşturma

#### Sol Duvar
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `Wall_Left`
3. Component ekle: **Box Collider 2D**
4. Ayarlar:
   ```
   Position: (-7, 0, 0)
   Box Collider 2D:
     - Size: (1, 20)
     - Material: WallFriction
   Layer: Wall
   ```

#### Sağ Duvar
1. `Wall_Left`'i kopyala (Ctrl+D)
2. İsim: `Wall_Right`
3. Position: `(7, 0, 0)`

#### Zemin
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `Floor`
3. Component ekle: **Box Collider 2D**
4. Ayarlar:
   ```
   Position: (0, -8, 0)
   Box Collider 2D:
     - Size: (14, 1)
     - Material: WallFriction
   Layer: Wall
   ```

### 7.4 Environment Parent Oluşturma
1. Tüm duvarları ve zemini seç
2. Hierarchy'de sağ tık → **Create Empty Parent**
3. Parent'ın ismi: `Environment`

### 7.5 Fail Line Oluşturma
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `FailLine`
3. Component ekle: **Box Collider 2D**
4. Component ekle: **FailLineManager** (script)
5. Ayarlar:
   ```
   Position: (0, 7, 0)
   Box Collider 2D:
     - Is Trigger: ✅
     - Size: (14, 2)
   Layer: FailLine
   FailLineManager:
     - Grace Time: 1.0
   ```

### 7.6 Manager Objects Oluşturma

#### GameManager
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `GameManager`
3. Script ekle: **GameManager**

#### MergeSystem
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `MergeSystem`
3. Script ekle: **MergeSystem**

#### PoolManager
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `PoolManager`
3. Script ekle: **PoolManager**

#### ScoreManager
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `ScoreManager`
3. Script ekle: **ScoreManager**

#### FruitSpawner
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `FruitSpawner`
3. Script ekle: **FruitSpawner**
4. Inspector'da ayarlar:
   ```
   Spawn Y: 8
   Min X: -6
   Max X: 6
   Preview Offset Y: 0.5
   ```

#### SpawnQueueManager
1. Hierarchy'de sağ tık → **Create Empty**
2. İsim: `SpawnQueueManager`
3. Script ekle: **SpawnQueueManager**

### 7.7 Managers Parent Oluşturma
1. Tüm manager objelerini seç
2. Hierarchy'de sağ tık → **Create Empty Parent**
3. Parent'ın ismi: `Managers`

---

## 8. UI KURULUMU

### 8.1 Canvas Oluşturma
1. Hierarchy'de sağ tık → **UI > Canvas**
2. Canvas ayarları:
   ```
   Render Mode: Screen Space - Overlay
   UI Scale Mode: Scale With Screen Size
   Reference Resolution: 1080 x 1920
   Match: 0.5
   ```

### 8.2 Score Text
1. Canvas'a sağ tık → **UI > Text - TextMeshPro**
2. İsim: `ScoreText`
3. Ayarlar:
   ```
   Anchor: Top Left
   Position: (150, -50)
   Size: (200, 50)
   Text: "Score: 0"
   Font Size: 36
   Color: White
   ```

### 8.3 High Score Text
1. Canvas'a sağ tık → **UI > Text - TextMeshPro**
2. İsim: `HighScoreText`
3. Ayarlar:
   ```
   Anchor: Top Right
   Position: (-150, -50)
   Size: (200, 50)
   Text: "Best: 0"
   Font Size: 28
   Color: Gold/Yellow
   ```

### 8.4 Next Fruit Preview
1. Canvas'a sağ tık → **UI > Image**
2. İsim: `NextFruitImage`
3. Ayarlar:
   ```
   Anchor: Top Right
   Position: (-80, -150)
   Size: (80, 80)
   ```

### 8.5 Game Over Panel
1. Canvas'a sağ tık → **UI > Panel**
2. İsim: `GameOverPanel`
3. Image Color: `(0, 0, 0, 0.8)` (yarı saydam siyah)
4. **Canvas Group** component ekle
5. İçine:
   - **TextMeshPro** - "GAME OVER!" (GameOverTitleText)
   - **TextMeshPro** - "Score: 0" (FinalScoreText)
   - **Button** - "Restart" (GameOverRestartButton)

### 8.6 UIHud Setup
1. Canvas'a **UIHud** script'i ekle
2. Inspector'da referansları bağla:
   - Score Manager: `ScoreManager`
   - Spawn Queue Manager: `SpawnQueueManager`
   - Game Manager: `GameManager`
   - Score Text: `ScoreText`
   - High Score Text: `HighScoreText`
   - Next Fruit Image: `NextFruitImage`
   - Game Over Panel: `GameOverPanel`
   - Game Over Title Text: `GameOverTitleText`
   - Final Score Text: `FinalScoreText`
   - Game Over Restart Button: `GameOverRestartButton`

---

## 9. REFERANSLARI BAĞLAMA

### 9.1 GameManager Referansları
`GameManager` objesini seç ve Inspector'da:
| Alan | Değer |
|------|-------|
| Fruit Database | FruitDatabase (SO) |
| Pool Manager | PoolManager |
| Merge System | MergeSystem |
| Spawn Queue Manager | SpawnQueueManager |
| Fruit Spawner | FruitSpawner |
| Score Manager | ScoreManager |
| Fail Line Manager | FailLine |
| UI Hud | Canvas (UIHud script'li) |

### 9.2 MergeSystem Referansları
| Alan | Değer |
|------|-------|
| Fruit Database | FruitDatabase (SO) |
| Pool Manager | PoolManager |
| Score Manager | ScoreManager |

### 9.3 FruitSpawner Referansları
| Alan | Değer |
|------|-------|
| Pool Manager | PoolManager |
| Spawn Queue Manager | SpawnQueueManager |

### 9.4 SpawnQueueManager Referansları
| Alan | Değer |
|------|-------|
| Fruit Database | FruitDatabase (SO) |

---

## ✅ KONTROL LİSTESİ

- [ ] Tüm Layer'lar oluşturuldu (Fruit, Wall, FailLine)
- [ ] Physics 2D Layer Matrix ayarlandı
- [ ] Tüm script'ler compile oluyor
- [ ] FruitDatabase içinde 10 FruitType var
- [ ] Her FruitType'ın sprite ve prefab'ı bağlı
- [ ] NextType zincirleri doğru (0→1→2→...→9→null)
- [ ] Tüm Manager referansları bağlı
- [ ] UI referansları bağlı
- [ ] Duvarlar ve zemin Wall layer'ında
- [ ] FailLine, FailLine layer'ında
- [ ] GameOverPanel başlangıçta kapalı

---

## 🎮 TEST ETME

1. **Play** butonuna bas
2. Ekranda bir yiyecek görünmeli
3. Mouse ile sürükleyip bırakabilmelisin
4. Aynı tip yiyecekler birleşmeli
5. Skor artmalı
6. Fail line'da 1 saniye bekleyince Game Over olmalı

---

## 🔧 SORUN GİDERME

### "MergeSystem.Instance null" hatası
- Sahnede `MergeSystem` objesi olduğundan emin ol

### Yiyecekler birleşmiyor
- Her iki yiyeceğin de aynı `id`'ye sahip olduğunu kontrol et
- `nextType` bağlı mı kontrol et

### Skor güncellenmiyor
- `ScoreManager` referansı `MergeSystem`'da bağlı mı?
- `UIHud`'da `ScoreManager` referansı bağlı mı?

### Game Over çalışmıyor
- `FailLine` objesi `FailLine` layer'ında mı?
- `BoxCollider2D` trigger olarak işaretli mi?
- `GameManager`'da `FailLineManager` referansı bağlı mı?

---

**İyi oyunlar! 🎮**
