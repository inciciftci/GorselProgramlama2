using UnityEngine;

namespace FruitMerge.Data
{
    [CreateAssetMenu(fileName = "NewFruitType", menuName = "FruitMerge/FruitType")]
    public class FruitTypeSO : ScriptableObject
    {
        [Header("Identification")]
        [Tooltip("Benzersiz meyve ID'si (0'dan baslar)")]
        public int id;

        [Tooltip("Gorunen isim")]
        public string displayName;

        [Header("Visual")]
        [Tooltip("Meyve sprite'i")]
        public Sprite sprite;

        [Tooltip("Meyve prefab'i (Fruit component icermeli)")]
        public GameObject prefab;

        [Header("Merge Settings")]
        [Tooltip("Bu meyve merge oldugunda olusacak bir sonraki tip (null = maksimum level)")]
        public FruitTypeSO nextType;

        [Header("Game Values")]
        [Tooltip("Bu meyve olustugunda verilecek skor")]
        public int scoreValue = 10;

        [Header("Physics")]
        [Tooltip("Collider radius (CircleCollider2D icin)")]
        public float colliderRadius = 0.5f;

        [Tooltip("Ozel physics material (opsiyonel)")]
        public PhysicsMaterial2D optionalMaterial;

        public bool HasNextType => nextType != null;

        public override string ToString()
        {
            return $"{displayName} (ID:{id})";
        }
    }
}
