using UnityEngine;
using System.Collections;
using FruitMerge.Core;
using FruitMerge.Data;
using FruitMerge.UI;

namespace FruitMerge.Managers
{
    public class GameManager : MonoBehaviour
    {
        // Singleton
        public static GameManager Instance { get; private set; }

        [Header("References")]
        [SerializeField] private FruitDatabaseSO fruitDatabase;
        [SerializeField] private PoolManager poolManager;
        [SerializeField] private MergeSystem mergeSystem;
        [SerializeField] private SpawnQueueManager spawnQueueManager;
        [SerializeField] private FruitSpawner fruitSpawner;
        [SerializeField] private ScoreManager scoreManager;
        [SerializeField] private FailLineManager failLineManager;
        [SerializeField] private UIHud uiHud;
        [SerializeField] private GameObject gameOverPanel;

        [Header("Game State")]
        [SerializeField] private GameState currentState = GameState.MainMenu;

        public enum GameState
        {
            MainMenu,
            Playing,
            GameOver,
            Paused
        }

        public System.Action<GameState> OnGameStateChanged;
        public GameState CurrentState => currentState;

        private void Awake()
        {
            // Singleton kurulumu
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[GameManager] Birden fazla instance tespit edildi, yok ediliyor.");
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (fruitDatabase != null)
            {
                fruitDatabase.Initialize();
            }

            if (mergeSystem != null)
            {
                mergeSystem.OnMergeCompleted += HandleMergeCompleted;
            }

            Debug.Log("[GameManager] Singleton kuruldu.");
        }

        private void OnEnable()
        {
            // OnEnable'da da subscribe et (GameObject disable/enable edilirse event sıfırlanabilir)
            if (Instance == this)
            {
                SubscribeToFailLineManager();
            }
        }

        private void Start()
        {
            Debug.Log("[GameManager] Start() çağrıldı.");
            
            try
            {
                // FailLineManager'a subscribe et (Start'ta yapıyoruz çünkü referanslar hazır olmalı)
                SubscribeToFailLineManager();
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[GameManager] SubscribeToFailLineManager hatası: {e.Message}\n{e.StackTrace}");
            }
            
            WarmupPools();
            StartGame();
        }

        private void SubscribeToFailLineManager()
        {
            Debug.Log("[GameManager] SubscribeToFailLineManager çağrıldı.");
            
            // ÖNEMLİ: Tüm aktif FailLineManager instance'larına subscribe ol
            // Çünkü sahne'de birden fazla instance olabilir ve hangisinin trigger edeceği belli değil
            FailLineManager[] allFailLineManagers = FindObjectsByType<FailLineManager>(FindObjectsSortMode.None);
            
            if (allFailLineManagers == null || allFailLineManagers.Length == 0)
            {
                Debug.LogError("[GameManager] FailLineManager bulunamadı! Game over tetiklenmeyecek!");
                return;
            }
            
            Debug.LogWarning($"[GameManager] Sahne'de {allFailLineManagers.Length} adet FailLineManager bulundu. Hepsine subscribe olunuyor...");
            
            int subscribedCount = 0;
            foreach (var flm in allFailLineManagers)
            {
                if (flm == null) continue;
                
                bool isActive = flm.gameObject.activeInHierarchy;
                Debug.Log($"[GameManager] FailLineManager bulundu: {flm.gameObject.name} (Instance ID: {flm.GetInstanceID()}, Active: {isActive})");
                
                // Sadece aktif olanlara subscribe ol (ama hepsine subscribe olmak daha güvenli)
                try
                {
                    flm.SubscribeToGameOver(HandleGameOver);
                    subscribedCount++;
                    Debug.Log($"[GameManager] ✓ {flm.gameObject.name} instance'ına subscribe edildi.");
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"[GameManager] {flm.gameObject.name} instance'ına subscribe edilirken hata: {e.Message}");
                }
            }
            
            // İlk aktif olanı referans olarak sakla (diğer işlemler için)
            failLineManager = System.Array.Find(allFailLineManagers, flm => flm != null && flm.gameObject.activeInHierarchy);
            if (failLineManager == null && allFailLineManagers.Length > 0)
            {
                failLineManager = allFailLineManagers[0];
            }
            
            Debug.Log($"[GameManager] Toplam {subscribedCount} adet FailLineManager instance'ına subscribe edildi.");
            
            if (subscribedCount == 0)
            {
                Debug.LogError("[GameManager] Hiçbir FailLineManager instance'ına subscribe edilemedi! Game over tetiklenmeyecek!");
            }
        }


        private void WarmupPools()
        {
            if (fruitDatabase == null || poolManager == null) return;

            foreach (var fruitType in fruitDatabase.GetAllTypes())
            {
                if (fruitType != null)
                {
                    poolManager.WarmupPool(fruitType, 5);
                }
            }
        }

        public void StartGame()
        {
            ChangeState(GameState.Playing);

            if (spawnQueueManager != null)
            {
                spawnQueueManager.InitializeQueue();
            }

            if (fruitSpawner != null)
            {
                fruitSpawner.AllowInput = true;
                fruitSpawner.StartSpawning();
            }

            if (scoreManager != null)
            {
                scoreManager.ResetScore();
            }

            if (failLineManager != null)
            {
                failLineManager.ResetFailLine();
            }

            // Game over panelini kapat
            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);
            }
        }

        public void RestartGame()
        {
            // Önceki Invoke'ları iptal et (birden fazla restart çağrılırsa sorun olmasın)
            CancelInvoke(nameof(StartGame));

            if (poolManager != null)
            {
                poolManager.ReturnAll();
            }

            if (mergeSystem != null)
            {
                mergeSystem.ClearQueue();
            }

            if (fruitSpawner != null)
            {
                fruitSpawner.ResetSpawner();
            }

            if (spawnQueueManager != null)
            {
                spawnQueueManager.ResetQueue();
            }

            if (scoreManager != null)
            {
                scoreManager.ResetScore();
            }

            if (failLineManager != null)
            {
                failLineManager.ResetFailLine();
            }

            // Kısa delay ile oyunu başlat (tüm sistemlerin reset olması için)
            Invoke(nameof(StartGame), 0.2f);
        }

        private void ChangeState(GameState newState)
        {
            if (currentState == newState) return;

            Debug.Log($"[GameManager] State değişiyor: {currentState} -> {newState}");
            currentState = newState;
            
            // UIHud'a bildir (game over panelini göstermek için)
            OnGameStateChanged?.Invoke(newState);

            switch (newState)
            {
                case GameState.Playing:
                    Time.timeScale = 1f;
                    if (fruitSpawner != null) fruitSpawner.AllowInput = true;
                    break;

                case GameState.GameOver:
                    Time.timeScale = 1f;
                    if (fruitSpawner != null) fruitSpawner.AllowInput = false;
                    Debug.Log("[GameManager] Game Over state aktif. UIHud game over panelini göstermeli.");
                    break;

                case GameState.Paused:
                    Time.timeScale = 0f;
                    if (fruitSpawner != null) fruitSpawner.AllowInput = false;
                    break;
            }
        }

        private void HandleMergeCompleted(FruitTypeSO newFruitType, Vector2 position)
        {
            // Skor MergeSystem'da ekleniyor
        }

        private void HandleGameOver()
        {
            Debug.Log("[GameManager] HandleGameOver çağrıldı. Mevcut state: " + currentState);
            
            // Null kontrolü: Instance kontrolü
            if (Instance != this)
            {
                Debug.LogWarning("[GameManager] HandleGameOver çağrıldı ama Instance bu değil. İptal ediliyor.");
                return;
            }
            
            if (currentState != GameState.Playing)
            {
                Debug.LogWarning($"[GameManager] Game over tetiklendi ama oyun Playing state'inde değil (şu anki: {currentState}). Game over iptal edildi.");
                return;
            }
            
            // Mevcut skoru ScoreManager'dan al (güvenli erişim)
            int currentScore = 0;
            ScoreManager activeScoreManager = scoreManager != null ? scoreManager : ScoreManager.Instance;
            
            try
            {
                if (activeScoreManager != null)
                {
                    currentScore = activeScoreManager.CurrentScore;
                    
                    // Skoru veritabanına kaydet
                    activeScoreManager.SaveCurrentScore();
                    
                    Debug.Log($"[GameManager] Mevcut skor veritabanına kaydedildi: {currentScore}");
                }
                else
                {
                    Debug.LogWarning("[GameManager] ScoreManager bulunamadı! Skor kaydedilemedi.");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[GameManager] Skor kaydedilirken hata: {e.Message}");
            }
            
            // BestScore'u DatabaseManager'dan al
            int bestScore = 0;
            try
            {
                if (DatabaseManager.Instance != null)
                {
                    var topScores = DatabaseManager.Instance.GetHighScores();
                    
                    if (topScores != null && topScores.Count > 0)
                    {
                        bestScore = topScores[0].score;
                        Debug.Log($"[GameManager] En yüksek skor veritabanından alındı: {bestScore}");
                    }
                    else
                    {
                        Debug.Log("[GameManager] Veritabanında skor kaydı bulunamadı.");
                    }
                }
                else
                {
                    Debug.LogWarning("[GameManager] DatabaseManager bulunamadı! Best score 0 olarak ayarlandı.");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[GameManager] Best score alınırken hata: {e.Message}");
            }
            
            // GameOverUI bileşenine eriş ve Setup() fonksiyonunu çağır
            if (gameOverPanel == null)
            {
                Debug.LogError("[GameManager] GameOverPanel referansı null! Inspector'da atanmamış olabilir.");
                // Yine de state'i değiştir (oyun durmalı)
                ChangeState(GameState.GameOver);
                return;
            }
            
            // GameOverUI component'ini al (null kontrolü ile)
            GameOverUI gameOverUI = gameOverPanel.GetComponent<GameOverUI>();
            
            if (gameOverUI == null)
            {
                // Component yoksa, inactive olabilir, GetComponentInChildren dene
                gameOverUI = gameOverPanel.GetComponentInChildren<GameOverUI>(true);
            }
            
            if (gameOverUI != null)
            {
                // Paneli aktif et (önemli: Setup'tan önce aktif et)
                gameOverPanel.SetActive(true);
                
                // Kısa bir frame bekle (UI'nin aktif olması için)
                StartCoroutine(SetupGameOverUICoroutine(gameOverUI, currentScore, bestScore));
            }
            else
            {
                Debug.LogWarning("[GameManager] GameOverPanel üzerinde GameOverUI bileşeni bulunamadı! Panel aktif ediliyor ama Setup çağrılamadı.");
                // Yine de paneli aktif et
                gameOverPanel.SetActive(true);
                ChangeState(GameState.GameOver);
            }
        }
        
        /// <summary>
        /// GameOverUI Setup'ını bir frame sonra çağırır (UI'nin aktif olması için)
        /// </summary>
        private System.Collections.IEnumerator SetupGameOverUICoroutine(GameOverUI gameOverUI, int currentScore, int bestScore)
        {
            // Bir frame bekle (UI'nin aktif olması için)
            yield return null;
            
            // Setup fonksiyonunu çağır
            if (gameOverUI != null)
            {
                gameOverUI.Setup(currentScore, bestScore);
                Debug.Log($"[GameManager] GameOverUI Setup çağrıldı. Score: {currentScore}, BestScore: {bestScore}");
            }
            
            // State'i değiştir
            ChangeState(GameState.GameOver);
        }

        public void TogglePause()
        {
            if (currentState == GameState.Playing)
            {
                ChangeState(GameState.Paused);
            }
            else if (currentState == GameState.Paused)
            {
                ChangeState(GameState.Playing);
            }
        }

        private void OnDestroy()
        {
            if (mergeSystem != null)
            {
                mergeSystem.OnMergeCompleted -= HandleMergeCompleted;
            }

            // Tüm FailLineManager instance'larından unsubscribe et
            // ÖNEMLİ: SubscribeToGameOver() metodu kullanıldığı için, unsubscribe işlemi de güvenli şekilde yapılmalı
            FailLineManager[] allFailLineManagers = FindObjectsByType<FailLineManager>(FindObjectsSortMode.None);
            if (allFailLineManagers != null && allFailLineManagers.Length > 0)
            {
                foreach (var flm in allFailLineManagers)
                {
                    if (flm != null)
                    {
                        try
                        {
                            flm.OnGameOver -= HandleGameOver;
                        }
                        catch (System.Exception e)
                        {
                            Debug.LogWarning($"[GameManager] Unsubscribe hatası: {e.Message}");
                        }
                    }
                }
            }
            else if (failLineManager != null)
            {
                // Fallback: Sadece referans olarak tutulan instance'dan unsubscribe et
                try
                {
                    failLineManager.OnGameOver -= HandleGameOver;
                }
                catch (System.Exception e)
                {
                    Debug.LogWarning($"[GameManager] Unsubscribe hatası: {e.Message}");
                }
            }

            if (Instance == this)
            {
                Instance = null;
            }
        }
    }
}
