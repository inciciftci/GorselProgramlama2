using UnityEngine;
using TMPro;
using System.Collections;
using System.Collections.Generic;
using FruitMerge.Managers;

namespace FruitMerge.UI
{
    /// <summary>
    /// Game Over UI panelini y?netir.
    /// Skor g?sterimi ve a??l?? animasyonu sa?lar.
    /// </summary>
    public class GameOverUI : MonoBehaviour
    {
        [Header("UI References")]
        [Tooltip("Mevcut skor metni")]
        [SerializeField] private TextMeshProUGUI scoreText;
        
        [Tooltip("En iyi skor metni")]
        [SerializeField] private TextMeshProUGUI bestScoreText;
        
        [Tooltip("Restart butonu")]
        [SerializeField] private UnityEngine.UI.Button restartButton;
        
        [Tooltip("DatabaseManager referansı (boş bırakılırsa Singleton kullanılır)")]
        [SerializeField] private DatabaseManager databaseManager;

        [Header("Animation Settings")]
        [Tooltip("Animasyon s?resi (saniye)")]
        [SerializeField] private float animationDuration = 0.3f;
        
        [Tooltip("Animasyon e?risi (ease in/out)")]
        [SerializeField] private AnimationCurve scaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);
        
        [Tooltip("Ba?lang?? ?l?e?i")]
        [SerializeField] private Vector3 startScale = Vector3.zero;
        
        [Tooltip("Hedef ?l?ek")]
        [SerializeField] private Vector3 targetScale = Vector3.one;

        [Header("Text Format")]
        [Tooltip("Skor metin format?")]
        [SerializeField] private string scoreFormat = "Score: {0}";
        
        [Tooltip("En iyi skor metin format?")]
        [SerializeField] private string bestScoreFormat = "Best: {0}";

        [Header("Counting Animation")]
        [Tooltip("Skor sayma animasyonu s?resi (saniye)")]
        [SerializeField] private float countingDuration = 1.0f;
        
        [Tooltip("Sayma animasyonu e?risi")]
        [SerializeField] private AnimationCurve countingCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

        private RectTransform rectTransform;
        private Coroutine scaleAnimationCoroutine;
        private Coroutine scoreCountingCoroutine;
        private Coroutine bestScoreCountingCoroutine;
        
        private int targetScore = 0;
        private int targetBestScore = 0;

        private Vector2 initialAnchoredPosition;
        private Vector2 initialSizeDelta;
        private bool hasStoredInitialValues = false;
        
        // UI elementlerinin ilk değerleri (çözünürlük değişikliklerinden korumak için)
        private struct UIElementData
        {
            public Vector2 anchoredPosition;
            public Vector3 localScale;
        }
        
        private UIElementData scoreTextData;
        private UIElementData bestScoreTextData;
        private UIElementData restartButtonData;
        private bool hasStoredUIElementValues = false;
        
        private void Awake()
        {
            // Canvas'ın referenceResolution'unu 1080x1920 olarak ayarla
            ConfigureCanvasReferenceResolution();
            
            // RectTransform referansını al (UI elementleri için)
            rectTransform = GetComponent<RectTransform>();
            
            // Eğer RectTransform yoksa, normal Transform kullan
            if (rectTransform == null)
            {
                Debug.LogWarning("[GameOverUI] RectTransform bulunamadı, Transform kullanılıyor.");
            }
            else
            {
                // İlk pozisyon ve boyut değerlerini kaydet (çözünürlük değişikliklerinden korumak için)
                if (!hasStoredInitialValues)
                {
                    initialAnchoredPosition = rectTransform.anchoredPosition;
                    initialSizeDelta = rectTransform.sizeDelta;
                    hasStoredInitialValues = true;
                }
            }

            // UI elementlerinin ilk değerlerini kaydet
            StoreUIElementValues();

            // Başlangıç durumunu ayarla (sadece scale, pozisyon ve boyut değiştirme)
            if (rectTransform != null)
            {
                rectTransform.localScale = startScale;
            }
            else
            {
                transform.localScale = startScale;
            }
        }
        
        /// <summary>
        /// Canvas'ın referenceResolution'unu 1080x1920 olarak ayarlar
        /// </summary>
        private void ConfigureCanvasReferenceResolution()
        {
            Canvas canvas = GetComponentInParent<Canvas>();
            if (canvas == null)
            {
                Debug.LogWarning("[GameOverUI] Canvas bulunamadı! CanvasScaler ayarlanamadı.");
                return;
            }
            
            UnityEngine.UI.CanvasScaler canvasScaler = canvas.GetComponent<UnityEngine.UI.CanvasScaler>();
            if (canvasScaler == null)
            {
                Debug.LogWarning("[GameOverUI] CanvasScaler bulunamadı! Canvas'a CanvasScaler component'i ekleyin.");
                return;
            }
            
            // Reference Resolution'ı 1080x1920 olarak ayarla
            Vector2 targetResolution = new Vector2(1080f, 1920f);
            
            if (canvasScaler.referenceResolution != targetResolution)
            {
                canvasScaler.referenceResolution = targetResolution;
                Debug.Log($"[GameOverUI] Canvas Reference Resolution {targetResolution} olarak ayarlandı.");
            }
            
            // Scale Mode'u ScaleWithScreenSize yap (eğer değilse)
            if (canvasScaler.uiScaleMode != UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize)
            {
                canvasScaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
                Debug.Log("[GameOverUI] CanvasScaler ScaleMode ScaleWithScreenSize olarak ayarlandı.");
            }
        }
        
        /// <summary>
        /// UI elementlerinin anchoredPosition ve localScale değerlerini kaydeder
        /// </summary>
        private void StoreUIElementValues()
        {
            if (hasStoredUIElementValues) return;
            
            // Score Text değerlerini kaydet
            if (scoreText != null)
            {
                RectTransform scoreRect = scoreText.GetComponent<RectTransform>();
                if (scoreRect != null)
                {
                    scoreTextData.anchoredPosition = scoreRect.anchoredPosition;
                    scoreTextData.localScale = scoreRect.localScale;
                    Debug.Log($"[GameOverUI] ScoreText değerleri kaydedildi - Position: {scoreTextData.anchoredPosition}, Scale: {scoreTextData.localScale}");
                }
            }
            
            // Best Score Text değerlerini kaydet
            if (bestScoreText != null)
            {
                RectTransform bestScoreRect = bestScoreText.GetComponent<RectTransform>();
                if (bestScoreRect != null)
                {
                    bestScoreTextData.anchoredPosition = bestScoreRect.anchoredPosition;
                    bestScoreTextData.localScale = bestScoreRect.localScale;
                    Debug.Log($"[GameOverUI] BestScoreText değerleri kaydedildi - Position: {bestScoreTextData.anchoredPosition}, Scale: {bestScoreTextData.localScale}");
                }
            }
            
            // Restart Button değerlerini kaydet
            if (restartButton != null)
            {
                RectTransform buttonRect = restartButton.GetComponent<RectTransform>();
                if (buttonRect != null)
                {
                    restartButtonData.anchoredPosition = buttonRect.anchoredPosition;
                    restartButtonData.localScale = buttonRect.localScale;
                    Debug.Log($"[GameOverUI] RestartButton değerleri kaydedildi - Position: {restartButtonData.anchoredPosition}, Scale: {restartButtonData.localScale}");
                }
            }
            
            hasStoredUIElementValues = true;
        }
        
        /// <summary>
        /// UI elementlerinin anchoredPosition ve localScale değerlerini geri yükler
        /// </summary>
        private void RestoreUIElementValues()
        {
            if (!hasStoredUIElementValues) return;
            
            // Score Text değerlerini geri yükle
            if (scoreText != null)
            {
                RectTransform scoreRect = scoreText.GetComponent<RectTransform>();
                if (scoreRect != null)
                {
                    scoreRect.anchoredPosition = scoreTextData.anchoredPosition;
                    scoreRect.localScale = scoreTextData.localScale;
                    Debug.Log($"[GameOverUI] ScoreText değerleri geri yüklendi - Position: {scoreTextData.anchoredPosition}, Scale: {scoreTextData.localScale}");
                }
            }
            
            // Best Score Text değerlerini geri yükle
            if (bestScoreText != null)
            {
                RectTransform bestScoreRect = bestScoreText.GetComponent<RectTransform>();
                if (bestScoreRect != null)
                {
                    bestScoreRect.anchoredPosition = bestScoreTextData.anchoredPosition;
                    bestScoreRect.localScale = bestScoreTextData.localScale;
                    Debug.Log($"[GameOverUI] BestScoreText değerleri geri yüklendi - Position: {bestScoreTextData.anchoredPosition}, Scale: {bestScoreTextData.localScale}");
                }
            }
            
            // Restart Button değerlerini geri yükle
            if (restartButton != null)
            {
                RectTransform buttonRect = restartButton.GetComponent<RectTransform>();
                if (buttonRect != null)
                {
                    buttonRect.anchoredPosition = restartButtonData.anchoredPosition;
                    buttonRect.localScale = restartButtonData.localScale;
                    Debug.Log($"[GameOverUI] RestartButton değerleri geri yüklendi - Position: {restartButtonData.anchoredPosition}, Scale: {restartButtonData.localScale}");
                }
            }
        }
        
        private void Start()
        {
            // Start'ta da ilk değerleri kaydet (CanvasScaler bazen Start'ta ayarlanır)
            if (rectTransform != null && !hasStoredInitialValues)
            {
                initialAnchoredPosition = rectTransform.anchoredPosition;
                initialSizeDelta = rectTransform.sizeDelta;
                hasStoredInitialValues = true;
            }
            
            // UI element değerlerini Start'ta da kaydet (CanvasScaler ayarlarından sonra)
            if (!hasStoredUIElementValues)
            {
                StoreUIElementValues();
            }
        }
        
        private void LateUpdate()
        {
            // Pozisyon ve boyutun sabit kalmas?n? sa?la (sadece scale animasyonu varsa m?dahale etme)
            if (rectTransform != null && hasStoredInitialValues)
            {
                // Scale animasyonu aktif de?ilse (startScale veya targetScale d???nda bir de?erde de?ilse) pozisyonu koru
                bool isAnimating = scaleAnimationCoroutine != null;
                
                if (!isAnimating)
                {
                    // Pozisyonu kontrol et ve d?zelt
                    if (rectTransform.anchoredPosition != initialAnchoredPosition)
                    {
                        rectTransform.anchoredPosition = initialAnchoredPosition;
                    }
                    
                    // Boyutu kontrol et ve d?zelt
                    if (rectTransform.sizeDelta != initialSizeDelta)
                    {
                        rectTransform.sizeDelta = initialSizeDelta;
                    }
                }
            }
        }

        private void OnEnable()
        {
            // UI elementlerinin değerlerini geri yükle (çözünürlük değişikliklerinden korumak için)
            RestoreUIElementValues();
            
            // Panel açıldığında animasyonu başlat
            PlayScaleAnimation();
            
            // High score'u veritabanından yükle ve göster
            LoadAndDisplayHighScore();
        }
        
        /// <summary>
        /// En yüksek skoru veritabanından yükler ve bestScoreText'e gösterir
        /// </summary>
        private void LoadAndDisplayHighScore()
        {
            try
            {
                DatabaseManager dbManager = databaseManager != null ? databaseManager : DatabaseManager.Instance;
                
                if (dbManager != null)
                {
                    // Veritabanından en yüksek skoru al
                    int bestScore = dbManager.GetBestScore();
                    
                    // Eğer Setup çağrılmadıysa veya bestScoreText güncellenmemişse, güncelle
                    if (bestScoreText != null)
                    {
                        // Mevcut bestScore değerini güncelle
                        targetBestScore = bestScore;
                        
                        // Text'i güncelle (animasyonlu sayma yerine direkt göster)
                        UpdateBestScoreText(bestScore);
                        
                        Debug.Log($"[GameOverUI] En yüksek skor veritabanından yüklendi ve gösterildi: {bestScore}");
                    }
                }
                else
                {
                    Debug.LogWarning("[GameOverUI] DatabaseManager bulunamadı! High score gösterilemiyor.");
                    if (bestScoreText != null)
                    {
                        UpdateBestScoreText(0);
                    }
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[GameOverUI] High score yüklenirken hata: {e.Message}");
                if (bestScoreText != null)
                {
                    UpdateBestScoreText(0);
                }
            }
        }

        /// <summary>
        /// UI'yi belirtilen skor de?erleriyle g?nceller.
        /// Skorlar animasyonlu olarak say?l?r.
        /// </summary>
        /// <param name="score">Mevcut skor</param>
        /// <param name="bestScore">En iyi skor</param>
        public void Setup(int score, int bestScore)
        {
            // Null kontrol?
            if (this == null || gameObject == null)
            {
                Debug.LogError("[GameOverUI] Setup ?a?r?ld? ama component veya GameObject null!");
                return;
            }
            
            // Hedef skorlar? sakla (negatif de?erleri engelle)
            targetScore = Mathf.Max(0, score);
            targetBestScore = Mathf.Max(0, bestScore);
            
            // ?nceki sayma animasyonlar?n? durdur
            StopCountingAnimations();
            
            // Skor metinlerini 0'dan ba?lat
            UpdateScoreText(0);
            UpdateBestScoreText(0);
            
            // Sayma animasyonlar?n? ba?lat (null kontrol? ile)
            if (scoreText != null && gameObject.activeInHierarchy)
            {
                scoreCountingCoroutine = StartCoroutine(CountScoreCoroutine(targetScore, scoreText, scoreFormat));
            }
            else if (scoreText == null)
            {
                Debug.LogWarning("[GameOverUI] ScoreText referans? null! Skor g?sterilemeyecek.");
            }
            
            if (bestScoreText != null && gameObject.activeInHierarchy)
            {
                bestScoreCountingCoroutine = StartCoroutine(CountScoreCoroutine(targetBestScore, bestScoreText, bestScoreFormat));
            }
            else if (bestScoreText == null)
            {
                Debug.LogWarning("[GameOverUI] BestScoreText referans? null! En iyi skor g?sterilemeyecek.");
            }
            
            Debug.Log($"[GameOverUI] Setup tamamland?. Score: {targetScore}, BestScore: {targetBestScore}");
        }

        /// <summary>
        /// Skor metnini g?nceller.
        /// </summary>
        private void UpdateScoreText(int score)
        {
            if (scoreText != null)
            {
                scoreText.text = string.Format(scoreFormat, score);
            }
            else
            {
                Debug.LogWarning("[GameOverUI] ScoreText referans? null!");
            }
        }

        /// <summary>
        /// En iyi skor metnini g?nceller.
        /// </summary>
        private void UpdateBestScoreText(int bestScore)
        {
            if (bestScoreText != null)
            {
                bestScoreText.text = string.Format(bestScoreFormat, bestScore);
            }
            else
            {
                Debug.LogWarning("[GameOverUI] BestScoreText referans? null!");
            }
        }

        /// <summary>
        /// Skor sayma animasyonu coroutine'i.
        /// 0'dan hedef skora kadar sayarak g?sterir.
        /// </summary>
        /// <param name="targetValue">Hedef skor de?eri</param>
        /// <param name="textComponent">G?ncellenecek TextMeshProUGUI component</param>
        /// <param name="format">Metin format?</param>
        private IEnumerator CountScoreCoroutine(int targetValue, TextMeshProUGUI textComponent, string format)
        {
            if (textComponent == null) yield break;
            
            float elapsedTime = 0f;
            int startValue = 0;
            int currentValue = startValue;
            
            // K???k skorlar i?in daha h?zl? say
            float actualDuration = countingDuration;
            if (targetValue < 100)
            {
                actualDuration = countingDuration * 0.5f; // K???k skorlar i?in yar? s?re
            }
            
            while (elapsedTime < actualDuration)
            {
                elapsedTime += Time.unscaledDeltaTime;
                float normalizedTime = Mathf.Clamp01(elapsedTime / actualDuration);
                
                // Animation curve'den de?eri al
                float curveValue = countingCurve.Evaluate(normalizedTime);
                
                // Skoru interpolate et
                float floatValue = Mathf.Lerp(startValue, targetValue, curveValue);
                int newValue = Mathf.RoundToInt(floatValue);
                
                // Sadece de?er de?i?tiyse g?ncelle (performans i?in)
                if (newValue != currentValue)
                {
                    currentValue = newValue;
                    textComponent.text = string.Format(format, currentValue);
                }
                
                yield return null; // Bir frame bekle
            }
            
            // Animasyon tamamland???nda hedef de?eri garantile
            textComponent.text = string.Format(format, targetValue);
        }

        /// <summary>
        /// T?m sayma animasyonlar?n? durdurur.
        /// </summary>
        private void StopCountingAnimations()
        {
            if (scoreCountingCoroutine != null)
            {
                StopCoroutine(scoreCountingCoroutine);
                scoreCountingCoroutine = null;
            }
            
            if (bestScoreCountingCoroutine != null)
            {
                StopCoroutine(bestScoreCountingCoroutine);
                bestScoreCountingCoroutine = null;
            }
        }

        /// <summary>
        /// ?l?eklenme animasyonunu oynat?r.
        /// </summary>
        private void PlayScaleAnimation()
        {
            // ?nceki animasyonu durdur (e?er varsa)
            if (scaleAnimationCoroutine != null)
            {
                StopCoroutine(scaleAnimationCoroutine);
            }

            // Ba?lang?? ?l?e?ini ayarla
            if (rectTransform != null)
            {
                rectTransform.localScale = startScale;
            }
            else
            {
                transform.localScale = startScale;
            }

            // Animasyonu ba?lat
            scaleAnimationCoroutine = StartCoroutine(ScaleAnimationCoroutine());
        }

        /// <summary>
        /// ?l?eklenme animasyonu coroutine'i.
        /// Performansl? ve p?r?zs?z animasyon sa?lar.
        /// </summary>
        private IEnumerator ScaleAnimationCoroutine()
        {
            float elapsedTime = 0f;
            Transform targetTransform = rectTransform != null ? rectTransform : transform;

            while (elapsedTime < animationDuration)
            {
                elapsedTime += Time.unscaledDeltaTime; // Time.unscaledDeltaTime kullan (pause durumunda da ?al??s?n)
                float normalizedTime = Mathf.Clamp01(elapsedTime / animationDuration);
                
                // Animation curve'den de?eri al
                float curveValue = scaleCurve.Evaluate(normalizedTime);
                
                // ?l?e?i interpolate et
                Vector3 currentScale = Vector3.Lerp(startScale, targetScale, curveValue);
                targetTransform.localScale = currentScale;

                yield return null; // Bir frame bekle
            }

            // Animasyon tamamland???nda hedef ?l?e?i garantile
            targetTransform.localScale = targetScale;
            scaleAnimationCoroutine = null;
        }

        /// <summary>
        /// Animasyonu durdurur (panel kapat?l?rken kullan?labilir).
        /// </summary>
        public void StopAnimation()
        {
            if (scaleAnimationCoroutine != null)
            {
                StopCoroutine(scaleAnimationCoroutine);
                scaleAnimationCoroutine = null;
            }
            
            // Sayma animasyonlar?n? da durdur
            StopCountingAnimations();
        }

        /// <summary>
        /// Panel kapat?ld???nda t?m animasyonlar? durdur.
        /// </summary>
        private void OnDisable()
        {
            StopAnimation();
        }

#if UNITY_EDITOR
        /// <summary>
        /// Editor'da varsay?lan de?erleri ayarla.
        /// </summary>
        private void Reset()
        {
            // Varsay?lan scale curve'? ayarla
            if (scaleCurve == null || scaleCurve.length == 0)
            {
                scaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);
            }
            
            // Varsay?lan counting curve'? ayarla
            if (countingCurve == null || countingCurve.length == 0)
            {
                countingCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);
            }
        }
#endif
    }
}
