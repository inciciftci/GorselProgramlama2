# 🍌 FruitType Hızlı Referans Tablosu

## 📋 FruitType SO Oluşturma Tablosu

| ID | SO İsmi | Sprite Dosyası | displayName | colliderRadius | scoreValue | nextType |
|----|---------|----------------|-------------|----------------|------------|----------|
| 0 | `Food_BurnedToast` | `Burned_Toast` | Burned Toast | 0.25 | 10 | Food_CrispyToast |
| 1 | `Food_CrispyToast` | `Crispy_Toast` | Crispy Toast | 0.35 | 20 | Food_BakedBanana |
| 2 | `Food_BakedBanana` | `Baked_Banana` | Baked Banana | 0.45 | 40 | Food_BananaMilk |
| 3 | `Food_BananaMilk` | `Banana_Milk` | Banana Milk | 0.55 | 80 | Food_BananaFrenchToast |
| 4 | `Food_BananaFrenchToast` | `Banana_French_Toast` | Banana French Toast | 0.65 | 160 | Food_EggCheeseSandwich |
| 5 | `Food_EggCheeseSandwich` | `Egg_Cheese_Sandwich` | Egg Cheese Sandwich | 0.75 | 320 | Food_EggSalamiSandwich |
| 6 | `Food_EggSalamiSandwich` | `Egg_Salami_Sandwich` | Egg Salami Sandwich | 0.85 | 640 | Food_EggCheeseSalamiSandwich |
| 7 | `Food_EggCheeseSalamiSandwich` | `Egg_Cheese_Salami_Sandwich` | Full Sandwich | 0.95 | 1280 | Food_BananaBread |
| 8 | `Food_BananaBread` | `Banana_Bread` | Banana Bread | 1.05 | 2560 | Food_BananaPancakes |
| 9 | `Food_BananaPancakes` | `Banana_Pancakes` | Banana Pancakes | 1.15 | 5120 | **null** |

---

## 🎯 Adım Adım Oluşturma

### 1. FruitType SO'ları Oluştur
**Assets/ScriptableObjects/FruitTypes** klasöründe:

1. Sağ tık → **Create > FruitMerge > FruitType**
2. İsim: Tablodaki **SO İsmi** (örn: `Food_BurnedToast`)
3. Inspector'da ayarları yap:
   - **id**: Tablodaki ID (0-9)
   - **displayName**: Tablodaki displayName
   - **sprite**: Project penceresinden `Assets/Sprites/[Sprite Dosyası].png` sürükle
   - **colliderRadius**: Tablodaki değer
   - **scoreValue**: Tablodaki değer
   - **nextType**: Bir sonraki FruitType SO'yu sürükle (son olan null)

### 2. FruitDatabase Oluştur
**Assets/ScriptableObjects** klasöründe:

1. Sağ tık → **Create > FruitMerge > FruitDatabase**
2. İsim: `FruitDatabase`
3. **Types** listesine sırayla 10 FruitType'ı ekle
4. **Max Spawn Type ID**: `2` (Sadece ID 0, 1, 2 spawn olur)

---

## 📦 Prefab Oluşturma

**ÖNEMLİ:** Her FruitType için **ayrı prefab** oluşturmalısın! Bu sayede:
- Her yiyecek için farklı collider tipi kullanabilirsin (Circle, Box, Polygon, vb.)
- Her prefab'ın kendi özel ayarları olabilir
- Daha esnek ve özelleştirilebilir bir sistem elde edersin

### Prefab İsimleri
Her FruitType için prefab ismi = SO ismi ile aynı:
- `Food_BurnedToast`
- `Food_CrispyToast`
- `Food_BakedBanana`
- `Food_BananaMilk`
- `Food_BananaFrenchToast`
- `Food_EggCheeseSandwich`
- `Food_EggSalamiSandwich`
- `Food_EggCheeseSalamiSandwich`
- `Food_BananaBread`
- `Food_BananaPancakes`

### Prefab Oluşturma Adımları
1. Hierarchy'de **Create Empty** → İsim: `Food_BurnedToast`
2. Component ekle:
   - **Sprite Renderer** → Sprite'ı ekle
   - **Rigidbody2D** (Dynamic, Mass:0.5, Gravity Scale:2, Freeze Rotation:✅)
   - **Collider2D** (Circle, Box veya Polygon - istediğin tipi seç)
   - **Fruit** script
3. Collider ayarlarını yap (size, offset, vb.)
4. Layer: `Fruit`
5. **Assets/Prefabs/Fruits** klasörüne sürükle
6. Her FruitType için tekrarla

**Not:** 
- Eğer **CircleCollider2D** kullanırsan, script otomatik olarak radius'u ayarlayacak
- Eğer **BoxCollider2D** veya **PolygonCollider2D** kullanırsan, collider ayarlarını prefab'da manuel yapmalısın

---

## ✅ Kontrol

- [ ] 10 FruitType SO oluşturuldu
- [ ] Her birinin sprite'ı bağlı
- [ ] NextType zinciri doğru (0→1→2→...→9→null)
- [ ] 10 ayrı prefab oluşturuldu (her FruitType için)
- [ ] Her prefab'a ilgili sprite eklendi
- [ ] Her prefab'da Collider2D component'i var
- [ ] Her FruitType SO'ya ilgili prefab bağlandı
- [ ] FruitDatabase oluşturuldu ve 10 tip eklendi
- [ ] Max Spawn Type ID = 2
