using UnityEngine;
using UnityEngine.UI;

namespace FruitMerge.UI
{
    /// <summary>
    /// CanvasScaler ayarlarını runtime'da kontrol eder ve doğru yapılandırmayı sağlar.
    /// Bu script Canvas GameObject'ine eklenebilir ve CanvasScaler'ı otomatik olarak yapılandırır.
    /// </summary>
    [RequireComponent(typeof(Canvas))]
    [RequireComponent(typeof(CanvasScaler))]
    public class CanvasScalerConfig : MonoBehaviour
    {
        [Header("Reference Resolution")]
        [Tooltip("Referans çözünürlük (UI tasarımının yapıldığı çözünürlük)")]
        [SerializeField] private Vector2 referenceResolution = new Vector2(1920, 1080);
        
        [Header("Match Settings")]
        [Tooltip("0 = Width'e göre ölçekle, 1 = Height'e göre ölçekle, 0.5 = Her ikisine göre ölçekle")]
        [Range(0f, 1f)]
        [SerializeField] private float matchWidthOrHeight = 0.5f;
        
        [Header("Auto Configure")]
        [Tooltip("Start'ta otomatik olarak CanvasScaler'ı yapılandır")]
        [SerializeField] private bool autoConfigureOnStart = true;
        
        private CanvasScaler canvasScaler;
        private Canvas canvas;
        
        private void Awake()
        {
            canvas = GetComponent<Canvas>();
            canvasScaler = GetComponent<CanvasScaler>();
            
            if (canvasScaler == null)
            {
                Debug.LogError("[CanvasScalerConfig] CanvasScaler component bulunamadı!");
                return;
            }
            
            // Mevcut ayarları kaydet
            referenceResolution = canvasScaler.referenceResolution;
            matchWidthOrHeight = canvasScaler.matchWidthOrHeight;
        }
        
        private void Start()
        {
            if (autoConfigureOnStart)
            {
                ConfigureCanvasScaler();
            }
        }
        
        /// <summary>
        /// CanvasScaler'ı doğru ayarlarla yapılandırır
        /// </summary>
        public void ConfigureCanvasScaler()
        {
            if (canvasScaler == null)
            {
                Debug.LogError("[CanvasScalerConfig] CanvasScaler null!");
                return;
            }
            
            // Scale Mode'u ScaleWithScreenSize olarak ayarla
            canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            
            // Reference Resolution'ı ayarla
            canvasScaler.referenceResolution = referenceResolution;
            
            // Match ayarını yap
            canvasScaler.matchWidthOrHeight = matchWidthOrHeight;
            
            // Screen Space - Overlay için ekstra ayarlar
            if (canvas != null && canvas.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                canvasScaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            }
            
            Debug.Log($"[CanvasScalerConfig] CanvasScaler yapılandırıldı - " +
                     $"ReferenceResolution: {referenceResolution}, " +
                     $"Match: {matchWidthOrHeight}, " +
                     $"ScaleMode: {canvasScaler.uiScaleMode}");
        }
        
        /// <summary>
        /// Mevcut ekran çözünürlüğünü logla (debug için)
        /// </summary>
        [ContextMenu("Log Screen Resolution")]
        public void LogScreenResolution()
        {
            Debug.Log($"[CanvasScalerConfig] Ekran Çözünürlüğü: {Screen.width}x{Screen.height}, " +
                     $"Reference: {referenceResolution}, " +
                     $"Match: {matchWidthOrHeight}");
        }
        
        /// <summary>
        /// CanvasScaler ayarlarını kontrol et ve uyarı ver
        /// </summary>
        [ContextMenu("Check CanvasScaler Settings")]
        public void CheckCanvasScalerSettings()
        {
            if (canvasScaler == null)
            {
                Debug.LogError("[CanvasScalerConfig] CanvasScaler null!");
                return;
            }
            
            bool hasIssues = false;
            
            if (canvasScaler.uiScaleMode != CanvasScaler.ScaleMode.ScaleWithScreenSize)
            {
                Debug.LogWarning($"[CanvasScalerConfig] ScaleMode '{canvasScaler.uiScaleMode}' yerine 'ScaleWithScreenSize' kullanılmalı!");
                hasIssues = true;
            }
            
            if (canvasScaler.referenceResolution.x <= 0 || canvasScaler.referenceResolution.y <= 0)
            {
                Debug.LogError($"[CanvasScalerConfig] Reference Resolution geçersiz: {canvasScaler.referenceResolution}");
                hasIssues = true;
            }
            
            if (!hasIssues)
            {
                Debug.Log($"[CanvasScalerConfig] ✓ CanvasScaler ayarları doğru görünüyor.");
            }
        }
    }
}
