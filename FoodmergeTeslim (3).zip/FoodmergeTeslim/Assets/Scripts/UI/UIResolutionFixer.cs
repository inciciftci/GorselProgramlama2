using UnityEngine;
using UnityEngine.UI;

namespace FruitMerge.UI
{
    /// <summary>
    /// UI elementlerinin çözünürlükten bağımsız olarak sabit kalmasını sağlar.
    /// CanvasScaler ayarlarını kontrol eder ve UI pozisyonlarını korur.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class UIResolutionFixer : MonoBehaviour
    {
        [Header("Settings")]
        [Tooltip("UI elementinin pozisyonunu ve boyutunu sabit tut")]
        [SerializeField] private bool lockPosition = true;
        [Tooltip("UI elementinin boyutunu sabit tut")]
        [SerializeField] private bool lockSize = true;
        
        [Header("Initial Values (Auto-set)")]
        [SerializeField] private Vector2 initialAnchoredPosition;
        [SerializeField] private Vector2 initialSizeDelta;
        [SerializeField] private Vector3 initialLocalScale;
        
        private RectTransform rectTransform;
        private CanvasScaler canvasScaler;
        private Canvas rootCanvas;
        private bool isInitialized = false;
        
        private void Awake()
        {
            rectTransform = GetComponent<RectTransform>();
            
            // Root Canvas'i bul
            rootCanvas = GetComponentInParent<Canvas>();
            if (rootCanvas != null)
            {
                canvasScaler = rootCanvas.GetComponent<CanvasScaler>();
            }
            
            // İlk değerleri kaydet
            if (rectTransform != null)
            {
                initialAnchoredPosition = rectTransform.anchoredPosition;
                initialSizeDelta = rectTransform.sizeDelta;
                initialLocalScale = rectTransform.localScale;
                isInitialized = true;
            }
        }
        
        private void Start()
        {
            // Start'ta da kontrol et (CanvasScaler bazen Start'ta ayarlanır)
            if (!isInitialized && rectTransform != null)
            {
                initialAnchoredPosition = rectTransform.anchoredPosition;
                initialSizeDelta = rectTransform.sizeDelta;
                initialLocalScale = rectTransform.localScale;
                isInitialized = true;
            }
            
            // CanvasScaler ayarlarını kontrol et ve uyar
            CheckCanvasScalerSettings();
        }
        
        private void LateUpdate()
        {
            // Her frame sonunda pozisyon ve boyutu kontrol et ve düzelt
            if (!isInitialized || rectTransform == null) return;
            
            // Sadece scale animasyonu yoksa düzelt (GameOverUI gibi animasyonlu UI'lar için)
            if (lockPosition && rectTransform.anchoredPosition != initialAnchoredPosition)
            {
                // Eğer localScale değişmemişse (animasyon yoksa) pozisyonu düzelt
                if (rectTransform.localScale == initialLocalScale || rectTransform.localScale == Vector3.zero)
                {
                    rectTransform.anchoredPosition = initialAnchoredPosition;
                }
            }
            
            if (lockSize && rectTransform.sizeDelta != initialSizeDelta)
            {
                // Eğer localScale değişmemişse (animasyon yoksa) boyutu düzelt
                if (rectTransform.localScale == initialLocalScale || rectTransform.localScale == Vector3.zero)
                {
                    rectTransform.sizeDelta = initialSizeDelta;
                }
            }
        }
        
        /// <summary>
        /// CanvasScaler ayarlarını kontrol eder ve öneriler sunar
        /// </summary>
        private void CheckCanvasScalerSettings()
        {
            if (canvasScaler == null)
            {
                Debug.LogWarning($"[UIResolutionFixer] {gameObject.name}: CanvasScaler bulunamadı! Canvas'a CanvasScaler ekleyin.");
                return;
            }
            
            // CanvasScaler ayarlarını kontrol et
            if (canvasScaler.uiScaleMode != CanvasScaler.ScaleMode.ScaleWithScreenSize)
            {
                Debug.LogWarning($"[UIResolutionFixer] {gameObject.name}: CanvasScaler ScaleMode '{canvasScaler.uiScaleMode}' yerine 'ScaleWithScreenSize' kullanılmalı!");
            }
            
            if (canvasScaler.referenceResolution.x <= 0 || canvasScaler.referenceResolution.y <= 0)
            {
                Debug.LogError($"[UIResolutionFixer] {gameObject.name}: CanvasScaler Reference Resolution geçersiz! ({canvasScaler.referenceResolution})");
            }
            
            // Önerilen ayarları logla
            Debug.Log($"[UIResolutionFixer] {gameObject.name}: CanvasScaler ayarları - " +
                     $"ReferenceResolution: {canvasScaler.referenceResolution}, " +
                     $"Match: {canvasScaler.matchWidthOrHeight}, " +
                     $"ScaleMode: {canvasScaler.uiScaleMode}");
        }
        
        /// <summary>
        /// İlk değerleri manuel olarak ayarla (runtime'da kullanılabilir)
        /// </summary>
        public void SetInitialValues()
        {
            if (rectTransform != null)
            {
                initialAnchoredPosition = rectTransform.anchoredPosition;
                initialSizeDelta = rectTransform.sizeDelta;
                initialLocalScale = rectTransform.localScale;
                isInitialized = true;
            }
        }
        
        /// <summary>
        /// Pozisyonu ve boyutu ilk değerlere sıfırla
        /// </summary>
        public void ResetToInitialValues()
        {
            if (!isInitialized || rectTransform == null) return;
            
            if (lockPosition)
            {
                rectTransform.anchoredPosition = initialAnchoredPosition;
            }
            
            if (lockSize)
            {
                rectTransform.sizeDelta = initialSizeDelta;
            }
        }
        
#if UNITY_EDITOR
        /// <summary>
        /// Editor'da değerleri görselleştir
        /// </summary>
        private void OnDrawGizmosSelected()
        {
            if (rectTransform == null) return;
            
            // İlk pozisyonu göster
            Vector3 worldPos = rectTransform.TransformPoint(initialAnchoredPosition);
            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(worldPos, 5f);
        }
#endif
    }
}
