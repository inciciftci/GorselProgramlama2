using FruitMerge.Data;
using FruitMerge.Managers;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using DG.Tweening;

namespace FruitMerge.UI
{
    public class UIHud : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private ScoreManager scoreManager;
        [SerializeField] private SpawnQueueManager spawnQueueManager;
        [SerializeField] private GameManager gameManager;

        [Header("UI Elements")]
        [SerializeField] private TextMeshProUGUI scoreText;
        [SerializeField] private TextMeshProUGUI highScoreText;
        [SerializeField] private Image nextFruitImage;
        [SerializeField] private Button restartButton;

        [Header("Game Over Panel")]
        [SerializeField] private GameObject gameOverPanel;
        [SerializeField] private TextMeshProUGUI gameOverTitleText;
        [SerializeField] private TextMeshProUGUI finalScoreText;
        [SerializeField] private Button gameOverRestartButton;

        [Header("Settings")]
        [SerializeField] private string scoreFormat = "Score: {0}";
        [SerializeField] private string highScoreFormat = "Best: {0}";
        
        [Header("Next Fruit Animation")]
        [Tooltip("Maksimum UI boyutu (piksel) - meyve bu boyutu aşamaz")]
        [SerializeField] private float maxUISize = 150f;
        
        [Tooltip("Giriş animasyonu süresi (scale 0'dan 1.0'a)")]
        [SerializeField] private float entranceScaleDuration = 0.2f;
        
        [Tooltip("Fade animasyonu süresi")]
        [SerializeField] private float fadeDuration = 0.15f;
        
        [Tooltip("Zıplama yüksekliği (piksel)")]
        [SerializeField] private float bounceHeight = 5f;
        
        [Tooltip("Zıplama animasyonu süresi")]
        [SerializeField] private float bounceDuration = 0.2f;
        
        private Sequence animationSequence;
        private Vector2 initialAnchoredPosition;

        private void OnEnable()
        {
            // Singleton'ları kullan (fallback olarak direkt referanslar)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            SpawnQueueManager spawnQueue = spawnQueueManager != null ? spawnQueueManager : FindFirstObjectByType<SpawnQueueManager>();
            GameManager game = gameManager != null ? gameManager : GameManager.Instance;

            if (score != null)
            {
                score.OnScoreChanged += UpdateScoreText;
                score.OnHighScoreChanged += OnHighScoreChangedHandler;
            }
            else
            {
                Debug.LogWarning("[UIHud] ScoreManager bulunamadı! Event subscription yapılamadı.");
            }

            if (spawnQueue != null)
            {
                spawnQueue.OnNextChanged += UpdateNextFruitPreview;
            }
            else
            {
                Debug.LogWarning("[UIHud] SpawnQueueManager bulunamadı! Event subscription yapılamadı.");
            }

            if (game != null)
            {
                game.OnGameStateChanged += HandleGameStateChanged;
            }
            else
            {
                Debug.LogWarning("[UIHud] GameManager bulunamadı! Event subscription yapılamadı.");
            }

            if (restartButton != null)
            {
                restartButton.onClick.AddListener(OnRestartButtonClicked);
            }

            if (gameOverRestartButton != null)
            {
                gameOverRestartButton.onClick.AddListener(OnRestartButtonClicked);
            }
        }

        private void OnDisable()
        {
            // Animasyonu durdur
            StopAnimationSequence();
            
            // Singleton'ları kullan (fallback olarak direkt referanslar)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            SpawnQueueManager spawnQueue = spawnQueueManager != null ? spawnQueueManager : FindFirstObjectByType<SpawnQueueManager>();
            GameManager game = gameManager != null ? gameManager : GameManager.Instance;

            if (score != null)
            {
                score.OnScoreChanged -= UpdateScoreText;
                score.OnHighScoreChanged -= OnHighScoreChangedHandler;
            }

            if (spawnQueue != null)
            {
                spawnQueue.OnNextChanged -= UpdateNextFruitPreview;
            }

            if (game != null)
            {
                game.OnGameStateChanged -= HandleGameStateChanged;
            }

            if (restartButton != null)
            {
                restartButton.onClick.RemoveListener(OnRestartButtonClicked);
            }

            if (gameOverRestartButton != null)
            {
                gameOverRestartButton.onClick.RemoveListener(OnRestartButtonClicked);
            }
        }
        
        private void OnDestroy()
        {
            // Animasyonu temizle
            StopAnimationSequence();
        }

        private void Start()
        {
            // Singleton kullan (fallback)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            
            if (score != null)
            {
                UpdateScoreText(score.CurrentScore);
            }

            // High Score'u DatabaseManager'dan al
            LoadHighScore();

            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);
            }
            
            // NextFruitImage RectTransform referansını al ve ilk pozisyonu kaydet
            if (nextFruitImage != null && nextFruitImage.rectTransform != null)
            {
                initialAnchoredPosition = nextFruitImage.rectTransform.anchoredPosition;
            }
        }

        /// <summary>
        /// En yüksek skoru DatabaseManager'dan yükler ve gösterir
        /// </summary>
        private void LoadHighScore()
        {
            try
            {
                if (Managers.DatabaseManager.Instance != null)
                {
                    // GetBestScore() kullan - veritabanı boşsa 0 döner
                    int bestScore = Managers.DatabaseManager.Instance.GetBestScore();
                    UpdateHighScoreText(bestScore);
                    Debug.Log($"[UIHud] En yüksek skor veritabanından yüklendi ve gösterildi: {bestScore}");
                }
                else
                {
                    Debug.LogWarning("[UIHud] DatabaseManager bulunamadı! High score 0 olarak gösteriliyor.");
                    UpdateHighScoreText(0);
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[UIHud] High score yüklenirken hata: {e.Message}");
                UpdateHighScoreText(0);
            }
        }

        private void UpdateScoreText(int score)
        {
            if (scoreText != null)
            {
                scoreText.text = string.Format(scoreFormat, score);
            }
        }

        private void UpdateHighScoreText(int highScore)
        {
            if (highScoreText != null)
            {
                highScoreText.text = string.Format(highScoreFormat, highScore);
            }
        }

        /// <summary>
        /// ScoreManager'ın OnHighScoreChanged event'i tetiklendiğinde çağrılır
        /// DatabaseManager'dan güncel high score'u alır ve gösterir
        /// </summary>
        private void OnHighScoreChangedHandler(int newHighScore)
        {
            // DatabaseManager'dan güncel high score'u al
            LoadHighScore();
        }

        private void UpdateNextFruitPreview(FruitTypeSO nextFruit)
        {
            if (nextFruitImage == null)
            {
                return;
            }
            
            // RectTransform referansını kontrol et
            if (nextFruitImage.rectTransform == null)
            {
                Debug.LogWarning("[UIHud] NextFruitImage RectTransform bulunamadı!");
                return;
            }
            
            if (nextFruit != null && nextFruit.sprite != null)
            {
                // Önceki animasyonu durdur
                StopAnimationSequence();
                
                // Yeni sprite'ı atamadan önce eski sprite'ı fade out yap
                PlayFruitChangeAnimation(nextFruit.sprite);
            }
            else
            {
                nextFruitImage.enabled = false;
                StopAnimationSequence();
            }
        }
        
        /// <summary>
        /// Meyve değişim animasyonunu oynatır
        /// ÖNEMLI: Pivot, Anchor ve Inspector pozisyonunu değiştirmez
        /// </summary>
        private void PlayFruitChangeAnimation(Sprite newSprite)
        {
            if (nextFruitImage == null || nextFruitImage.rectTransform == null)
            {
                return;
            }
            
            // Sequence oluştur
            animationSequence = DOTween.Sequence();
            
            // 1. Eski sprite'ı fade out yap (eğer sprite varsa)
            if (nextFruitImage.sprite != null && nextFruitImage.enabled)
            {
                animationSequence.Append(
                    nextFruitImage.DOFade(0f, fadeDuration)
                        .SetEase(Ease.InQuad)
                );
            }
            else
            {
                // İlk sprite ise direkt alpha'yı 0 yap
                Color color = nextFruitImage.color;
                color.a = 0f;
                nextFruitImage.color = color;
            }
            
            // 2. Yeni sprite'ı ata ve boyutlandır
            animationSequence.AppendCallback(() =>
            {
                nextFruitImage.sprite = newSprite;
                nextFruitImage.enabled = true;
                
                // SetNativeSize() çağır (sprite'ın orijinal boyutunu kullan)
                nextFruitImage.SetNativeSize();
                
                // Boyutu maksimum UI boyutuna göre sınırla (Scale kullanarak, sizeDelta değiştirmeden)
                ConstrainImageSize();
            });
            
            // 3. Yeni meyve pop efekti: Mevcut scale'den 1.2x büyüt
            Vector3 currentScale = nextFruitImage.rectTransform.localScale;
            Vector3 popScale = currentScale * 1.2f;
            
            animationSequence.Append(
                nextFruitImage.rectTransform.DOScale(popScale, entranceScaleDuration * 0.5f)
                    .SetEase(Ease.OutQuad)
            );
            
            // 4. Normal boyuta geri dön
            animationSequence.Append(
                nextFruitImage.rectTransform.DOScale(currentScale, entranceScaleDuration * 0.5f)
                    .SetEase(Ease.OutBack)
            );
            
            // 5. Yeni sprite'ı fade in yap (pop animasyonu ile birlikte)
            animationSequence.Insert(
                fadeDuration, // Fade'i pop ile aynı anda başlat
                nextFruitImage.DOFade(1f, fadeDuration)
                    .SetEase(Ease.OutQuad)
            );
            
            // 6. Zıplama efekti: Yukarı zıpla ve yerine düş (başlangıç pozisyonunu kullan)
            Vector2 bounceUpPosition = initialAnchoredPosition + Vector2.up * bounceHeight;
            
            animationSequence.Append(
                nextFruitImage.rectTransform.DOAnchorPos(bounceUpPosition, bounceDuration * 0.5f)
                    .SetEase(Ease.OutQuad)
            );
            
            animationSequence.Append(
                nextFruitImage.rectTransform.DOAnchorPos(initialAnchoredPosition, bounceDuration * 0.5f)
                    .SetEase(Ease.InQuad)
            );
            
            // Sequence tamamlandığında temizlik yap
            animationSequence.OnComplete(() =>
            {
                // Pozisyonu başlangıç pozisyonuna garantile (Inspector'daki değer)
                nextFruitImage.rectTransform.anchoredPosition = initialAnchoredPosition;
                
                // Scale'i ConstrainImageSize'dan gelen değerde garantile
                Vector2 finalSize = nextFruitImage.rectTransform.sizeDelta;
                float finalMaxDimension = Mathf.Max(finalSize.x, finalSize.y);
                if (finalMaxDimension > maxUISize)
                {
                    float finalScaleFactor = maxUISize / finalMaxDimension;
                    nextFruitImage.rectTransform.localScale = Vector3.one * finalScaleFactor;
                }
                else
                {
                    nextFruitImage.rectTransform.localScale = Vector3.one;
                }
                
                // Alpha'yı garantile
                Color finalColor = nextFruitImage.color;
                finalColor.a = 1f;
                nextFruitImage.color = finalColor;
            });
            
            Debug.Log("[UIHud] NextFruitImage animasyonu başlatıldı.");
        }
        
        /// <summary>
        /// Image boyutunu maksimum UI boyutuna göre sınırlar (Scale kullanarak)
        /// </summary>
        private void ConstrainImageSize()
        {
            if (nextFruitImage == null || nextFruitImage.rectTransform == null)
            {
                return;
            }
            
            Vector2 nativeSize = nextFruitImage.rectTransform.sizeDelta;
            float maxDimension = Mathf.Max(nativeSize.x, nativeSize.y);
            
            // Eğer boyut maksimum değeri aşıyorsa, scale ile orantılı olarak küçült
            // Ama asla boyutunu küçültme, sadece büyükse sınırla
            if (maxDimension > maxUISize)
            {
                float scaleFactor = maxUISize / maxDimension;
                nextFruitImage.rectTransform.localScale = Vector3.one * scaleFactor;
                
                Debug.Log($"[UIHud] NextFruitImage scale sınırlandı: {maxDimension} -> {maxUISize} (Scale: {scaleFactor})");
            }
            else
            {
                // Boyut zaten uygunsa scale'i 1 yap
                nextFruitImage.rectTransform.localScale = Vector3.one;
            }
        }
        
        /// <summary>
        /// Animasyon sequence'ini durdurur ve temizler
        /// </summary>
        private void StopAnimationSequence()
        {
            if (animationSequence != null && animationSequence.IsActive())
            {
                animationSequence.Kill();
                animationSequence = null;
            }
            
            // Değerleri sıfırla
            if (nextFruitImage != null && nextFruitImage.rectTransform != null)
            {
                nextFruitImage.rectTransform.localScale = Vector3.one;
                nextFruitImage.rectTransform.anchoredPosition = initialAnchoredPosition;
            }
            
            if (nextFruitImage != null)
            {
                Color color = nextFruitImage.color;
                color.a = 1f;
                nextFruitImage.color = color;
            }
        }

        public void OnRestartButtonClicked()
        {
            // GameManager'ın RestartGame metodunu kullan
            GameManager game = gameManager != null ? gameManager : GameManager.Instance;
            if (game != null)
            {
                game.RestartGame();
            }
            else
            {
                // Fallback: Scene reload
                Debug.LogWarning("[UIHud] GameManager bulunamadı, scene reload yapılıyor.");
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }

        private void HandleGameStateChanged(GameManager.GameState newState)
        {
            Debug.Log($"[UIHud] Game state değişti: {newState}");
            
            if (newState == GameManager.GameState.GameOver)
            {
                Debug.Log("[UIHud] Game Over state'i algılandı, panel gösteriliyor...");
                ShowGameOverPanel();
            }
            else if (newState == GameManager.GameState.Playing)
            {
                Debug.Log("[UIHud] Playing state'i algılandı, panel gizleniyor...");
                HideGameOverPanel();
            }
        }

        private void HideGameOverPanel()
        {
            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);
            }
        }

        private void ShowGameOverPanel()
        {
            if (gameOverPanel == null)
            {
                Debug.LogError("[UIHud] Game Over Panel referansı null! Inspector'da atanmamış olabilir.");
                return;
            }

            Debug.Log("[UIHud] Game Over Panel gösteriliyor...");
            gameOverPanel.SetActive(true);

            if (gameOverTitleText != null)
            {
                gameOverTitleText.text = "GAME OVER!";
            }
            else
            {
                Debug.LogWarning("[UIHud] Game Over Title Text referansı null!");
            }

            // Singleton kullan (fallback)
            ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
            
            if (finalScoreText != null && score != null)
            {
                finalScoreText.text = $"Score: {score.CurrentScore}";
            }
            else if (finalScoreText == null)
            {
                Debug.LogWarning("[UIHud] Final Score Text referansı null!");
            }
            else if (score == null)
            {
                Debug.LogWarning("[UIHud] ScoreManager bulunamadı!");
            }

            if (gameOverRestartButton != null)
            {
                gameOverRestartButton.gameObject.SetActive(true);
                gameOverRestartButton.interactable = true;
            }
            else
            {
                Debug.LogWarning("[UIHud] Game Over Restart Button referansı null!");
            }
        }
    }
}
