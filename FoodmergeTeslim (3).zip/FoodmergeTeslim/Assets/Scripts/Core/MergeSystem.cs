using UnityEngine;
using System.Collections.Generic;
using FruitMerge.Data;
using FruitMerge.Managers;

namespace FruitMerge.Core
{
    public class MergeSystem : MonoBehaviour
    {
        public static MergeSystem Instance { get; private set; }

        [Header("References")]
        [SerializeField] private FruitDatabaseSO fruitDatabase;
        [SerializeField] private PoolManager poolManager;
        [SerializeField] private FruitMerge.Managers.ScoreManager scoreManager;

        [Header("Settings")]
        [SerializeField] private float mergeDelay = 0.05f;
        [SerializeField] private Vector2 spawnOffset = new Vector2(0, 0.3f);

        [Header("Debug")]
        [SerializeField] private bool debugMode = false;

        private struct MergePair
        {
            public Fruit fruitA;
            public Fruit fruitB;
            public Vector2 contactPoint;

            public MergePair(Fruit a, Fruit b, Vector2 contact)
            {
                fruitA = a;
                fruitB = b;
                contactPoint = contact;
            }
        }

        private Queue<MergePair> mergeQueue = new Queue<MergePair>();
        private float mergeTimer = 0f;

        public System.Action<FruitTypeSO, Vector2> OnMergeCompleted;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
            }
            else
            {
                Destroy(gameObject);
                return;
            }

            if (fruitDatabase != null)
            {
                fruitDatabase.Initialize();
            }
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        public void OnFruitCollision(Fruit fruitA, Fruit fruitB, Vector2 contactPoint)
        {
            if (fruitA == null || fruitB == null) return;
            if (fruitA.IsLockedForMerge || fruitB.IsLockedForMerge) return;
            if (fruitA.FruitType == null || fruitB.FruitType == null) return;

            int idA = fruitA.FruitType.id;
            int idB = fruitB.FruitType.id;
            
            if (idA == idB)
            {
                // Her iki meyveyi de hemen kilitle (double merge'i önle)
                fruitA.LockForMerge();
                fruitB.LockForMerge();
                
                mergeQueue.Enqueue(new MergePair(fruitA, fruitB, contactPoint));
                
                if (debugMode)
                {
                    Debug.Log($"[MergeSystem] Merge pair eklendi: {fruitA.FruitType.displayName} + {fruitB.FruitType.displayName}");
                }
            }
        }

        private void FixedUpdate()
        {
            if (mergeQueue.Count > 0)
            {
                mergeTimer += Time.fixedDeltaTime;

                if (mergeTimer >= mergeDelay)
                {
                    ProcessMergeQueue();
                    mergeTimer = 0f;
                }
            }
        }

        private void ProcessMergeQueue()
        {
            while (mergeQueue.Count > 0)
            {
                MergePair pair = mergeQueue.Dequeue();

                // ValidateMergePair - lock kontrolünü KALDIRDIK (çünkü zaten lock'lılar)
                if (!ValidateMergePairForProcess(pair)) continue;

                PerformMerge(pair);
            }
        }
        
        // Yeni validation - lock kontrolü YOK
        private bool ValidateMergePairForProcess(MergePair pair)
        {
            if (pair.fruitA == null || pair.fruitB == null) return false;
            if (!pair.fruitA.gameObject.activeInHierarchy || !pair.fruitB.gameObject.activeInHierarchy) return false;
            
            // FruitType null kontrolleri
            if (pair.fruitA.FruitType == null || pair.fruitB.FruitType == null) return false;
            if (pair.fruitA.FruitType.id != pair.fruitB.FruitType.id) return false;

            return true;
        }

        private bool ValidateMergePair(MergePair pair)
        {
            if (pair.fruitA == null || pair.fruitB == null) return false;
            if (!pair.fruitA.gameObject.activeInHierarchy || !pair.fruitB.gameObject.activeInHierarchy) return false;
            if (pair.fruitA.IsLockedForMerge || pair.fruitB.IsLockedForMerge) return false;
            
            // FruitType null kontrolleri
            if (pair.fruitA.FruitType == null || pair.fruitB.FruitType == null) return false;
            if (pair.fruitA.FruitType.id != pair.fruitB.FruitType.id) return false;

            return true;
        }

        private void PerformMerge(MergePair pair)
        {
            // Null kontrolleri
            if (pair.fruitA == null || pair.fruitB == null)
            {
                Debug.LogError("[MergeSystem] PerformMerge: Fruit'lerden biri null!");
                return;
            }

            FruitTypeSO currentType = pair.fruitA.FruitType;
            if (currentType == null)
            {
                Debug.LogError("[MergeSystem] PerformMerge: currentType null!");
                return;
            }

            // Singleton kullan veya field kullan (fallback)
            FruitDatabaseSO db = fruitDatabase;
            if (db == null)
            {
                Debug.LogError("[MergeSystem] PerformMerge: fruitDatabase null! Inspector'da atayın.");
                return;
            }

            FruitTypeSO nextType = db.GetNextType(currentType);

            if (nextType == null)
            {
                Debug.Log($"[MergeSystem] {currentType.displayName} maksimum level!");
                return;
            }

            Vector2 spawnPosition = (pair.fruitA.transform.position + pair.fruitB.transform.position) / 2f;
            spawnPosition += spawnOffset;

            Vector2 averageVelocity = Vector2.zero;
            if (pair.fruitA.Rigidbody != null && pair.fruitB.Rigidbody != null)
            {
                averageVelocity = (pair.fruitA.Rigidbody.velocity + pair.fruitB.Rigidbody.velocity) / 2f;
            }

            // Singleton kullan veya field kullan (fallback)
            PoolManager pool = poolManager != null ? poolManager : PoolManager.Instance;
            if (pool == null)
            {
                Debug.LogError("[MergeSystem] PerformMerge: poolManager null! Inspector'da atayın veya sahnede PoolManager objesi olsun.");
                return;
            }

            pool.Return(pair.fruitA);
            pool.Return(pair.fruitB);

            Fruit newFruit = pool.Get(nextType, spawnPosition, isKinematic: false);

            if (newFruit != null)
            {
                if (newFruit.Rigidbody != null)
                {
                    newFruit.Rigidbody.velocity = averageVelocity * 0.5f;
                }

                // Singleton kullan veya field kullan (fallback)
                ScoreManager score = scoreManager != null ? scoreManager : ScoreManager.Instance;
                if (score != null)
                {
                    score.AddScore(currentType.scoreValue);
                }
                else
                {
                    Debug.LogWarning("[MergeSystem] ScoreManager bulunamadı, skor eklenmedi.");
                }

                OnMergeCompleted?.Invoke(nextType, spawnPosition);

                if (debugMode)
                {
                    Debug.Log($"[MergeSystem] MERGE: {currentType.displayName} -> {nextType.displayName}");
                }
            }
            else
            {
                Debug.LogError($"[MergeSystem] PerformMerge: Yeni fruit spawn edilemedi! {nextType.displayName}");
            }
        }

        public void ClearQueue()
        {
            mergeQueue.Clear();
            mergeTimer = 0f;
        }
    }
}
