using UnityEngine;
using System.Collections.Generic;
using FruitMerge.Data;

namespace FruitMerge.Core
{
    public class PoolManager : MonoBehaviour
    {
        // Singleton
        public static PoolManager Instance { get; private set; }

        [Header("Settings")]
        [SerializeField] private int initialPoolSizePerType = 10;
        [SerializeField] private Transform poolParent;

        [Header("Debug")]
        [SerializeField] private bool debugMode = false;

        private Dictionary<int, Queue<Fruit>> pools = new Dictionary<int, Queue<Fruit>>();
        private Dictionary<int, List<Fruit>> activeObjects = new Dictionary<int, List<Fruit>>();
        
        // Tüm aktif fruit'leri döndürmek için (performans optimizasyonu)
        public List<Fruit> GetAllActiveFruits()
        {
            List<Fruit> allActive = new List<Fruit>();
            foreach (var list in activeObjects.Values)
            {
                allActive.AddRange(list);
            }
            return allActive;
        }

        private void Awake()
        {
            // Singleton kurulumu
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[PoolManager] Birden fazla instance tespit edildi, yok ediliyor.");
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (poolParent == null)
            {
                poolParent = new GameObject("PoolParent").transform;
                poolParent.SetParent(transform);
            }

            Debug.Log("[PoolManager] Singleton kuruldu.");
        }

        public void WarmupPool(FruitTypeSO fruitType, int count)
        {
            if (fruitType == null || fruitType.prefab == null)
            {
                Debug.LogError($"[PoolManager] WarmupPool: FruitType veya prefab null!");
                return;
            }

            if (!pools.ContainsKey(fruitType.id))
            {
                pools[fruitType.id] = new Queue<Fruit>();
                activeObjects[fruitType.id] = new List<Fruit>();
            }

            for (int i = 0; i < count; i++)
            {
                CreateNewInstance(fruitType);
            }

            if (debugMode)
            {
                Debug.Log($"[PoolManager] {fruitType.displayName} icin {count} instance warmup yapildi.");
            }
        }

        public Fruit Get(FruitTypeSO fruitType, Vector2 position, bool isKinematic = false)
        {
            if (fruitType == null)
            {
                Debug.LogError("[PoolManager] Get: FruitType null!");
                return null;
            }

            // Pool yoksa oluştur
            if (!pools.ContainsKey(fruitType.id))
            {
                pools[fruitType.id] = new Queue<Fruit>();
                activeObjects[fruitType.id] = new List<Fruit>();
                WarmupPool(fruitType, initialPoolSizePerType);
            }

            Fruit fruit = null;

            // Pool'dan al veya yeni oluştur
            if (pools[fruitType.id].Count > 0)
            {
                fruit = pools[fruitType.id].Dequeue();
            }
            else
            {
                fruit = CreateNewInstance(fruitType);
            }

            if (fruit != null)
            {
                fruit.Initialize(fruitType, position, isKinematic);
                
                // Active objects listesine ekle (güvenli)
                if (!activeObjects.ContainsKey(fruitType.id))
                {
                    activeObjects[fruitType.id] = new List<Fruit>();
                }
                activeObjects[fruitType.id].Add(fruit);
            }

            return fruit;
        }

        public void Return(Fruit fruit)
        {
            if (fruit == null) return;

            FruitTypeSO fruitType = fruit.FruitType;
            if (fruitType == null)
            {
                Debug.LogWarning("[PoolManager] Return: FruitType null! Fruit destroy ediliyor.");
                Destroy(fruit.gameObject);
                return;
            }

            // Active objects'tan çıkar
            if (activeObjects.ContainsKey(fruitType.id))
            {
                activeObjects[fruitType.id].Remove(fruit);
            }

            // Pool'a geri ekle
            if (!pools.ContainsKey(fruitType.id))
            {
                pools[fruitType.id] = new Queue<Fruit>();
            }

            fruit.ResetForPool();
            fruit.transform.SetParent(poolParent);
            pools[fruitType.id].Enqueue(fruit);
        }

        public void ReturnAll()
        {
            // List'i kopyala (iteration sırasında değişebilir)
            List<Fruit> allActive = GetAllActiveFruits();

            foreach (var fruit in allActive)
            {
                if (fruit != null)
                {
                    Return(fruit);
                }
            }
        }

        private Fruit CreateNewInstance(FruitTypeSO fruitType)
        {
            GameObject instance = Instantiate(fruitType.prefab, poolParent);
            instance.SetActive(false);

            Fruit fruit = instance.GetComponent<Fruit>();
            if (fruit == null)
            {
                Debug.LogError($"[PoolManager] {fruitType.displayName} prefab'inda Fruit component yok!");
                Destroy(instance);
                return null;
            }

            // Layer ayarı - güvenli kontrol
            int fruitLayer = LayerMask.NameToLayer("Fruit");
            if (fruitLayer >= 0) // Layer bulunduysa (geçerli bir değer)
            {
                instance.layer = fruitLayer;
            }
            else
            {
                Debug.LogWarning("[PoolManager] 'Fruit' layer'ı bulunamadı! Prefab'ın layer'ı kullanılacak.");
            }

            if (!pools.ContainsKey(fruitType.id))
            {
                pools[fruitType.id] = new Queue<Fruit>();
                activeObjects[fruitType.id] = new List<Fruit>();
            }

            pools[fruitType.id].Enqueue(fruit);

            return fruit;
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }
    }
}
