using UnityEngine;
using System.Collections.Generic;

namespace FruitMerge.Managers
{
    public class ScoreManager : MonoBehaviour
    {
        // Singleton
        public static ScoreManager Instance { get; private set; }

        [Header("Score")]
        [SerializeField] private int currentScore = 0;
        [SerializeField] private int highScore = 0;

        public System.Action<int> OnScoreChanged;
        public System.Action<int> OnHighScoreChanged;

        public int CurrentScore => currentScore;
        public int HighScore => highScore;

        private void Awake()
        {
            // Singleton kurulumu
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[ScoreManager] Birden fazla instance tespit edildi, yok ediliyor.");
                Destroy(gameObject);
                return;
            }
            Instance = this;

            Debug.Log("[ScoreManager] Singleton kuruldu.");
        }

        private void Start()
        {
            LoadHighScore();
        }

        public void AddScore(int points)
        {
            if (points <= 0) return;

            currentScore += points;
            OnScoreChanged?.Invoke(currentScore);

            if (currentScore > highScore)
            {
                highScore = currentScore;
                OnHighScoreChanged?.Invoke(highScore);
                // Not: High score kaydetme işlemi artık oyun bittiğinde DatabaseManager tarafından yapılıyor
            }
        }

        public void ResetScore()
        {
            currentScore = 0;
            OnScoreChanged?.Invoke(currentScore);
        }

        /// <summary>
        /// En yüksek skoru DatabaseManager'dan yükler
        /// </summary>
        private void LoadHighScore()
        {
            if (DatabaseManager.Instance == null)
            {
                Debug.LogWarning("[ScoreManager] DatabaseManager bulunamadı! High score 0 olarak ayarlandı.");
                highScore = 0;
                OnHighScoreChanged?.Invoke(highScore);
                return;
            }

            try
            {
                List<HighScoreData> topScores = DatabaseManager.Instance.GetHighScores();
                
                if (topScores != null && topScores.Count > 0)
                {
                    // En yüksek skoru al (liste zaten score'a göre sıralı)
                    highScore = topScores[0].score;
                    Debug.Log($"[ScoreManager] En yüksek skor veritabanından yüklendi: {highScore}");
                }
                else
                {
                    highScore = 0;
                    Debug.Log("[ScoreManager] Veritabanında skor kaydı bulunamadı, high score 0.");
                }
                
                OnHighScoreChanged?.Invoke(highScore);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[ScoreManager] High score yüklenirken hata: {e.Message}");
                highScore = 0;
                OnHighScoreChanged?.Invoke(highScore);
            }
        }

        /// <summary>
        /// Oyun bittiğinde skoru veritabanına kaydeder
        /// </summary>
        public void SaveCurrentScore()
        {
            if (DatabaseManager.Instance == null)
            {
                Debug.LogError("[ScoreManager] DatabaseManager bulunamadı! Skor kaydedilemedi.");
                return;
            }

            try
            {
                bool success = DatabaseManager.Instance.SaveScore(currentScore);
                
                if (success)
                {
                    Debug.Log($"[ScoreManager] Skor veritabanına kaydedildi: {currentScore}");
                    
                    // High score'u yeniden yükle (kaydedilen skor en yüksekse güncellenir)
                    LoadHighScore();
                }
                else
                {
                    Debug.LogWarning("[ScoreManager] Skor veritabanına kaydedilemedi!");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[ScoreManager] Skor kaydedilirken hata: {e.Message}");
            }
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }
    }
}
