using UnityEngine;
using System.Collections.Generic;
using FruitMerge.Core;

namespace FruitMerge.Managers
{
    /// <summary>
    /// Manages the fail line detection system.
    /// When food stays above the fail line for too long, triggers game over.
    /// Fast-falling food passing through briefly should NOT trigger game over.
    /// </summary>
    [RequireComponent(typeof(BoxCollider2D))]
    public class FailLineManager : MonoBehaviour
    {
        [Header("Fail Line Settings")]
        [Tooltip("Time (in seconds) a food must stay above the fail line before game over")]
        [SerializeField] private float failTimeThreshold = 1.5f;
        
        [Header("Velocity Filter")]
        [Tooltip("Food moving faster than this speed (units/second) is considered 'falling fast' and won't trigger game over")]
        [SerializeField] private float fastFallVelocityThreshold = 2.0f;
        
        [Header("Debug")]
        [SerializeField] private bool showDebugLogs = true; // Enable by default for troubleshooting
        [SerializeField] private bool showGizmos = true;

        // Track each food that enters the fail zone
        private Dictionary<Fruit, FoodTimerData> foodsInZone = new Dictionary<Fruit, FoodTimerData>();

        public System.Action OnGameOver;

        private BoxCollider2D failLineCollider;
        
        /// <summary>
        /// GameManager'dan çağrılır - event'e subscribe olmak için
        /// </summary>
        public void SubscribeToGameOver(System.Action handler)
        {
            // Null kontrolü
            if (handler == null)
            {
                Debug.LogError("[FailLineManager] SubscribeToGameOver: Handler null!");
                return;
            }
            
            if (this == null || gameObject == null)
            {
                Debug.LogError("[FailLineManager] SubscribeToGameOver: Component veya GameObject null!");
                return;
            }
            
            if (!gameObject.activeInHierarchy)
            {
                Debug.LogWarning($"[FailLineManager] SubscribeToGameOver: GameObject {gameObject.name} inactive, subscribe ediliyor ama trigger çalışmayabilir!");
            }
            
            Debug.Log($"[FailLineManager] SubscribeToGameOver çağrıldı. GameObject: {gameObject.name}, Instance ID: {GetInstanceID()}");
            
            try
            {
                // Önce unsubscribe et (eğer daha önce subscribe edilmişse - duplicate subscription'ı önlemek için)
                OnGameOver -= handler;
                
                // Sonra subscribe et
                OnGameOver += handler;
                
                // Kontrol et
                bool isNull = OnGameOver == null;
                int subscriberCount = 0;
                if (!isNull)
                {
                    try
                    {
                        var invocationList = OnGameOver.GetInvocationList();
                        subscriberCount = invocationList != null ? invocationList.Length : 0;
                        
                        // Debug: Subscriber'ları listele
                        if (subscriberCount > 0 && showDebugLogs)
                        {
                            Debug.Log($"[FailLineManager] Subscriber'lar ({subscriberCount} adet):");
                            for (int i = 0; i < invocationList.Length; i++)
                            {
                                var method = invocationList[i].Method;
                                Debug.Log($"  [{i}] {method.DeclaringType?.Name}.{method.Name}");
                            }
                        }
                    }
                    catch (System.Exception e)
                    {
                        Debug.LogError($"[FailLineManager] Subscriber sayısı alınırken hata: {e.Message}");
                        subscriberCount = -1;
                    }
                }
                
                Debug.Log($"[FailLineManager] ✓ GameOver event'ine subscribe edildi. Event null mu? {isNull}, Subscriber sayısı: {subscriberCount}");
                
                if (isNull)
                {
                    Debug.LogError($"[FailLineManager] ⚠ Subscribe işlemi başarısız! Event hala null! GameObject: {gameObject.name}");
                }
                else if (subscriberCount == 0)
                {
                    Debug.LogError($"[FailLineManager] ⚠ Subscribe edildi ama subscriber sayısı 0! Event boş! GameObject: {gameObject.name}");
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[FailLineManager] SubscribeToGameOver işlemi sırasında hata: {e.Message}\n{e.StackTrace}");
            }
        }

        /// <summary>
        /// Data structure to track each food's timer and state
        /// </summary>
        private class FoodTimerData
        {
            public float timeInZone = 0f;
            public Vector2 lastPosition;
            public bool wasMovingFast = false;
        }

        private void Awake()
        {
            Debug.Log($"[FailLineManager] Awake çağrıldı. GameObject: {gameObject.name}, Instance ID: {GetInstanceID()}");
            
            failLineCollider = GetComponent<BoxCollider2D>();
            
            if (failLineCollider == null)
            {
                Debug.LogError("[FailLineManager] BoxCollider2D component not found! Adding one...");
                failLineCollider = gameObject.AddComponent<BoxCollider2D>();
            }

            // Configure collider as trigger
            failLineCollider.isTrigger = true;

            // Set layer if FailLine layer exists
            int failLineLayer = LayerMask.NameToLayer("FailLine");
            if (failLineLayer >= 0)
            {
                gameObject.layer = failLineLayer;
            }
            else
            {
                Debug.LogWarning("[FailLineManager] 'FailLine' layer not found. Using default layer.");
            }
            
            // Event'i initialize et (null olmamalı ama emin olmak için)
            if (OnGameOver == null)
            {
                Debug.Log("[FailLineManager] OnGameOver event null. GameManager Start'ta subscribe edecek.");
            }
        }

        private void Update()
        {
            // Don't check if game is not playing
            if (GameManager.Instance != null && GameManager.Instance.CurrentState != GameManager.GameState.Playing)
            {
                return;
            }

            // Update timers for all foods in the zone
            List<Fruit> foodsToRemove = new List<Fruit>();
            
            foreach (var kvp in foodsInZone)
            {
                Fruit food = kvp.Key;
                FoodTimerData timerData = kvp.Value;

                // Clean up null or inactive foods
                if (food == null || !food.gameObject.activeInHierarchy)
                {
                    foodsToRemove.Add(food);
                    continue;
                }

                // Only track dropped foods (not preview fruits)
                if (!food.IsDropped || food.IsLockedForMerge)
                {
                    foodsToRemove.Add(food);
                    continue;
                }

                // Check if food is still in the zone (using collider bounds check)
                // IMPORTANT: Only check bounds, don't rely on trigger exit (it might not fire reliably)
                if (!IsFoodInZone(food))
                {
                    foodsToRemove.Add(food);
                    if (showDebugLogs)
                    {
                        Debug.Log($"[FailLineManager] {food.FruitType?.displayName} exited fail zone. Timer cancelled.");
                    }
                    continue;
                }

                // Check if food is moving fast (falling quickly)
                // Only reset timer if food is consistently fast, not just for a single frame
                bool isMovingFast = IsFoodMovingFast(food);
                
                if (isMovingFast)
                {
                    // Fast-moving food: reset timer only if it wasn't already fast
                    // This prevents timer from resetting every frame when food is falling
                    if (!timerData.wasMovingFast)
                    {
                        timerData.timeInZone = 0f;
                        if (showDebugLogs)
                        {
                            Debug.Log($"[FailLineManager] {food.FruitType?.displayName} is falling fast. Timer reset.");
                        }
                    }
                    timerData.wasMovingFast = true;
                }
                else
                {
                    // Slow or stuck food: increment timer
                    // If food was fast before but now slow, don't reset timer, just continue counting
                    timerData.wasMovingFast = false;
                    timerData.timeInZone += Time.deltaTime;
                    timerData.lastPosition = food.transform.position;

                    if (showDebugLogs && Time.frameCount % 30 == 0) // Log every 0.5 seconds
                    {
                        Debug.Log($"[FailLineManager] {food.FruitType?.displayName} in zone: {timerData.timeInZone:F2}s / {failTimeThreshold:F2}s (Velocity: {food.Rigidbody?.velocity.y:F2})");
                    }

                    // Check if threshold exceeded
                    if (timerData.timeInZone >= failTimeThreshold)
                    {
                        if (showDebugLogs)
                        {
                            Debug.Log($"[FailLineManager] Threshold exceeded! {food.FruitType?.displayName} stayed for {timerData.timeInZone:F2}s");
                        }
                        TriggerGameOver(food);
                        return; // Exit immediately after game over
                    }
                }
            }

            // Remove foods that exited or became invalid
            foreach (var food in foodsToRemove)
            {
                foodsInZone.Remove(food);
            }
        }

        /// <summary>
        /// Check if food is currently within the fail zone using collider bounds
        /// </summary>
        private bool IsFoodInZone(Fruit food)
        {
            if (food == null || failLineCollider == null) return false;

            Collider2D foodCollider = food.GetComponent<Collider2D>();
            if (foodCollider == null) return false;

            // Check if food's top point is above the fail line
            Bounds foodBounds = foodCollider.bounds;
            Bounds failLineBounds = failLineCollider.bounds;

            // Food is in zone if its top point is above the fail line's bottom edge
            // Also check if food overlaps with the fail line trigger area
            bool isAboveLine = foodBounds.max.y >= failLineBounds.min.y;
            bool overlapsTrigger = foodBounds.Intersects(failLineBounds);
            
            // Food is in zone if it's above the line OR overlapping with the trigger
            return isAboveLine || overlapsTrigger;
        }

        /// <summary>
        /// Check if food is moving fast (falling quickly)
        /// </summary>
        private bool IsFoodMovingFast(Fruit food)
        {
            if (food == null) return false;

            Rigidbody2D rb = food.Rigidbody;
            if (rb == null || rb.bodyType != RigidbodyType2D.Dynamic)
            {
                return false;
            }

            // Check vertical velocity (downward movement)
            float verticalVelocity = rb.velocity.y;
            
            // If falling fast (negative Y velocity with high magnitude), consider it fast-moving
            // We check downward velocity (negative Y) - food falling down fast should not trigger game over
            // Use absolute value to catch fast movement in either direction
            float speed = Mathf.Abs(verticalVelocity);
            
            bool isFast = speed > fastFallVelocityThreshold;
            
            // Also check if food is moving upward (positive Y velocity) - this shouldn't reset timer
            // Only downward fast movement should reset timer
            if (verticalVelocity > 0)
            {
                // Food moving up - don't consider it fast for timer reset purposes
                return false;
            }
            
            return isFast;
        }

        /// <summary>
        /// Called when a food enters the fail zone trigger
        /// </summary>
        private void OnTriggerEnter2D(Collider2D other)
        {
            Fruit food = other.GetComponent<Fruit>();
            
            if (food == null) 
            {
                if (showDebugLogs)
                {
                    Debug.LogWarning($"[FailLineManager] OnTriggerEnter2D: Collider {other.name} has no Fruit component!");
                }
                return;
            }
            
            // Only track dropped foods (not preview fruits)
            if (!food.IsDropped)
            {
                if (showDebugLogs)
                {
                    Debug.Log($"[FailLineManager] {food.FruitType?.displayName} entered trigger but IsDropped=false. Ignoring.");
                }
                return;
            }
            
            if (food.IsLockedForMerge)
            {
                if (showDebugLogs)
                {
                    Debug.Log($"[FailLineManager] {food.FruitType?.displayName} entered trigger but IsLockedForMerge=true. Ignoring.");
                }
                return;
            }

            // Don't add if already tracking
            if (foodsInZone.ContainsKey(food))
            {
                if (showDebugLogs)
                {
                    Debug.Log($"[FailLineManager] {food.FruitType?.displayName} already in tracking dictionary.");
                }
                return;
            }

            // Initialize timer data for this food
            foodsInZone[food] = new FoodTimerData
            {
                timeInZone = 0f,
                lastPosition = food.transform.position,
                wasMovingFast = false
            };

            if (showDebugLogs)
            {
                Debug.Log($"[FailLineManager] ✓ {food.FruitType?.displayName} entered fail zone. Timer started. (Position: {food.transform.position.y:F2}, Velocity: {food.Rigidbody?.velocity.y:F2})");
            }
        }

        /// <summary>
        /// Called when a food exits the fail zone trigger
        /// </summary>
        private void OnTriggerExit2D(Collider2D other)
        {
            Fruit food = other.GetComponent<Fruit>();
            
            if (food == null) return;

            // Remove from tracking (timer cancelled)
            if (foodsInZone.ContainsKey(food))
            {
                foodsInZone.Remove(food);
                
                if (showDebugLogs)
                {
                    Debug.Log($"[FailLineManager] {food.FruitType?.displayName} exited fail zone. Timer cancelled.");
                }
            }
        }

        /// <summary>
        /// Trigger game over event
        /// </summary>
        private void TriggerGameOver(Fruit triggeringFood)
        {
            Debug.LogWarning($"[FailLineManager] ⚠ GAME OVER! {triggeringFood?.FruitType?.displayName} stayed above fail line for {failTimeThreshold}s");
            
            // Null kontrolü: GameObject ve component kontrolü
            if (this == null || gameObject == null)
            {
                Debug.LogError("[FailLineManager] TriggerGameOver çağrıldı ama component veya GameObject null!");
                return;
            }
            
            // Debug: Event durumunu kontrol et
            bool hasSubscribers = OnGameOver != null;
            int subscriberCount = 0;
            if (hasSubscribers)
            {
                try
                {
                    var invocationList = OnGameOver.GetInvocationList();
                    subscriberCount = invocationList != null ? invocationList.Length : 0;
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"[FailLineManager] Subscriber sayısı alınırken hata: {e.Message}");
                    subscriberCount = -1; // Hesaplanamadı
                }
            }
            
            Debug.Log($"[FailLineManager] OnGameOver event durumu - Null mu? {!hasSubscribers}, Subscriber sayısı: {subscriberCount}");
            Debug.Log($"[FailLineManager] FailLineManager GameObject: {gameObject.name}, Instance ID: {GetInstanceID()}");

            // Clear all tracking
            foodsInZone.Clear();

            // Trigger game over event (güvenli invoke)
            if (OnGameOver != null)
            {
                Debug.Log($"[FailLineManager] Invoking OnGameOver event...");
                try
                {
                    // Event'i güvenli şekilde invoke et
                    OnGameOver.Invoke();
                    Debug.Log("[FailLineManager] OnGameOver event başarıyla invoke edildi.");
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"[FailLineManager] OnGameOver event invoke edilirken hata: {e.Message}\n{e.StackTrace}");
                }
            }
            else
            {
                Debug.LogError("[FailLineManager] OnGameOver event is NULL! GameManager is not subscribed!");
                Debug.LogError("[FailLineManager] Lütfen GameManager'ın FailLineManager referansını ve SubscribeToFailLineManager() metodunu kontrol edin!");
            }
        }

        /// <summary>
        /// Reset the fail line (clear all tracking)
        /// </summary>
        public void ResetFailLine()
        {
            foodsInZone.Clear();
            
            if (showDebugLogs)
            {
                Debug.Log("[FailLineManager] Fail line reset.");
            }
        }

        /// <summary>
        /// Visualize the fail line in the editor
        /// </summary>
        private void OnDrawGizmos()
        {
            if (!showGizmos) return;

            BoxCollider2D col = GetComponent<BoxCollider2D>();
            if (col == null) return;

            // Draw fail line
            Gizmos.color = foodsInZone.Count > 0 ? Color.red : Color.yellow;
            
            Vector3 center = transform.position + (Vector3)col.offset;
            Vector3 size = col.size;
            
            Gizmos.DrawWireCube(center, size);
            
            // Draw a line at the bottom edge (the actual fail line)
            Vector3 lineStart = center + new Vector3(-size.x / 2f, -size.y / 2f, 0f);
            Vector3 lineEnd = center + new Vector3(size.x / 2f, -size.y / 2f, 0f);
            
            Gizmos.color = Color.red;
            Gizmos.DrawLine(lineStart, lineEnd);
        }
    }
}
