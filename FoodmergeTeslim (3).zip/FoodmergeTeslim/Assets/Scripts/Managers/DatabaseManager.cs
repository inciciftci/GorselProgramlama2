using System;
using System.Collections.Generic;
using System.Data;
using Mono.Data.SqliteClient;
using UnityEngine;

namespace FruitMerge.Managers
{
    /// <summary>
    /// SQLite veritabanı yöneticisi - Skorları kaydeder ve yükler
    /// </summary>
    public class DatabaseManager : MonoBehaviour
    {
        private static DatabaseManager instance;
        public static DatabaseManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = FindFirstObjectByType<DatabaseManager>();
                    if (instance == null)
                    {
                        GameObject go = new GameObject("DatabaseManager");
                        instance = go.AddComponent<DatabaseManager>();
                        DontDestroyOnLoad(go);
                    }
                }
                return instance;
            }
        }

        [Header("Database Settings")]
        [SerializeField] private string databaseFileName = "GameData.db";
        [SerializeField] private string defaultPlayerName = "Player";
        
        private string databasePath;
        private string connectionString;
        private IDbConnection connection;
        
        /// <summary>
        /// Connection string'i Application.persistentDataPath kullanarak oluşturur
        /// </summary>
        private string GetConnectionString()
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                // Her zaman Application.persistentDataPath kullan
                databasePath = System.IO.Path.Combine(Application.persistentDataPath, databaseFileName);
                connectionString = "URI=file:" + databasePath;
            }
            return connectionString;
        }

        private void Awake()
        {
            if (instance != null && instance != this)
            {
                Destroy(gameObject);
                return;
            }

            instance = this;
            DontDestroyOnLoad(gameObject);

            InitializeDatabase();
        }

        /// <summary>
        /// Veritabanını başlatır ve Scores tablosunu oluşturur
        /// </summary>
        private void InitializeDatabase()
        {
            try
            {
                // Connection string'i oluştur (Application.persistentDataPath kullanarak)
                string connString = GetConnectionString();

                Debug.Log($"[DatabaseManager] ========== VERİTABANI BAŞLATILIYOR ==========");
                Debug.Log($"[DatabaseManager] Veritabanı yolu: {databasePath}");
                Debug.Log($"[DatabaseManager] Connection string: {connString}");
                Debug.Log($"[DatabaseManager] Dosya mevcut mu: {System.IO.File.Exists(databasePath)}");

                // SQLite bağlantısını oluştur ve aç
                connection = new SqliteConnection(connString);
                connection.Open();
                Debug.Log($"[DatabaseManager] ✓ Bağlantı açıldı. State: {connection.State}");

                // Scores tablosunu oluştur (yoksa)
                CreateScoresTable();

                // Tablo oluşturuldu mu kontrol et
                VerifyTableExists();

                // Bağlantıyı kapat (her işlemde açıp kapatacağız)
                connection.Close();

                Debug.Log("[DatabaseManager] ========== VERİTABANI BAŞARILI ==========");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] ❌ Veritabanı başlatma hatası: {ex.Message}\nStack Trace: {ex.StackTrace}");
            }
        }

        /// <summary>
        /// Scores tablosunu oluşturur (yoksa)
        /// </summary>
        private void CreateScoresTable()
        {
            try
            {
                Debug.Log("[DatabaseManager] CREATE TABLE sorgusu çalıştırılıyor...");
                
                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = @"
                        CREATE TABLE IF NOT EXISTS Scores (
                            ID INTEGER PRIMARY KEY AUTOINCREMENT,
                            PlayerName TEXT NOT NULL,
                            Score INTEGER NOT NULL,
                            Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                        )";

                    int result = command.ExecuteNonQuery();
                    Debug.Log($"[DatabaseManager] ✓ CREATE TABLE sorgusu başarıyla çalıştırıldı. Sonuç: {result}");
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] ❌ Tablo oluşturma hatası: {ex.Message}\nStack Trace: {ex.StackTrace}");
            }
        }

        /// <summary>
        /// Scores tablosunun var olduğunu kontrol eder
        /// </summary>
        private void VerifyTableExists()
        {
            try
            {
                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name='Scores'";
                    
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string tableName = reader.GetString(0);
                            Debug.Log($"[DatabaseManager] ✓ Tablo doğrulandı: {tableName}");
                            
                            // Tablo yapısını da kontrol et
                            VerifyTableStructure();
                        }
                        else
                        {
                            Debug.LogError("[DatabaseManager] ❌ UYARI: Scores tablosu bulunamadı!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] Tablo doğrulama hatası: {ex.Message}");
            }
        }

        /// <summary>
        /// Scores tablosunun yapısını kontrol eder
        /// </summary>
        private void VerifyTableStructure()
        {
            try
            {
                using (IDbCommand command = connection.CreateCommand())
                {
                    command.CommandText = "PRAGMA table_info(Scores)";
                    
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        Debug.Log("[DatabaseManager] Tablo yapısı:");
                        while (reader.Read())
                        {
                            string columnName = reader.GetString(1);
                            string columnType = reader.GetString(2);
                            Debug.Log($"  - {columnName} ({columnType})");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] Tablo yapısı kontrol hatası: {ex.Message}");
            }
        }

        /// <summary>
        /// Skoru veritabanına kaydeder
        /// </summary>
        /// <param name="score">Kaydedilecek skor</param>
        /// <param name="playerName">Oyuncu adı (opsiyonel)</param>
        /// <returns>Başarılı ise true, değilse false</returns>
        public bool SaveScore(int score, string playerName = null)
        {
            if (score < 0)
            {
                Debug.LogWarning("[DatabaseManager] Negatif skor kaydedilemez!");
                return false;
            }

            if (string.IsNullOrEmpty(playerName))
            {
                playerName = defaultPlayerName;
            }

            try
            {
                using (IDbConnection dbConnection = new SqliteConnection(GetConnectionString()))
                {
                    dbConnection.Open();

                    using (IDbCommand command = dbConnection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Scores (PlayerName, Score) VALUES (@playerName, @score)";

                        // Parametreleri ekle (SQL Injection koruması)
                        IDbDataParameter paramPlayerName = command.CreateParameter();
                        paramPlayerName.ParameterName = "@playerName";
                        paramPlayerName.Value = playerName;
                        command.Parameters.Add(paramPlayerName);

                        IDbDataParameter paramScore = command.CreateParameter();
                        paramScore.ParameterName = "@score";
                        paramScore.Value = score;
                        command.Parameters.Add(paramScore);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            Debug.Log($"[DatabaseManager] Skor kaydedildi: {playerName} - {score}");
                            return true;
                        }
                        else
                        {
                            Debug.LogWarning("[DatabaseManager] Skor kaydedilemedi!");
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] Skor kaydetme hatası: {ex.Message}\nStack Trace: {ex.StackTrace}");
                return false;
            }
        }

        /// <summary>
        /// En yüksek 5 skoru listeler (varsayılan)
        /// </summary>
        /// <returns>En yüksek 5 skor listesi (boşsa boş liste döner, hata vermez)</returns>
        public List<HighScoreData> GetHighScores()
        {
            return GetHighScores(5); // Varsayılan limit: 5
        }

        /// <summary>
        /// En yüksek skorları listeler (özelleştirilebilir limit)
        /// </summary>
        /// <param name="limit">Döndürülecek maksimum skor sayısı</param>
        /// <returns>En yüksek skorlar listesi (boşsa boş liste döner, hata vermez)</returns>
        public List<HighScoreData> GetHighScores(int limit)
        {
            List<HighScoreData> highScores = new List<HighScoreData>();

            try
            {
                using (IDbConnection dbConnection = new SqliteConnection(GetConnectionString()))
                {
                    dbConnection.Open();

                    using (IDbCommand command = dbConnection.CreateCommand())
                    {
                        command.CommandText = $@"
                            SELECT ID, PlayerName, Score, Timestamp 
                            FROM Scores 
                            ORDER BY Score DESC 
                            LIMIT {limit}";

                        using (IDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                HighScoreData data = new HighScoreData
                                {
                                    id = reader.GetInt32(0),
                                    playerName = reader.GetString(1),
                                    score = reader.GetInt32(2),
                                    timestamp = reader.IsDBNull(3) ? "" : reader.GetString(3)
                                };

                                highScores.Add(data);
                            }
                        }
                    }
                }

                if (highScores.Count == 0)
                {
                    Debug.Log("[DatabaseManager] Veritabanında skor kaydı bulunamadı (tablo boş).");
                }
                else
                {
                    Debug.Log($"[DatabaseManager] {highScores.Count} adet high score yüklendi.");
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] High score yükleme hatası: {ex.Message}\nStack Trace: {ex.StackTrace}");
            }

            return highScores;
        }

        /// <summary>
        /// En yüksek skoru döndürür. Veritabanı boşsa 0 döner.
        /// </summary>
        /// <returns>En yüksek skor</returns>
        public int GetBestScore()
        {
            try
            {
                List<HighScoreData> scores = GetHighScores();
                
                if (scores != null && scores.Count > 0)
                {
                    int bestScore = scores[0].score;
                    Debug.Log($"[DatabaseManager] En yüksek skor: {bestScore}");
                    return bestScore;
                }
                else
                {
                    Debug.Log("[DatabaseManager] Veritabanı boş, best score 0 döndürülüyor.");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] Best score alma hatası: {ex.Message}");
                return 0;
            }
        }

        /// <summary>
        /// Tüm skorları siler (debug amaçlı)
        /// </summary>
        public void ClearAllScores()
        {
            try
            {
                using (IDbConnection dbConnection = new SqliteConnection(GetConnectionString()))
                {
                    dbConnection.Open();

                    using (IDbCommand command = dbConnection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Scores";
                        int rowsAffected = command.ExecuteNonQuery();
                        Debug.Log($"[DatabaseManager] {rowsAffected} adet skor silindi.");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] Skorları silme hatası: {ex.Message}\nStack Trace: {ex.StackTrace}");
            }
        }

        /// <summary>
        /// Veritabanındaki toplam skor sayısını döndürür
        /// </summary>
        public int GetTotalScoreCount()
        {
            try
            {
                using (IDbConnection dbConnection = new SqliteConnection(GetConnectionString()))
                {
                    dbConnection.Open();

                    using (IDbCommand command = dbConnection.CreateCommand())
                    {
                        command.CommandText = "SELECT COUNT(*) FROM Scores";
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        return count;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DatabaseManager] Skor sayısı alma hatası: {ex.Message}\nStack Trace: {ex.StackTrace}");
                return 0;
            }
        }

        private void OnDestroy()
        {
            // Cleanup
            if (instance == this)
            {
                instance = null;
            }
        }

        #if UNITY_EDITOR
        [ContextMenu("Test - Save Random Score")]
        private void TestSaveRandomScore()
        {
            int randomScore = UnityEngine.Random.Range(100, 10000);
            SaveScore(randomScore, "TestPlayer");
        }

        [ContextMenu("Test - Print High Scores")]
        private void TestPrintHighScores()
        {
            List<HighScoreData> scores = GetHighScores();
            Debug.Log("=== HIGH SCORES ===");
            for (int i = 0; i < scores.Count; i++)
            {
                Debug.Log($"{i + 1}. {scores[i].playerName}: {scores[i].score} (ID: {scores[i].id}, Timestamp: {scores[i].timestamp})");
            }
        }

        [ContextMenu("Test - Clear All Scores")]
        private void TestClearAllScores()
        {
            ClearAllScores();
        }

        [ContextMenu("Test - Get Total Score Count")]
        private void TestGetTotalScoreCount()
        {
            int count = GetTotalScoreCount();
            Debug.Log($"Toplam skor sayısı: {count}");
        }
        #endif
    }

    /// <summary>
    /// High score verisi için data sınıfı
    /// </summary>
    [System.Serializable]
    public class HighScoreData
    {
        public int id;
        public string playerName;
        public int score;
        public string timestamp;

        public override string ToString()
        {
            return $"{playerName}: {score} (ID: {id}, Time: {timestamp})";
        }
    }
}
