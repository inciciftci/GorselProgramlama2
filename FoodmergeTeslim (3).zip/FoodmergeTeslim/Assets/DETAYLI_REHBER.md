# 📱 Samsung Galaxy S10 - Detaylı Kurulum Rehberi

Bu rehber, Samsung Galaxy S10 telefonunda ergonomik bir görüntü için tüm ayarları adım adım içerir.

---

## 📐 Samsung Galaxy S10 Özellikleri

- **Ekran Çözünürlüğü:** 1440 x 3040 piksel
- **Aspect Ratio:** 19:9 (yaklaşık 2.1:1)
- **Ekran Boyutu:** 6.1 inç
- **Piksel Yoğunluğu:** ~550 ppi

**Hedef:** En küçük sprite'tan (ID 0) en büyüğe (ID 9) kadar tüm yiyecekler ekranda ergonomik görünsün ve dokunma için uygun boyutta olsun.

---

## 1️⃣ SPRITE IMPORT AYARLARI

### Adım 1: Sprite'ları Seçme

1. Unity Editor'da **Project** penceresini aç
2. `Assets/Sprites` klasörüne git
3. **Tüm sprite dosyalarını seç:**
   - `Burned_Toast.png`
   - `Crispy_Toast.png`
   - `Baked_Banana.png`
   - `Banana_Milk.png`
   - `Banana_French_Toast.png`
   - `Egg_Cheese_Sandwich.png`
   - `Egg_Salami_Sandwich.png`
   - `Egg_Cheese_Salami_Sandwich.png`
   - `Banana_Bread.png`
   - `Banana_Pancakes.png`

**Nasıl Seçilir:**
- İlk sprite'a tıkla
- **Ctrl** (Windows) veya **Cmd** (Mac) tuşuna basılı tut
- Son sprite'a tıkla
- Veya **Ctrl+A** (Windows) veya **Cmd+A** (Mac) ile hepsini seç

### Adım 2: Inspector'da Ayarlama

1. **Inspector** penceresini aç (sağ tarafta)
2. Şu ayarları yap:

```
Texture Type: Sprite (2D and UI)
Sprite Mode: Single
Pixels Per Unit: 100
Filter Mode: Bilinear
Compression: None (veya Low - kalite için)
Max Size: 2048
```

**Detaylı Açıklama:**
- **Pixels Per Unit: 100** → Bu değer tüm sprite'lar için aynı olmalı. 100 pixel = 1 Unity unit demektir.
- **Filter Mode: Bilinear** → Yumuşak görüntü için. Pixel art istiyorsan "Point (no filter)" seç.
- **Compression: None** → En yüksek kalite. Performans sorunu varsa "Low" seç.

### Adım 3: Apply Butonu

1. Inspector'ın altında **Apply** butonuna tıkla
2. Tüm sprite'lar için ayarlar uygulanacak

**Kontrol:** Her sprite'ı tek tek seçip Inspector'da Pixels Per Unit'in 100 olduğunu kontrol et.

---

## 2️⃣ KAMERA AYARLARI

### Adım 1: Main Camera'yı Bulma

1. **Hierarchy** penceresinde (sol tarafta) **Main Camera** objesini bul
2. Üzerine tıkla

### Adım 2: Kamera Ayarları

**Inspector** penceresinde şu ayarları yap:

```
Transform:
  Position: X=0, Y=4, Z=-10

Camera:
  Projection: Orthographic
  Size: 10
  Background: Koyu renk (Color picker'dan #1a1a2e gibi)
```

**Detaylı Açıklama:**
- **Position Y=4** → Kamerayı biraz yukarı kaldırır, oyun alanını daha iyi görürsün
- **Size: 10** → Samsung S10 için optimize edilmiş değer. Bu değer:
  - Ekranın yüksekliği = 20 Unity unit
  - En küçük sprite (ID 0) yaklaşık 0.5-0.7 unit görünecek
  - En büyük sprite (ID 9) yaklaşık 1.5-2.0 unit görünecek
- **Background Color** → Koyu renk oyun alanını daha iyi gösterir

**Renk Ayarlama:**
1. Background alanındaki renk kutusuna tıkla
2. Color picker açılır
3. Hex alanına `#1a1a2e` yaz veya manuel seç
4. Alpha: 255 (tam opak)

### Adım 3: Test Etme

1. **Game View** penceresini aç (Scene view'un yanında)
2. **Aspect Ratio** dropdown'ından **9:19** seç (Samsung S10)
3. Kamera görüntüsünü kontrol et

---

## 3️⃣ CANVAS AYARLARI

### Adım 1: Canvas Bulma

1. **Hierarchy**'de **Canvas** objesini bul
2. Yoksa: Hierarchy'de sağ tık → **UI > Canvas**

### Adım 2: Canvas Ayarları

**Inspector**'da şu ayarları yap:

```
Canvas:
  Render Mode: Screen Space - Overlay
  UI Scale Mode: Scale With Screen Size
  Reference Resolution: X=1080, Y=1920
  Screen Match Mode: Match Width Or Height
  Match: 0.5
```

**Detaylı Açıklama:**
- **Reference Resolution: 1080x1920** → Samsung S10'ın gerçek çözünürlüğü 1440x3040 ama Unity'de yaygın olarak 1080x1920 kullanılır
- **Match: 0.5** → Width ve Height arasında denge. 0 = sadece width, 1 = sadece height
- **0.5** → Her iki yönde de scale edilir, daha dengeli görünüm

### Adım 3: Canvas Scaler Kontrolü

**Canvas Scaler** component'i otomatik eklenmiş olmalı. Yoksa:
1. Canvas'a **Canvas Scaler** component ekle
2. Yukarıdaki ayarları yap

---

## 4️⃣ FRUITTYPE SCRIPTABLEOBJECT AYARLARI

### Adım 1: FruitType SO'ları Oluşturma

1. **Project** penceresinde `Assets/ScriptableObjects/FruitTypes` klasörüne git
2. Sağ tık → **Create > FruitMerge > FruitType**
3. İsim: `Food_BurnedToast`
4. Aynı işlemi 10 kez tekrarla, her biri için farklı isimler:

| Sıra | İsim |
|------|------|
| 1 | `Food_BurnedToast` |
| 2 | `Food_CrispyToast` |
| 3 | `Food_BakedBanana` |
| 4 | `Food_BananaMilk` |
| 5 | `Food_BananaFrenchToast` |
| 6 | `Food_EggCheeseSandwich` |
| 7 | `Food_EggSalamiSandwich` |
| 8 | `Food_EggCheeseSalamiSandwich` |
| 9 | `Food_BananaBread` |
| 10 | `Food_BananaPancakes` |

### Adım 2: Her FruitType SO'yu Ayarlama

**Food_BurnedToast (ID: 0) - En Küçük:**

1. `Food_BurnedToast` SO'sunu seç
2. **Inspector**'da:

```
Identification:
  id: 0
  displayName: Burned Toast

Visual:
  sprite: Burned_Toast.png (Project'ten sürükle)
  prefab: Food_BurnedToast (şimdilik boş bırak, sonra dolduracağız)

Merge Settings:
  nextType: Food_CrispyToast (diğer SO'yu sürükle)

Game Values:
  scoreValue: 10

Physics:
  colliderRadius: 0.25
  optionalMaterial: FruitBouncy (Materials klasöründen)
```

**Food_CrispyToast (ID: 1):**

```
id: 1
displayName: Crispy Toast
sprite: Crispy_Toast.png
prefab: Food_CrispyToast (şimdilik boş)
nextType: Food_BakedBanana
scoreValue: 20
colliderRadius: 0.35
optionalMaterial: FruitBouncy
```

**Food_BakedBanana (ID: 2):**

```
id: 2
displayName: Baked Banana
sprite: Baked_Banana.png
prefab: Food_BakedBanana (şimdilik boş)
nextType: Food_BananaMilk
scoreValue: 40
colliderRadius: 0.45
optionalMaterial: FruitBouncy
```

**Food_BananaMilk (ID: 3):**

```
id: 3
displayName: Banana Milk
sprite: Banana_Milk.png
prefab: Food_BananaMilk (şimdilik boş)
nextType: Food_BananaFrenchToast
scoreValue: 80
colliderRadius: 0.55
optionalMaterial: FruitBouncy
```

**Food_BananaFrenchToast (ID: 4):**

```
id: 4
displayName: Banana French Toast
sprite: Banana_French_Toast.png
prefab: Food_BananaFrenchToast (şimdilik boş)
nextType: Food_EggCheeseSandwich
scoreValue: 160
colliderRadius: 0.65
optionalMaterial: FruitBouncy
```

**Food_EggCheeseSandwich (ID: 5):**

```
id: 5
displayName: Egg Cheese Sandwich
sprite: Egg_Cheese_Sandwich.png
prefab: Food_EggCheeseSandwich (şimdilik boş)
nextType: Food_EggSalamiSandwich
scoreValue: 320
colliderRadius: 0.75
optionalMaterial: FruitBouncy
```

**Food_EggSalamiSandwich (ID: 6):**

```
id: 6
displayName: Egg Salami Sandwich
sprite: Egg_Salami_Sandwich.png
prefab: Food_EggSalamiSandwich (şimdilik boş)
nextType: Food_EggCheeseSalamiSandwich
scoreValue: 640
colliderRadius: 0.85
optionalMaterial: FruitBouncy
```

**Food_EggCheeseSalamiSandwich (ID: 7):**

```
id: 7
displayName: Full Sandwich
sprite: Egg_Cheese_Salami_Sandwich.png
prefab: Food_EggCheeseSalamiSandwich (şimdilik boş)
nextType: Food_BananaBread
scoreValue: 1280
colliderRadius: 0.95
optionalMaterial: FruitBouncy
```

**Food_BananaBread (ID: 8):**

```
id: 8
displayName: Banana Bread
sprite: Banana_Bread.png
prefab: Food_BananaBread (şimdilik boş)
nextType: Food_BananaPancakes
scoreValue: 2560
colliderRadius: 1.05
optionalMaterial: FruitBouncy
```

**Food_BananaPancakes (ID: 9) - En Büyük:**

```
id: 9
displayName: Banana Pancakes
sprite: Banana_Pancakes.png
prefab: Food_BananaPancakes (şimdilik boş)
nextType: null (son seviye, boş bırak)
scoreValue: 5120
colliderRadius: 1.15
optionalMaterial: FruitBouncy
```

**Önemli Notlar:**
- **colliderRadius** değerleri sprite'ların ekranda görünen boyutlarını kontrol eder
- 0.25 (en küçük) → 1.15 (en büyük) arasında artar
- Formül: `scaleMultiplier = colliderRadius / 0.3`
- Bu değerler Samsung S10 için optimize edilmiştir

---

## 5️⃣ FRUITTYPE DATABASE OLUŞTURMA

### Adım 1: Database Oluşturma

1. **Project** penceresinde `Assets/ScriptableObjects` klasörüne git
2. Sağ tık → **Create > FruitMerge > FruitDatabase**
3. İsim: `FruitDatabase`

### Adım 2: Types Listesini Doldurma

1. `FruitDatabase` SO'sunu seç
2. **Inspector**'da **Types** listesini bul
3. **Size** alanına `10` yaz
4. Her element'e sırayla FruitType SO'ları sürükle:

```
Element 0: Food_BurnedToast
Element 1: Food_CrispyToast
Element 2: Food_BakedBanana
Element 3: Food_BananaMilk
Element 4: Food_BananaFrenchToast
Element 5: Food_EggCheeseSandwich
Element 6: Food_EggSalamiSandwich
Element 7: Food_EggCheeseSalamiSandwich
Element 8: Food_BananaBread
Element 9: Food_BananaPancakes
```

**Nasıl Sürüklenir:**
1. Project penceresinde FruitType SO'yu bul
2. Mouse ile tut
3. Inspector'daki ilgili element alanına sürükle
4. Bırak

### Adım 3: Max Spawn Type ID Ayarlama

**Inspector**'da:
```
Max Spawn Type ID: 2
```

**Açıklama:**
- Bu değer spawn edilebilecek maksimum meyve ID'sini belirler
- 2 = Sadece ID 0, 1, 2 spawn olur (Burned Toast, Crispy Toast, Baked Banana)
- Diğer yiyecekler sadece merge ile elde edilir

---

## 6️⃣ PREFAB OLUŞTURMA VE COLLIDER AYARLARI

### Adım 1: İlk Prefab'ı Oluşturma (Food_BurnedToast)

#### 6.1.1 Hierarchy'de Obje Oluşturma

1. **Hierarchy** penceresinde sağ tık → **Create Empty**
2. İsim: `Food_BurnedToast`
3. **Transform** component'inde:
   ```
   Position: (0, 0, 0)
   Rotation: (0, 0, 0)
   Scale: (1, 1, 1)
   ```

#### 6.1.2 Component'leri Ekleme

**Sprite Renderer:**
1. **Add Component** butonuna tıkla
2. **Sprite Renderer** yaz ve seç
3. **Sprite** alanına `Burned_Toast` sprite'ını sürükle

**Rigidbody2D:**
1. **Add Component** → **Rigidbody2D**
2. Ayarlar:
   ```
   Body Type: Dynamic
   Material: FruitBouncy (Materials klasöründen)
   Simulated: ✅
   Use Auto Mass: ❌
   Mass: 0.5
   Linear Drag: 0.5
   Angular Drag: 0.5
   Gravity Scale: 2
   Collision Detection: Continuous
   Sleeping Mode: Start Awake
   Interpolate: Interpolate
   Constraints:
     Freeze Rotation: ✅ (Z ekseninde dönme yok)
   ```

**BoxCollider2D:**
1. **Add Component** → **Box Collider 2D**
2. Ayarlar:
   ```
   Is Trigger: ❌
   Used By Effector: ❌
   Material: FruitBouncy
   Offset: (0, 0)
   Size: Hesapla (aşağıda açıklanacak)
   ```

**Fruit Script:**
1. **Add Component** → **Fruit** (script)
2. Script otomatik olarak eklenir

**Layer Ayarlama:**
1. Inspector'ın üst kısmında **Layer** dropdown'ına tıkla
2. **Fruit** layer'ını seç

#### 6.1.3 BoxCollider2D Size Hesaplama

**Yöntem 1: Sprite Boyutuna Göre**

1. **Sprite Renderer** component'inde sprite'ı seç
2. Sprite'ın **pixel boyutunu** gör (örn: 100x100)
3. **Formül:**
   ```
   Gerçek Boyut = Pixel Boyutu / 100
   Scale Çarpanı = colliderRadius / 0.3 = 0.25 / 0.3 = 0.83
   Collider Size = Gerçek Boyut * Scale Çarpanı * 0.9
   ```

**Örnek Hesaplama:**
- Sprite: 100x100 pixel
- Gerçek Boyut: 100/100 = 1.0 unit
- Scale Çarpanı: 0.83
- Collider Size: 1.0 * 0.83 * 0.9 = **0.75 unit**

**BoxCollider2D Size:** `(0.75, 0.75)`

**Yöntem 2: Görsel Ayarlama**

1. Prefab'ı **Scene**'e sürükle (test için)
2. **Scene View**'da sprite'ı gör
3. BoxCollider2D'nin **yeşil çerçevesini** gör
4. **Edit Collider** moduna geç (BoxCollider2D component'inde)
5. Yeşil çerçeveyi sprite'ın kenarlarına hizala
6. Size değerlerini Inspector'da ayarla

#### 6.1.4 Prefab Kaydetme

1. `Food_BurnedToast` objesini **Project** penceresindeki `Assets/Prefabs/Fruits` klasörüne sürükle
2. Prefab oluşturulur
3. **Hierarchy**'deki orijinal objeyi sil (Delete tuşu)

### Adım 2: Diğer BoxCollider2D Prefab'ları

**Food_CrispyToast (ID: 1):**

Aynı adımları tekrarla, farklılıklar:
- İsim: `Food_CrispyToast`
- Sprite: `Crispy_Toast`
- BoxCollider2D Size:
  ```
  Scale Çarpanı = 0.35 / 0.3 = 1.17
  Size = (Sprite Boyutu / 100) * 1.17 * 0.9
  ```
  - Örnek: Sprite 100x100 → Size = (1.05, 1.05)

**Food_BananaBread (ID: 8):**

Aynı adımları tekrarla, farklılıklar:
- İsim: `Food_BananaBread`
- Sprite: `Banana_Bread`
- BoxCollider2D Size:
  ```
  Scale Çarpanı = 1.05 / 0.3 = 3.5
  Size = (Sprite Boyutu / 100) * 3.5 * 0.9
  ```
  - Örnek: Sprite 100x100 → Size = (3.15, 3.15)

### Adım 3: CapsuleCollider2D Prefab (Food_BananaMilk)

#### 6.3.1 Obje Oluşturma

1. Hierarchy → **Create Empty** → İsim: `Food_BananaMilk`
2. **Sprite Renderer** → Sprite: `Banana_Milk`
3. **Rigidbody2D** → Aynı ayarlar (yukarıdaki gibi)
4. **Capsule Collider 2D** → **Add Component**
5. **Fruit** script ekle
6. **Layer:** Fruit

#### 6.3.2 CapsuleCollider2D Ayarları

**Inspector**'da:
```
Is Trigger: ❌
Used By Effector: ❌
Material: FruitBouncy
Offset: (0, 0)
Direction: Vertical (sprite'a göre - dikey şişe/bardak)
Size: Hesapla (aşağıda)
```

#### 6.3.3 Size Hesaplama

1. **Sprite Renderer**'da sprite'ın **genişlik ve yüksekliğini** gör
2. **Formül:**
   ```
   X = (Genişlik / 100) * 1.83 * 0.9
   Y = (Yükseklik / 100) * 1.83 * 0.9
   ```

**Örnek:**
- Sprite: 80x120 pixel
- X = (80 / 100) * 1.83 * 0.9 = 0.8 * 1.83 * 0.9 = **1.32**
- Y = (120 / 100) * 1.83 * 0.9 = 1.2 * 1.83 * 0.9 = **1.98**
- **Size:** `(1.3, 2.0)` (yuvarlanmış)

**Direction:**
- Sprite dikey bir şişe/bardak şeklindeyse → **Vertical**
- Sprite yatay bir şişe şeklindeyse → **Horizontal**

#### 6.3.4 Prefab Kaydetme

1. `Food_BananaMilk` objesini `Assets/Prefabs/Fruits` klasörüne sürükle
2. Hierarchy'deki orijinali sil

### Adım 4: PolygonCollider2D Prefab'ları

**6 prefab için:** Food_BakedBanana, Food_BananaFrenchToast, Food_EggCheeseSandwich, Food_EggSalamiSandwich, Food_EggCheeseSalamiSandwich, Food_BananaPancakes

#### 6.4.1 Obje Oluşturma (Her Biri İçin)

1. Hierarchy → **Create Empty** → İsim: `Food_BakedBanana` (veya diğerleri)
2. **Sprite Renderer** → İlgili sprite'ı ekle
3. **Rigidbody2D** → Aynı ayarlar
4. **Polygon Collider 2D** → **Add Component**
5. **Fruit** script ekle
6. **Layer:** Fruit

#### 6.4.2 PolygonCollider2D Ayarları

**Inspector**'da:
```
Is Trigger: ❌
Used By Effector: ❌
Material: FruitBouncy
Offset: (0, 0)
Points: Edit Collider ile ayarla
```

#### 6.4.3 Edit Collider ile Shape Ayarlama

**Yöntem 1: Otomatik (Unity'nin Önerdiği)**

1. **PolygonCollider2D** component'inde **Edit Collider** butonuna tıkla
2. Unity otomatik olarak sprite şekline göre bir polygon oluşturur
3. Scene view'da yeşil çizgileri gör
4. Eğer uygunsa kullan, değilse manuel ayarla

**Yöntem 2: Manuel Ayarlama**

1. **Edit Collider** moduna geç
2. **Scene View**'da sprite'ı gör
3. Yeşil çizgiler sprite'ın kenarlarını takip etmeli
4. **Noktaları taşı:**
   - Noktaya tıkla ve sürükle
5. **Nokta ekle:**
   - Yeşil çizgiye tıkla
6. **Nokta sil:**
   - Noktaya sağ tık → Delete
7. Collider sprite'ın **%85-90'ı** kadar olmalı (kenarlardan biraz içeride)

**Özel Notlar Her Prefab İçin:**

**Food_BakedBanana (ID: 2):**
- Muz şekline göre ayarla
- Alt ve üst kısımlar yuvarlak olabilir
- Collider biraz küçük tut (%85)

**Food_BananaFrenchToast (ID: 4):**
- Dikdörtgen ama köşeler yuvarlak
- 4-6 nokta yeterli
- Collider %90

**Food_EggCheeseSandwich (ID: 5):**
- Sandviç şekline göre
- Genellikle dikdörtgen
- Collider %90-95

**Food_EggSalamiSandwich (ID: 6):**
- Sandviç şekline göre
- Collider %90-95

**Food_EggCheeseSalamiSandwich (ID: 7):**
- En büyük sandviç
- Daha detaylı shape gerekebilir
- 6-8 nokta kullan
- Collider %90-95

**Food_BananaPancakes (ID: 9):**
- Yuvarlak ama tam değil
- 8-12 nokta ile yuvarlak şekil oluştur
- Collider %90-95

#### 6.4.4 Prefab Kaydetme

1. Her objeyi `Assets/Prefabs/Fruits` klasörüne sürükle
2. Hierarchy'deki orijinali sil

### Adım 5: FruitType SO'lara Prefab Bağlama

1. Her FruitType SO'yu aç (Project penceresinde)
2. **prefab** alanına ilgili prefab'ı sürükle:
   - `Food_BurnedToast` SO → `Food_BurnedToast` prefab
   - `Food_CrispyToast` SO → `Food_CrispyToast` prefab
   - ... (tüm 10 prefab için)

---

## 7️⃣ SAHNE KURULUMU

### Adım 1: Yeni Sahne Oluşturma

1. **File > New Scene**
2. **File > Save As**
3. İsim: `GameScene`
4. Klasör: `Assets/Scenes`

### Adım 2: Duvarlar Oluşturma

#### Sol Duvar (Wall_Left)

1. Hierarchy → **Create Empty** → İsim: `Wall_Left`
2. **Add Component** → **Box Collider 2D**
3. **Transform:**
   ```
   Position: X=-7, Y=0, Z=0
   ```
4. **Box Collider 2D:**
   ```
   Size: X=1, Y=20
   Material: WallFriction (Materials klasöründen)
   Is Trigger: ❌
   ```
5. **Layer:** Wall (Inspector'ın üst kısmından)

#### Sağ Duvar (Wall_Right)

1. `Wall_Left`'i kopyala: Seç → **Ctrl+D** (Windows) veya **Cmd+D** (Mac)
2. İsim: `Wall_Right`
3. **Transform:**
   ```
   Position: X=7, Y=0, Z=0
   ```
4. Diğer ayarlar aynı

#### Zemin (Floor)

1. Hierarchy → **Create Empty** → İsim: `Floor`
2. **Add Component** → **Box Collider 2D**
3. **Transform:**
   ```
   Position: X=0, Y=-8, Z=0
   ```
4. **Box Collider 2D:**
   ```
   Size: X=14, Y=1
   Material: WallFriction
   Is Trigger: ❌
   ```
5. **Layer:** Wall

#### Environment Parent

1. Tüm duvarları seç: `Wall_Left`, `Wall_Right`, `Floor`
2. Hierarchy'de sağ tık → **Create Empty Parent**
3. Parent'ın ismi: `Environment`

### Adım 3: FailLine Oluşturma

1. Hierarchy → **Create Empty** → İsim: `FailLine`
2. **Add Component** → **Box Collider 2D**
3. **Add Component** → **FailLineManager** (script)
4. **Transform:**
   ```
   Position: X=0, Y=7, Z=0
   ```
5. **Box Collider 2D:**
   ```
   Size: X=14, Y=2
   Is Trigger: ✅ (ÖNEMLİ!)
   Material: None (veya WallFriction)
   ```
6. **FailLineManager:**
   ```
   Grace Time: 1.0
   Debug Mode: false (veya true - test için)
   ```
7. **Layer:** FailLine

### Adım 4: Manager Objeleri Oluşturma

#### GameManager

1. Hierarchy → **Create Empty** → İsim: `GameManager`
2. **Add Component** → **GameManager** (script)

#### MergeSystem

1. Hierarchy → **Create Empty** → İsim: `MergeSystem`
2. **Add Component** → **MergeSystem** (script)

#### PoolManager

1. Hierarchy → **Create Empty** → İsim: `PoolManager`
2. **Add Component** → **PoolManager** (script)

#### ScoreManager

1. Hierarchy → **Create Empty** → İsim: `ScoreManager`
2. **Add Component** → **ScoreManager** (script)

#### FruitSpawner

1. Hierarchy → **Create Empty** → İsim: `FruitSpawner`
2. **Add Component** → **FruitSpawner** (script)
3. **Inspector**'da:
   ```
   Spawn Y: 8
   Min X: -6
   Max X: 6
   Preview Offset Y: 0.5
   ```

#### SpawnQueueManager

1. Hierarchy → **Create Empty** → İsim: `SpawnQueueManager`
2. **Add Component** → **SpawnQueueManager** (script)

#### Managers Parent

1. Tüm manager objelerini seç
2. Hierarchy'de sağ tık → **Create Empty Parent**
3. Parent'ın ismi: `Managers`

---

## 8️⃣ UI KURULUMU

### Adım 1: Canvas Oluşturma

1. Hierarchy → **UI > Canvas**
2. Canvas otomatik oluşturulur

### Adım 2: Canvas Ayarları

**Canvas:**
```
Render Mode: Screen Space - Overlay
UI Scale Mode: Scale With Screen Size
Reference Resolution: X=1080, Y=1920
Match: 0.5
```

### Adım 3: Score Text Oluşturma

1. Canvas'a sağ tık → **UI > Text - TextMeshPro**
2. İsim: `ScoreText`
3. **Rect Transform:**
   ```
   Anchor: Top Left
   Position: X=150, Y=-50
   Width: 200
   Height: 50
   ```
4. **TextMeshPro:**
   ```
   Text: Score: 0
   Font Size: 36
   Color: White
   Alignment: Left, Middle
   ```

### Adım 4: High Score Text

1. Canvas'a sağ tık → **UI > Text - TextMeshPro**
2. İsim: `HighScoreText`
3. **Rect Transform:**
   ```
   Anchor: Top Right
   Position: X=-150, Y=-50
   Width: 200
   Height: 50
   ```
4. **TextMeshPro:**
   ```
   Text: Best: 0
   Font Size: 28
   Color: Gold/Yellow
   Alignment: Right, Middle
   ```

### Adım 5: Next Fruit Preview

1. Canvas'a sağ tık → **UI > Image**
2. İsim: `NextFruitImage`
3. **Rect Transform:**
   ```
   Anchor: Top Right
   Position: X=-80, Y=-150
   Width: 80
   Height: 80
   ```
4. **Image:**
   ```
   Source Image: None (script otomatik dolduracak)
   Color: White
   ```

### Adım 6: Game Over Panel

1. Canvas'a sağ tık → **UI > Panel**
2. İsim: `GameOverPanel`
3. **Rect Transform:**
   ```
   Anchor: Stretch (her iki yönde)
   Left: 0, Right: 0, Top: 0, Bottom: 0
   ```
4. **Image:**
   ```
   Color: R=0, G=0, B=0, A=204 (yarı saydam siyah)
   ```
5. **Add Component** → **Canvas Group**
6. **Canvas Group:**
   ```
   Alpha: 1
   Interactable: ✅
   Blocks Raycasts: ✅
   ```

#### Game Over Panel İçeriği

**Game Over Title Text:**
1. `GameOverPanel`'e sağ tık → **UI > Text - TextMeshPro**
2. İsim: `GameOverTitleText`
3. **Rect Transform:**
   ```
   Anchor: Middle Center
   Position: X=0, Y=100
   Width: 400
   Height: 80
   ```
4. **TextMeshPro:**
   ```
   Text: GAME OVER!
   Font Size: 48
   Color: White
   Alignment: Center, Middle
   ```

**Final Score Text:**
1. `GameOverPanel`'e sağ tık → **UI > Text - TextMeshPro**
2. İsim: `FinalScoreText`
3. **Rect Transform:**
   ```
   Anchor: Middle Center
   Position: X=0, Y=0
   Width: 400
   Height: 60
   ```
4. **TextMeshPro:**
   ```
   Text: Score: 0
   Font Size: 36
   Color: White
   Alignment: Center, Middle
   ```

**Restart Button:**
1. `GameOverPanel`'e sağ tık → **UI > Button**
2. İsim: `GameOverRestartButton`
3. **Rect Transform:**
   ```
   Anchor: Middle Center
   Position: X=0, Y=-100
   Width: 200
   Height: 60
   ```
4. **Button:**
   ```
   Interactable: ✅
   ```
5. Button'un içindeki **Text** objesini bul:
   ```
   Text: Restart
   Font Size: 24
   Color: White
   ```

**Panel'i Başlangıçta Gizle:**
1. `GameOverPanel` seç
2. Inspector'da **GameObject** aktifliğini kapat (checkbox'ı kapat)

### Adım 7: UIHud Script Ekleme

1. **Canvas** seç
2. **Add Component** → **UIHud** (script)
3. **Inspector**'da referansları bağla (sonraki adımda)

---

## 9️⃣ REFERANSLARI BAĞLAMA

### Adım 1: GameManager Referansları

1. **GameManager** objesini seç
2. **Inspector**'da **GameManager** script'ini bul
3. Şu referansları bağla:

```
Fruit Database: FruitDatabase (ScriptableObjects klasöründen)
Pool Manager: PoolManager (Hierarchy'den)
Merge System: MergeSystem (Hierarchy'den)
Spawn Queue Manager: SpawnQueueManager (Hierarchy'den)
Fruit Spawner: FruitSpawner (Hierarchy'den)
Score Manager: ScoreManager (Hierarchy'den)
Fail Line Manager: FailLine (Hierarchy'den)
UI Hud: Canvas (Hierarchy'den - UIHud script'li)
```

**Nasıl Bağlanır:**
1. Inspector'da boş alanı bul
2. Project veya Hierarchy'den ilgili objeyi/asset'i sürükle
3. Bırak

### Adım 2: MergeSystem Referansları

1. **MergeSystem** objesini seç
2. **Inspector**'da:

```
Fruit Database: FruitDatabase (ScriptableObjects klasöründen)
Pool Manager: PoolManager (Hierarchy'den)
Score Manager: ScoreManager (Hierarchy'den)
```

### Adım 3: FruitSpawner Referansları

1. **FruitSpawner** objesini seç
2. **Inspector**'da:

```
Pool Manager: PoolManager (Hierarchy'den)
Spawn Queue Manager: SpawnQueueManager (Hierarchy'den)
```

### Adım 4: SpawnQueueManager Referansları

1. **SpawnQueueManager** objesini seç
2. **Inspector**'da:

```
Fruit Database: FruitDatabase (ScriptableObjects klasöründen)
```

### Adım 5: UIHud Referansları

1. **Canvas** objesini seç
2. **Inspector**'da **UIHud** script'ini bul
3. Şu referansları bağla:

```
Score Manager: ScoreManager (Hierarchy'den)
Spawn Queue Manager: SpawnQueueManager (Hierarchy'den)
Game Manager: GameManager (Hierarchy'den)
Score Text: ScoreText (Canvas altında)
High Score Text: HighScoreText (Canvas altında)
Next Fruit Image: NextFruitImage (Canvas altında)
Restart Button: (Canvas altında - varsa)
Game Over Panel: GameOverPanel (Canvas altında)
Game Over Title Text: GameOverTitleText (GameOverPanel altında)
Final Score Text: FinalScoreText (GameOverPanel altında)
Game Over Restart Button: GameOverRestartButton (GameOverPanel altında)
```

---

## 🔟 TEST VE KONTROL

### Adım 1: Game View Ayarları

1. **Game View** penceresini aç
2. **Aspect Ratio** dropdown'ından **9:19** seç (Samsung S10)
3. Veya **Free Aspect** seç ve manuel boyutlandır

### Adım 2: Play Moduna Geçme

1. **Play** butonuna bas (üstteki ▶ butonu)
2. Oyun başlamalı

### Adım 3: Kontroller

**Sprite Boyutları:**
- En küçük sprite (Burned Toast) ekranda rahat görünüyor mu?
- En büyük sprite (Banana Pancakes) ekrana sığıyor mu?
- Tüm sprite'lar dokunma için uygun boyutta mı?

**Collider'lar:**
- Sprite'lar birbirine değiyor mu?
- Collider'lar sprite'ların içinde mi? (taşmıyor mu?)
- Merge işlemi çalışıyor mu?

**UI:**
- Skor görünüyor mu?
- Next fruit preview görünüyor mu?
- Game Over panel çalışıyor mu?

### Adım 4: Sorun Giderme

**Sprite'lar çok küçükse:**
- Kamera Size'ı azalt (örn: 9 veya 8.5)
- Veya colliderRadius değerlerini artır

**Sprite'lar çok büyükse:**
- Kamera Size'ı artır (örn: 11 veya 12)
- Veya colliderRadius değerlerini azalt

**Collider'lar sprite'dan taşıyorsa:**
- Collider Size'ı küçült (%90 yerine %85)

**Collider'lar sprite'dan çok küçükse:**
- Collider Size'ı büyüt (%90 yerine %95)

**Merge çalışmıyorsa:**
- İki sprite'ın aynı ID'ye sahip olduğunu kontrol et
- Collider'ların birbirine değdiğini kontrol et
- Layer'ların doğru olduğunu kontrol et (Fruit layer'ında olmalı)

---

## ✅ FİNAL KONTROL LİSTESİ

- [ ] Tüm sprite'lar: Pixels Per Unit = 100
- [ ] Kamera: Size = 10, Position = (0, 4, -10)
- [ ] Canvas: Reference Resolution = 1080x1920, Match = 0.5
- [ ] 10 FruitType SO oluşturuldu ve ayarlandı
- [ ] Her FruitType SO'ya sprite bağlandı
- [ ] Her FruitType SO'ya prefab bağlandı
- [ ] NextType zinciri doğru (0→1→2→...→9→null)
- [ ] FruitDatabase oluşturuldu ve 10 tip eklendi
- [ ] Max Spawn Type ID = 2
- [ ] 10 prefab oluşturuldu
- [ ] BoxCollider2D'ler ayarlandı (3 prefab)
- [ ] CapsuleCollider2D ayarlandı (1 prefab)
- [ ] PolygonCollider2D'ler ayarlandı (6 prefab)
- [ ] Tüm collider'lara FruitBouncy material eklendi
- [ ] Tüm collider'larda Is Trigger kapalı
- [ ] Sahne kuruldu (Duvarlar, FailLine, Managers)
- [ ] UI kuruldu (ScoreText, HighScoreText, NextFruitImage, GameOverPanel)
- [ ] UIHud script Canvas'a eklendi
- [ ] Tüm referanslar bağlandı
- [ ] Game View'da 9:19 aspect ratio ile test edildi
- [ ] Sprite boyutları ergonomik görünüyor
- [ ] Collider'lar sprite'lara uygun
- [ ] Merge işlemi çalışıyor
- [ ] Game Over çalışıyor

---

## 🎮 SONUÇ

Bu rehberi takip ederek Samsung Galaxy S10'da ergonomik bir FoodMerge oyunu oluşturabilirsin. Tüm ayarlar optimize edilmiştir ve sprite'lar en küçükten en büyüğe kadar ekrana mükemmel şekilde sığacaktır.

**İyi çalışmalar! 📱🎮**
