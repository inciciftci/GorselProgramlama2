# 🎯 Collider Ayar Rehberi

Bu rehber, her yiyecek tipi için collider ayarlarını içerir.

---

## 📋 Collider Tipi Dağılımı

| Yiyecek | Collider Tipi | ID |
|---------|---------------|-----|
| Burned Toast | **BoxCollider2D** | 0 |
| Crispy Toast | **BoxCollider2D** | 1 |
| Baked Banana | **PolygonCollider2D** | 2 |
| Banana Milk | **CapsuleCollider2D** | 3 |
| Banana French Toast | **PolygonCollider2D** | 4 |
| Egg Cheese Sandwich | **PolygonCollider2D** | 5 |
| Egg Salami Sandwich | **PolygonCollider2D** | 6 |
| Full Sandwich | **PolygonCollider2D** | 7 |
| Banana Bread | **BoxCollider2D** | 8 |
| Banana Pancakes | **PolygonCollider2D** | 9 |

---

## 📦 BOXCOLLIDER2D AYARLARI

### Kullanılan Yiyecekler:
- ✅ Burned Toast (ID: 0)
- ✅ Crispy Toast (ID: 1)
- ✅ Banana Bread (ID: 8)

### Ayarlama Adımları:

1. **Prefab'ı seç** (örn: `Food_BurnedToast`)
2. **BoxCollider2D** component'ini bul
3. Şu ayarları yap:

```
Is Trigger: ❌ (kapalı)
Used By Effector: ❌ (kapalı)
Material: FruitBouncy (Assets/Materials klasöründen)
Offset: (0, 0) veya sprite'a göre ayarla
Size: Sprite'ın gerçek boyutuna göre ayarla
```

### Size Ayarlama Yöntemi:

**Yöntem 1: Sprite Bounds'a Göre**
1. Sprite Renderer component'inde sprite'ı seç
2. Sprite'ın gerçek boyutunu gör
3. BoxCollider2D Size'ı sprite boyutuna göre ayarla
   - Örnek: Sprite 100x100 pixel ise ve Pixels Per Unit 100 ise
   - Size: (1, 1) olmalı

**Yöntem 2: Görsel Ayarlama**
1. Scene view'da prefab'ı aç
2. BoxCollider2D'nin yeşil çerçevesini gör
3. Size'ı sprite'ın kenarlarına hizala
4. Offset ile merkeze hizala

### Önerilen Size Değerleri:

| Yiyecek | Önerilen Size (X, Y) | Offset |
|---------|---------------------|--------|
| Burned Toast | Sprite boyutuna göre | (0, 0) |
| Crispy Toast | Sprite boyutuna göre | (0, 0) |
| Banana Bread | Sprite boyutuna göre | (0, 0) |

**Not:** Her sprite farklı boyutta olabilir, bu yüzden her prefab için manuel ayarlama yapmalısın.

---

## 🥛 CAPSULECOLLIDER2D AYARLARI

### Kullanılan Yiyecekler:
- ✅ Banana Milk (ID: 3)

### Ayarlama Adımları:

1. **Prefab'ı seç** (`Food_BananaMilk`)
2. **CapsuleCollider2D** component'ini bul
3. Şu ayarları yap:

```
Is Trigger: ❌ (kapalı)
Used By Effector: ❌ (kapalı)
Material: FruitBouncy
Offset: (0, 0) veya sprite'a göre ayarla
Size: Sprite'ın gerçek boyutuna göre ayarla
Direction: Horizontal veya Vertical (sprite'a göre)
```

### Size ve Direction Ayarlama:

**Banana Milk için:**
- Sprite genellikle dikey bir şişe/bardak şeklinde
- **Direction**: `Vertical` seç
- **Size**: 
  - X: Sprite genişliği
  - Y: Sprite yüksekliği
- Offset ile merkeze hizala

**Örnek:**
```
Size: (0.5, 1.0)  // Genişlik 0.5, Yükseklik 1.0
Direction: Vertical
Offset: (0, 0)
```

---

## 🔷 POLYGONCOLLIDER2D AYARLARI

### Kullanılan Yiyecekler:
- ✅ Baked Banana (ID: 2)
- ✅ Banana French Toast (ID: 4)
- ✅ Egg Cheese Sandwich (ID: 5)
- ✅ Egg Salami Sandwich (ID: 6)
- ✅ Full Sandwich (ID: 7)
- ✅ Banana Pancakes (ID: 9)

### Ayarlama Adımları:

1. **Prefab'ı seç** (örn: `Food_BakedBanana`)
2. **PolygonCollider2D** component'ini bul
3. Şu ayarları yap:

```
Is Trigger: ❌ (kapalı)
Used By Effector: ❌ (kapalı)
Material: FruitBouncy
Offset: (0, 0)
Points: Sprite şekline göre otomatik oluşturulur
```

### PolygonCollider2D Otomatik Ayarlama:

**En Kolay Yöntem:**
1. PolygonCollider2D component'inde **Edit Collider** butonuna tıkla
2. Scene view'da sprite'ın kenarlarını takip ederek noktaları ayarla
3. Veya Unity otomatik olarak sprite şekline göre oluşturur

**Manuel Ayarlama:**
1. Sprite Renderer'da sprite'ı seç
2. PolygonCollider2D → **Edit Collider**
3. Scene view'da yeşil çizgileri sprite kenarlarına hizala
4. Noktaları ekle/çıkar/taşı

### Önerilen Ayarlar:

| Yiyecek | Özel Notlar |
|---------|-------------|
| Baked Banana | Muz şekline göre ayarla |
| Banana French Toast | Dikdörtgen ama köşeler yuvarlak |
| Egg Cheese Sandwich | Sandviç şekline göre |
| Egg Salami Sandwich | Sandviç şekline göre |
| Full Sandwich | En büyük sandviç, daha detaylı shape |
| Banana Pancakes | Yuvarlak ama tam değil, polygon ile daha iyi |

---

## ✅ GENEL AYARLAR (Tüm Collider'lar İçin)

### Ortak Ayarlar:
```
Is Trigger: ❌ (kapalı - çarpışma için gerekli)
Used By Effector: ❌ (kapalı)
Material: FruitBouncy (Assets/Materials klasöründen)
```

### Offset Ayarlama:
- Sprite'ın pivot noktası merkezde değilse Offset kullan
- Sprite'ın merkezini collider'ın merkezine hizala
- Genellikle (0, 0) yeterli

### Material Ayarlama:
1. **Assets/Materials** klasörüne git
2. **FruitBouncy** material'ını bul
3. Collider component'inde **Material** alanına sürükle

---

## 🎮 TEST ETME

### Collider'ları Test Etme:
1. Prefab'ı Scene'e sürükle
2. **Play** moduna geç
3. Yiyecekleri birbirine yaklaştır
4. Çarpışma doğru çalışıyor mu kontrol et
5. Merge işlemi doğru çalışıyor mu kontrol et

### Sorun Giderme:

**Çarpışma çalışmıyor:**
- Collider'ın **Is Trigger** kapalı mı kontrol et
- Collider sprite'ın dışında mı kontrol et
- Layer'lar doğru mu kontrol et (Fruit layer'ında olmalı)

**Merge çalışmıyor:**
- İki yiyecek aynı ID'ye sahip mi kontrol et
- Collider'lar birbirine değiyor mu kontrol et
- Rigidbody2D component'i var mı kontrol et

**Collider çok büyük/küçük:**
- Size değerlerini sprite boyutuna göre ayarla
- Scene view'da görsel olarak kontrol et

---

## 📝 HIZLI KONTROL LİSTESİ

- [ ] Tüm BoxCollider2D'ler ayarlandı (Burned Toast, Crispy Toast, Banana Bread)
- [ ] CapsuleCollider2D ayarlandı (Banana Milk)
- [ ] Tüm PolygonCollider2D'ler ayarlandı (6 yiyecek)
- [ ] Tüm collider'lara FruitBouncy material eklendi
- [ ] Tüm collider'larda Is Trigger kapalı
- [ ] Offset değerleri sprite'a göre ayarlandı
- [ ] Size/Points değerleri sprite boyutuna uygun
- [ ] Test edildi ve çarpışma çalışıyor

---

## 💡 İPUÇLARI

1. **Scene View'da Görselleştirme:**
   - Scene view'da collider'lar yeşil çizgilerle gösterilir
   - Bu sayede sprite'a göre ayarlayabilirsin

2. **Sprite Pivot Noktası:**
   - Sprite'ın pivot noktası merkezde değilse Offset kullan
   - Pivot noktasını Sprite Editor'da değiştirebilirsin

3. **PolygonCollider2D Optimizasyonu:**
   - Çok fazla nokta kullanma (performans için)
   - Sprite şekline yakın ama basit tut

4. **Test Sırasında:**
   - Gizmos'u aç (Scene view'da Gizmos butonu)
   - Collider'ları daha net görebilirsin

---

**İyi çalışmalar! 🎮**
